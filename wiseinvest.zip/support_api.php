<?php
include 'includes/db.php';
session_start();
date_default_timezone_set('Asia/Bangkok');

$action = isset($_GET['action']) ? $_GET['action'] : '';

// --- 1. SEND MESSAGE (User or Admin) ---
if ($action == 'send' && $_SERVER['REQUEST_METHOD'] == 'POST') {
    // If Admin is replying, they must provide the target user_id
    if (isset($_POST['target_id']) && isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
        $user_id = intval($_POST['target_id']);
        $sender = 'admin';
    } 
    // If User is sending
    elseif (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];
        $sender = 'user';
    } else {
        die("Unauthorized");
    }

    $message = clean($_POST['message']);
    
    if (!empty($message)) {
        $stmt = $conn->prepare("INSERT INTO support_messages (user_id, message, sender) VALUES (?, ?, ?)");
        $stmt->bind_param("iss", $user_id, $message, $sender);
        $stmt->execute();
    }
    exit();
}

// --- 2. FETCH MESSAGES ---
if ($action == 'fetch') {
    // Admin fetching a specific user's chat
    if (isset($_GET['target_id']) && isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
        $user_id = intval($_GET['target_id']);
    } 
    // User fetching their own chat
    elseif (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];
    } else {
        echo json_encode([]); exit();
    }

    $stmt = $conn->prepare("SELECT message, sender, created_at FROM support_messages WHERE user_id = ? ORDER BY created_at ASC");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $messages = [];
    while ($row = $result->fetch_assoc()) {
        $messages[] = [
            'msg' => htmlspecialchars($row['message']),
            'sender' => $row['sender'], // 'user' or 'admin'
            'time' => date('h:i A', strtotime($row['created_at']))
        ];
    }
    echo json_encode($messages);
    exit();
}
?>