<?php include 'includes/header.php'; ?>

<style>
*{box-sizing:border-box;margin:0;padding:0}

.ff-wrapper{
font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,sans-serif;
background:radial-gradient(circle at top,#0f172a,#020617);
color:#e5e7eb;
min-height:100vh;
padding:80px 20px;
display:flex;
justify-content:center
}

.ff-container{width:100%;max-width:720px}

.ff-card{
background:linear-gradient(145deg,rgba(15,23,42,.85),rgba(2,6,23,.9));
border:1px solid rgba(255,255,255,.05);
backdrop-filter:blur(18px);
border-radius:18px;
padding:36px;
box-shadow:0 40px 100px rgba(0,0,0,.65);
margin-bottom:36px;
transition:transform .25s ease, box-shadow .25s ease
}

.ff-card:hover{
transform:translateY(-6px);
box-shadow:0 50px 120px rgba(0,0,0,.8)
}

.ff-card h2{font-size:26px;margin-bottom:6px}

.ff-card p{
color:#94a3b8;
margin-bottom:22px;
line-height:1.5
}

.ff-card label{
display:block;
margin:14px 0 6px;
font-size:14px;
color:#cbd5f5
}

.ff-card input,select{
width:100%;
padding:14px;
border-radius:10px;
border:none;
background:#020617;
color:#fff;
font-size:15px
}

.ff-card input:focus{
outline:2px solid #22c55e
}

.ff-result{
margin-top:20px;
padding:16px;
border-radius:12px;
background:rgba(34,197,94,.12);
color:#22c55e;
font-size:16px;
display:none
}

.ff-result b{
font-size:22px;
background:linear-gradient(90deg,#22c55e,#4ade80);
-webkit-background-clip:text;
-webkit-text-fill-color:transparent
}

.ff-error{
background:rgba(239,68,68,.15);
color:#f87171
}

.ff-progress{
height:14px;
background:#020617;
border-radius:10px;
margin-top:16px;
overflow:hidden
}

.ff-bar{
height:100%;
width:0%;
background:linear-gradient(90deg,#22c55e,#4ade80);
transition:width .8s ease
}

.tip{
display:inline-flex;
align-items:center;
justify-content:center;
margin-left:6px;
width:20px;
height:20px;
border-radius:50%;
background:#22c55e;
color:#020617;
font-size:12px;
font-weight:bold;
cursor:pointer;
position:relative;
transition:transform .2s ease, box-shadow .2s ease;
}

.tip:hover{
transform:scale(1.1);
box-shadow:0 0 10px rgba(34,197,94,.7);
}

.tip-text{
position:absolute;
left:50%;
bottom:140%;
transform:translateX(-50%) translateY(10px);
background:#020617;
color:#e5e7eb;
padding:12px 14px;
border-radius:10px;
font-size:13px;
line-height:1.5;
width:260px;
box-shadow:0 20px 40px rgba(0,0,0,.7);
opacity:0;
pointer-events:none;
transition:all .25s ease;
z-index:999;
}

.tip.active .tip-text{
opacity:1;
transform:translateX(-50%) translateY(0);
pointer-events:auto;
}

.tip-text::after{
content:"";
position:absolute;
bottom:-6px;
left:50%;
transform:translateX(-50%);
border-width:6px;
border-style:solid;
border-color:#020617 transparent transparent transparent;
}

.ff-summary{
background:#020617;
padding:18px;
border-radius:12px;
margin-top:20px;
line-height:1.8
}

@media(max-width:700px){
.ff-card{padding:24px}
.ff-card h2{font-size:22px}
.tip-text{width:220px;font-size:12px}
}

/* Wealth Chart */

.chart-box{
margin-top:24px;
background:#020617;
border-radius:12px;
padding:18px;
}

#growthChart{
width:100%;
height:260px;
}

/* Reset Button */

.reset-btn{
margin-top:20px;
width:100%;
padding:14px;
border-radius:12px;
border:none;
font-weight:700;
font-size:15px;
cursor:pointer;
color:white;

background:linear-gradient(135deg,#ef4444,#dc2626);

transition:all .25s ease;
box-shadow:0 10px 25px rgba(239,68,68,.35);
}

.reset-btn:hover{
transform:translateY(-2px);
box-shadow:0 14px 35px rgba(239,68,68,.55);
}

.reset-btn:active{
transform:scale(.98);
}
</style>

<div class="ff-wrapper">
<div class="ff-container">

<div class="ff-card">
<label>Currency</label>
<select id="currency">
<option value="$">USD</option>
<option value="฿">THB</option>
<option value="¥">JPY</option>
<option value="MMK">MMK</option>
</select>
</div>

<!-- Calculator 1 -->

<div class="ff-card">
<h2>1️⃣ Inflation-Adjusted Annual Expenses</h2>

<label>
Annual Expenses (Today)
<span class="tip">ⓘ
<span class="tip-text">
သင်ယနေ့ အသုံးပြုနေသော တစ်နှစ်တာ အသုံးစရိတ် (စားစရိတ်၊ အိမ်စရိတ်၊ သွားလာစရိတ်)
</span>
</span>
</label>

<input type="number" id="c1_expense">

<label>
Number of Years
<span class="tip">ⓘ
<span class="tip-text">
ဘယ်နှစ်နှစ်အကြာတွင် အသုံးစရိတ်ကို ခန့်မှန်းချင်ပါသလဲ
</span>
</span>
</label>

<input type="number" id="c1_years">

<label>
Inflation Rate (%)
<span class="tip">ⓘ
<span class="tip-text">
ငွေဖောင်းပွမှုနှုန်း။ ပုံမှန်အားဖြင့် ၂% မှ ၅% အတွင်း ဖြစ်တတ်သည်
</span>
</span>
</label>

<input type="number" id="c1_inflation">

<div class="ff-result" id="r1"></div>
</div>

<!-- Calculator 2 -->

<div class="ff-card">
<h2>2️⃣ Financial Freedom Capital (MFFC)</h2>

<label>
Years Expenses Must Last
<span class="tip">ⓘ
<span class="tip-text">
Financial Freedom ရရှိပြီးနောက် သင့်အသုံးစရိတ်ကို ဘယ်နှစ်နှစ် ထောက်ပံ့မည်
</span>
</span>
</label>

<input type="number" id="c2_years">

<label>
Expected Annual Return (%)
<span class="tip">ⓘ
<span class="tip-text">
သင့်ရင်းနှီးမြှုပ်နှံမှုမှ မျှော်လင့်ထားသော နှစ်စဉ်အမြတ်နှုန်း
</span>
</span>
</label>

<input type="range" min="2" max="15" value="7" id="c2_return">
<span id="returnLabel">7%</span>

<div class="ff-result" id="r2"></div>
</div>

<!-- Calculator 3 -->

<div class="ff-card">
<h2>3️⃣ Required Rate of Return</h2>

<label>
Current Liquid Assets
<span class="tip">ⓘ
<span class="tip-text">
အလွယ်တကူ အသုံးပြုနိုင်သော ငွေသားနှင့် ရင်းနှီးမြှုပ်နှံမှုများ
</span>
</span>
</label>

<input type="number" id="c3_assets">

<label>
Annual Savings
<span class="tip">ⓘ
<span class="tip-text">
တစ်နှစ်အတွင်း သင် သိမ်းဆည်းနိုင်သော ငွေပမာဏ
</span>
</span>
</label>

<input type="number" id="c3_savings">

<label>
Time Target (Years)
<span class="tip">ⓘ
<span class="tip-text">
Financial Freedom ရရှိချင်သော အချိန်ကာလ
</span>
</span>
</label>

<input type="number" id="c3_years">

<div class="ff-result" id="r3"></div>
</div>

<!-- Calculator 4 -->

<div class="ff-card">
<h2>4️⃣ Years to Financial Freedom</h2>

<label>
Current Liquid Assets
<span class="tip">ⓘ
<span class="tip-text">
လက်ရှိ ရင်းနှီးမြှုပ်နှံထားသော စုစုပေါင်း ပိုင်ဆိုင်မှု
</span>
</span>
</label>

<input type="number" id="c4_assets">

<label>
Annual Savings
<span class="tip">ⓘ
<span class="tip-text">
တစ်နှစ်အတွင်း ထပ်မံရင်းနှီးမြှုပ်နှံမည့် ငွေပမာဏ
</span>
</span>
</label>

<input type="number" id="c4_savings">

<label>
Expected Annual Return (%)
<span class="tip">ⓘ
<span class="tip-text">
Portfolio မှ မျှော်လင့်ထားသော နှစ်စဉ်အမြတ်နှုန်း
</span>
</span>
</label>

<input type="number" id="c4_return">

<div class="ff-result" id="r4"></div>

<div class="ff-progress">
<div class="ff-bar" id="progressBar"></div>
</div>

<p id="progressText"></p>
<div class="chart-box">
<h3 style="margin-bottom:10px;">📈 Wealth Growth Projection</h3>
<canvas id="growthChart"></canvas>
</div>

</div>

<div class="ff-card">
<h2>📊 Financial Freedom Summary</h2>
<div class="ff-summary" id="summary">Waiting for calculations...</div>
<button class="reset-btn" onclick="location.reload()">
↺ Reset Calculator
</button>
</div>

</div>
</div>

<script>

let adjustedExpense=0
let mffc=0

function currency(){
return document.getElementById("currency").value
}

function animateValue(el,start,end,duration){
let startTime=null
function animation(currentTime){
if(!startTime) startTime=currentTime
const progress=Math.min((currentTime-startTime)/duration,1)
const value=start+(end-start)*progress
el.innerHTML=currency()+" "+value.toLocaleString(undefined,{maximumFractionDigits:2})
if(progress<1) requestAnimationFrame(animation)
}
requestAnimationFrame(animation)
}

function calc1(){
const e=+c1_expense.value
const y=+c1_years.value
const i=+c1_inflation.value/100
if(e<=0||y<0||i<0) return
adjustedExpense=e*Math.pow(1+i,y)
r1.style.display="block"
animateValue(r1,0,adjustedExpense,800)
updateSummary()
}

function drawWealthChart(PV,PMT,r,years){

const canvas=document.getElementById("growthChart")
const ctx=canvas.getContext("2d")

canvas.width=canvas.offsetWidth
canvas.height=260

ctx.clearRect(0,0,canvas.width,canvas.height)

let data=[]
let wealth=PV

for(let i=0;i<=years;i++){

wealth=wealth*(1+r)+PMT
data.push(wealth)

}

const max=Math.max(...data)

const w=canvas.width
const h=canvas.height

/* GRID */

ctx.strokeStyle="rgba(255,255,255,.06)"
ctx.lineWidth=1

for(let i=0;i<5;i++){

const y=(i/4)*h

ctx.beginPath()
ctx.moveTo(0,y)
ctx.lineTo(w,y)
ctx.stroke()

}

/* AXIS LABELS */

ctx.fillStyle="#94a3b8"
ctx.font="11px Inter"

for(let i=0;i<5;i++){

const value=Math.round((max/4)*(4-i))

ctx.fillText(currency()+" "+value.toLocaleString(),4,(i/4)*h+12)

}

/* CHART LINE */

ctx.beginPath()
ctx.strokeStyle="#22c55e"
ctx.lineWidth=3

data.forEach((v,i)=>{

const x=(i/(data.length-1))*w
const y=h-(v/max)*h

if(i===0) ctx.moveTo(x,y)
else ctx.lineTo(x,y)

})

ctx.stroke()

/* MILESTONE MARKERS */

ctx.fillStyle="#4ade80"

data.forEach((v,i)=>{

if(i%Math.ceil(years/5)!==0 && i!==years) return

const x=(i/(data.length-1))*w
const y=h-(v/max)*h

ctx.beginPath()
ctx.arc(x,y,4,0,Math.PI*2)
ctx.fill()

ctx.fillStyle="#e5e7eb"
ctx.font="11px Inter"

ctx.fillText("Year "+i,x-12,y-10)

ctx.fillStyle="#4ade80"

})

}

const max=Math.max(...data)

ctx.beginPath()
ctx.strokeStyle="#22c55e"
ctx.lineWidth=3

data.forEach((v,i)=>{

const x=(i/(data.length-1))*canvas.width
const y=canvas.height-(v/max)*canvas.height

if(i===0) ctx.moveTo(x,y)
else ctx.lineTo(x,y)

})

ctx.stroke()

}

function calc2(){
const y=+c2_years.value
const r=+c2_return.value/100
if(adjustedExpense<=0||y<=0||r<=0) return
mffc=adjustedExpense*((1-Math.pow(1+r,-y))/r)*(1+r)
r2.style.display="block"
animateValue(r2,0,mffc,800)
updateSummary()
}

function calc3(){
const PV=+c3_assets.value
const PMT=+c3_savings.value
const n=+c3_years.value
if(mffc<=0||PV<0||PMT<0||n<=0) return
let r=0.10
for(let i=0;i<1000;i++){
const A=Math.pow(1+r,n)
const fv=PV*A+PMT*((A-1)/r)*(1+r)
const f=fv-mffc
if(Math.abs(f)<1e-12) break
const df=PV*n*Math.pow(1+r,n-1)+PMT*(((A-1)/r)+((n*A*r-(A-1))/(r*r)))
r=r-f/df
}
r3.style.display="block"
r3.innerHTML="Required annual return: <b>"+(r*100).toFixed(4)+"%</b>"
}

function calc4(){
const PV=+c4_assets.value
const PMT=+c4_savings.value
const r=+c4_return.value/100
if(mffc<=0||PV<0||PMT<0||r<=0) return
let years=0
while(years<=100){
const A=Math.pow(1+r,years)
const fv=PV*A+PMT*((A-1)/r)*(1+r)
if(fv>=mffc) break
years++
}
const freedomYear=new Date().getFullYear()+years
r4.style.display="block"
r4.innerHTML="Financial freedom in <b>"+years+" years</b><br>Expected Year: <b>"+freedomYear+"</b>"
updateProgress(PV,mffc)
updateProgress(PV,mffc)
drawWealthChart(PV,PMT,r,years)
updateSummary(years,freedomYear)
}

function updateProgress(current,target){
const percent=Math.min((current/target)*100,100)
progressBar.style.width=percent+"%"
progressText.innerHTML="Progress to Freedom: "+percent.toFixed(1)+"%"
}

function updateSummary(years=null,year=null){
summary.innerHTML=`
Future Expenses: ${currency()} ${adjustedExpense.toLocaleString()}<br>
Target Capital: ${currency()} ${mffc.toLocaleString()}<br>
Years to Freedom: ${years??"-"}<br>
Freedom Year: ${year??"-"}
`
}

document.querySelectorAll("input").forEach(input=>{
input.addEventListener("input",()=>{
calc1();calc2();calc3();calc4()
})
})

c2_return.addEventListener("input",()=>{
returnLabel.innerHTML=c2_return.value+"%"
})

/* Advanced Tooltip Engine */

const tooltips=document.querySelectorAll(".tip")

tooltips.forEach(tip=>{
tip.addEventListener("click",(e)=>{
e.stopPropagation()
document.querySelectorAll(".tip").forEach(t=>{
if(t!==tip) t.classList.remove("active")
})
tip.classList.toggle("active")
smartPosition(tip)
})
})

document.addEventListener("click",()=>{
document.querySelectorAll(".tip").forEach(t=>t.classList.remove("active"))
})

function smartPosition(tip){
const tooltip=tip.querySelector(".tip-text")
const rect=tooltip.getBoundingClientRect()
const padding=10

if(rect.right>window.innerWidth-padding){
tooltip.style.left="auto"
tooltip.style.right="0"
tooltip.style.transform="translateY(0)"
}

if(rect.left<padding){
tooltip.style.left="0"
tooltip.style.transform="translateY(0)"
}
}

window.addEventListener("resize",()=>{
document.querySelectorAll(".tip.active").forEach(tip=>{
smartPosition(tip)
})
})

</script>

<?php include 'includes/footer.php'; ?>