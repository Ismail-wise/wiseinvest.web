<?php include 'includes/header.php'; ?>

<style>
/* ===== HERO (PROFESSIONAL UPGRADE) ===== */
.page-hero {
    position: relative;
    padding: 80px 20px 60px; /* tighter, premium */
    background:
        radial-gradient(700px 350px at 50% -160px, rgba(250,204,21,0.22), transparent),
        radial-gradient(circle at 85% 35%, rgba(56,189,248,0.15), transparent 60%),
        linear-gradient(135deg, #020617, #020617);
    color: #fff;
    text-align: center;
    overflow: hidden;
}

/* Soft bottom divider glow */
.page-hero::after {
    content: "";
    position: absolute;
    left: 0;
    right: 0;
    bottom: -1px;
    height: 80px;
    background: linear-gradient(to bottom, rgba(2,6,23,0), #020617);
    pointer-events: none;
}

/* Hero card */
.hero-inner {
    max-width: 860px;
    margin: auto;
    padding: 42px 32px;
    background: rgba(15,23,42,0.65);
    backdrop-filter: blur(12px);
    border-radius: 22px;
    border: 1px solid rgba(255,255,255,0.12);
    box-shadow: 0 30px 80px rgba(0,0,0,0.45);
}

/* Title */
.hero-title {
    font-size: clamp(2.4rem, 4.5vw, 3.2rem);
    font-weight: 800;
    letter-spacing: -0.6px;
    margin-bottom: 12px;
}

/* Subtitle */
.hero-subtitle {
    max-width: 700px;
    margin: auto;
    font-size: 1.08rem;
    line-height: 1.65;
    color: #cbd5f5;
}

/* Trust strip */
.hero-trust {
    display: flex;
    justify-content: center;
    gap: 24px;
    margin-top: 26px;
    flex-wrap: wrap;
}

.hero-trust span {
    font-size: 0.9rem;
    color: #e5e7eb;
    background: rgba(255,255,255,0.08);
    padding: 8px 14px;
    border-radius: 999px;
}

/* ===== GRID ===== */
.broker-section {
    padding: 70px 20px;
    background: #f8fafc;
}

.broker-grid {
    max-width: 1200px;
    margin: auto;
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 30px;
}

/* ===== CARD ===== */
.broker-card {
    position: relative;
    background: #fff;
    border-radius: 16px;
    padding: 35px 20px;
    text-align: center;
    box-shadow: 0 10px 30px rgba(0,0,0,0.06);
    overflow: hidden;
    animation: fadeUp 0.6s ease both;
}

@keyframes fadeUp {
    from {
        opacity: 0;
        transform: translateY(16px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.broker-card img {
    max-width: 160px;
    max-height: 70px;
    object-fit: contain;
}

/* ===== OVERLAY ===== */
.broker-actions {
    position: absolute;
    inset: 0;
    background: rgba(15,23,42,0.92);
    display: flex;
    flex-direction: column;
    justify-content: center;
    gap: 12px;
    opacity: 0;
    transition: .3s ease;
}

.broker-card:hover .broker-actions {
    opacity: 1;
}

.broker-actions button,
.broker-actions a {
    margin: 0 25px;
    padding: 10px;
    border-radius: 8px;
    font-weight: 600;
    border: none;
    cursor: pointer;
    text-decoration: none;
}

.btn-details {
    background: #e5e7eb;
}

.btn-contact {
    background: #facc15;
    color: #020617;
}

/* ===== MODAL ===== */
.modal {
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,0.65);
    display: none;
    align-items: center;
    justify-content: center;
    z-index: 9999;
}

.modal.active {
    display: flex;
}

.modal-box {
    background: #fff;
    width: 92%;
    max-width: 1000px;
    border-radius: 16px;
    padding: 30px;
    position: relative;
    max-height: 90vh;
    overflow-y: auto;
}

.modal-close {
    position: absolute;
    top: 15px;
    right: 20px;
    font-size: 22px;
    cursor: pointer;
}

/* ===== IMAGE CARDS ===== */
.flash-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
    gap: 20px;
    margin-top: 25px;
}

.flash-card {
    background: transparent;
    padding: 0;
}

.flash-card img {
    width: 100%;
    border-radius: 12px;
}

/* Empty state */
.no-data {
    text-align: center;
    color: #64748b;
    font-size: 1rem;
    padding: 40px 0;
}

/* ===== FLOATING BROKER LOGOS (HERO BACKGROUND) ===== */
.hero-floating-logos {
    position: absolute;
    inset: 0;
    pointer-events: none;
    overflow: hidden;
    z-index: 1; /* behind hero-inner */
}

.hero-floating-logos img {
    position: absolute;
    width: 70px;
    opacity: 0.08;
    filter: grayscale(100%) brightness(1.4);
    animation: floatRandom 22s linear infinite;
}

/* Different speeds & sizes */
.hero-floating-logos img:nth-child(2) { width: 90px; animation-duration: 26s; }
.hero-floating-logos img:nth-child(3) { width: 60px; animation-duration: 20s; }
.hero-floating-logos img:nth-child(4) { width: 80px; animation-duration: 30s; }
.hero-floating-logos img:nth-child(5) { width: 65px; animation-duration: 24s; }

/* Floating animation */
@keyframes floatRandom {
    0% {
        transform: translateY(120%) rotate(0deg);
    }
    100% {
        transform: translateY(-140%) rotate(360deg);
    }
}
</style>

<div class="page-hero">
    <!-- ===== FLOATING BROKER LOGOS BACKGROUND ===== -->
<div class="hero-floating-logos">
    <img src="assets/logos/wise.svg" style="left:10%; animation-delay:-2s;">
    <img src="assets/logos/etoro.svg" style="left:25%; animation-delay:-6s;">
    <img src="assets/logos/xtb.png" style="left:45%; animation-delay:-10s;">
    <img src="assets/logos/ibkr.png" style="left:65%; animation-delay:-14s;">
    <img src="assets/logos/schwab.svg" style="left:85%; animation-delay:-18s;">
</div>
    <div class="hero-inner">
        <h1 class="hero-title">Supported Brokers & Platforms</h1>

        <p class="hero-subtitle">
            We help you open and configure global brokerage accounts safely,
            professionally, and without confusion.
        </p>

        <div class="hero-trust">
            <span>✔ Global Platforms</span>
            <span>✔ Secure Setup</span>
            <span>✔ Step-by-Step Guidance</span>
            <span>✔ Trusted by Clients</span>
        </div>
    </div>
</div>

<section class="broker-section">
<div class="broker-grid">

<?php
$brokers = [
    ["key"=>"wise","logo"=>"wise.svg","name"=>"Wise"],
    ["key"=>"etoro","logo"=>"etoro.svg","name"=>"eToro"],
    ["key"=>"xtb","logo"=>"xtb.png","name"=>"XTB"],
    ["key"=>"moomoo","logo"=>"moomoo.png","name"=>"Moomoo"],
    ["key"=>"tiger","logo"=>"tiger.png","name"=>"Tiger Brokers"],
    ["key"=>"ibkr","logo"=>"ibkr.png","name"=>"Interactive Brokers"],
    ["key"=>"schwab","logo"=>"schwab.svg","name"=>"Charles Schwab"],
    ["key"=>"easyequities","logo"=>"easyequities.png","name"=>"EasyEquities"],
    ["key"=>"longbridge","logo"=>"longbridge.webp","name"=>"Longbridge"]
];

foreach ($brokers as $b):
?>
    <div class="broker-card">
        <img src="assets/logos/<?= $b['logo']; ?>" alt="<?= $b['name']; ?>">
        <div class="broker-actions">
            <button class="btn-details"
        data-broker="<?= $b['key']; ?>"
        onclick="openModal('<?= $b['key']; ?>')">
    Broker Details
</button>
            <a href="contact.php" class="btn-contact">
                Buy Our Service
            </a>
        </div>
    </div>
<?php endforeach; ?>

</div>
</section>

<!-- ===== MODAL ===== -->
<div class="modal" id="brokerModal">
    <div class="modal-box">
        <span class="modal-close" onclick="closeModal()">✕</span>
        <h2 id="modalTitle"></h2>
        <div class="flash-grid" id="flashContent"></div>
    </div>
</div>

<script>
/* ===== IMAGE CARD DATA ===== */
const brokerCards = {
    xtb: [
        "assets/broker-cards/xtb/card-1.jpg",
        "assets/broker-cards/xtb/card-2.jpg",
        "assets/broker-cards/xtb/card-3.jpg"
    ],
    etoro: [
        "assets/broker-cards/etoro/card-1.jpg",
        "assets/broker-cards/etoro/card-2.jpg",
        "assets/broker-cards/etoro/card-3.jpg"
    ],
    schwab: [
        "assets/broker-cards/schwab/card-1.jpg",
        "assets/broker-cards/schwab/card-2.jpg",
        "assets/broker-cards/schwab/card-3.jpg"
    ],
    ibkr: [
        "assets/broker-cards/ibkr/card-1.jpg",
        "assets/broker-cards/ibkr/card-2.jpg",
        "assets/broker-cards/ibkr/card-3.jpg"
    ],
    tiger: [
        "assets/broker-cards/tiger/card-1.jpg",
        "assets/broker-cards/tiger/card-2.jpg",
        "assets/broker-cards/tiger/card-3.jpg"
    ],
    moomoo: [
        "assets/broker-cards/moomoo/card-1.jpg",
        "assets/broker-cards/moomoo/card-2.jpg",
        "assets/broker-cards/moomoo/card-3.jpg"
    ],
    easyequities: [
        "assets/broker-cards/easyequities/card-1.jpg",
        "assets/broker-cards/easyequities/card-2.jpg",
        "assets/broker-cards/easyequities/card-3.jpg"
    ],
    longbridge: [
        "assets/broker-cards/longbridge/card-1.jpg",
        "assets/broker-cards/longbridge/card-2.jpg",
        "assets/broker-cards/longbridge/card-3.jpg"
    ]
};

/* ===== OPEN MODAL ===== */
function openModal(broker) {
    const modal = document.getElementById("brokerModal");
    const title = document.getElementById("modalTitle");
    const content = document.getElementById("flashContent");

    title.innerText = broker.toUpperCase() + " Details";
    content.innerHTML = "";

    if (!brokerCards[broker]) {
        content.innerHTML = `<div class="no-data">Broker details will be added soon.</div>`;
    } else {
        brokerCards[broker].forEach(img => {
            content.innerHTML += `
                <div class="flash-card">
                    <img src="${img}">
                </div>
            `;
        });
    }

    modal.classList.add("active");
}

/* ===== CLOSE MODAL ===== */
function closeModal() {
    document.getElementById("brokerModal").classList.remove("active");
}
</script>
<script>
/* ===== AUTO-HIDE DETAILS BUTTON IF NO CARDS ===== */
document.querySelectorAll('.btn-details').forEach(btn => {
    const broker = btn.dataset.broker;

    if (!brokerCards[broker]) {
        btn.style.display = 'none';
    }
});
</script>

<?php include 'includes/footer.php'; ?>
