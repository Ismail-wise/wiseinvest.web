<?php
// 1. ENABLE ERROR REPORTING (To debug white screens)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// 2. INCLUDE DATABASE & FUNCTIONS FIRST (No HTML output yet)
include 'includes/db.php';
// We do NOT include header.php here yet to avoid "Headers Already Sent" error

$error = "";
$success = "";

// 3. HANDLE FORM SUBMISSION
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Sanitize Inputs
    $fullname = $conn->real_escape_string(trim($_POST['fullname']));
    $email = $conn->real_escape_string(trim($_POST['email']));
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Basic Validation
    if (empty($fullname) || empty($email) || empty($password)) {
        $error = "Please fill in all fields.";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } elseif (strlen($password) < 6) {
        $error = "Password must be at least 6 characters.";
    } else {
        
        // Check if Email Exists
        $check = $conn->query("SELECT id FROM users WHERE email='$email'");
        if ($check->num_rows > 0) {
            $error = "This email is already registered.";
        } else {
            // Hash Password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // Default Values
            $role = 'user';
            $membership = 'free';

            // Insert User
            $stmt = $conn->prepare("INSERT INTO users (fullname, email, password, role, membership_type, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
            $stmt->bind_param("sssss", $fullname, $email, $hashed_password, $role, $membership);
            
            if ($stmt->execute()) {
                // SUCCESS: Redirect to Login
                echo "<script>alert('Account created successfully! Please login.'); window.location.href='login.php';</script>";
                exit();
            } else {
                $error = "Database Error: " . $conn->error;
            }
        }
    }
}

// 4. NOW INCLUDE THE HEADER (Visuals start here)
include 'includes/header.php'; 
?>

<div style="min-height:85vh; display:flex; align-items:center; justify-content:center; background:linear-gradient(135deg, #0f172a 0%, #1e293b 100%); padding:20px;">
    <div style="background:white; width:100%; max-width:500px; padding:40px; border-radius:16px; box-shadow:0 25px 50px rgba(0,0,0,0.25);">
        
        <div style="text-align:center; margin-bottom:30px;">
            <h2 style="font-family:'Playfair Display'; color:#0f172a; font-size:2rem; margin-bottom:5px;">Join Wise Invest</h2>
            <p style="color:#64748b;">Start your journey to financial freedom</p>
        </div>

        <?php if($error): ?>
            <div style="background:#fee2e2; color:#991b1b; padding:12px; border-radius:8px; margin-bottom:20px; font-size:0.9rem; text-align:center; border:1px solid #fecaca;">
                <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="form-group" style="margin-bottom:20px;">
                <label style="display:block; font-size:0.85rem; font-weight:700; color:#334155; margin-bottom:8px;">FULL NAME</label>
                <input type="text" name="fullname" style="width:100%; padding:12px; border:1px solid #cbd5e1; border-radius:8px; outline:none;" required value="<?php echo isset($_POST['fullname']) ? htmlspecialchars($_POST['fullname']) : ''; ?>">
            </div>

            <div class="form-group" style="margin-bottom:20px;">
                <label style="display:block; font-size:0.85rem; font-weight:700; color:#334155; margin-bottom:8px;">EMAIL ADDRESS</label>
                <input type="email" name="email" style="width:100%; padding:12px; border:1px solid #cbd5e1; border-radius:8px; outline:none;" required value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
            </div>
            
            <div class="form-group" style="margin-bottom:20px;">
                <label style="display:block; font-size:0.85rem; font-weight:700; color:#334155; margin-bottom:8px;">PASSWORD</label>
                <input type="password" name="password" style="width:100%; padding:12px; border:1px solid #cbd5e1; border-radius:8px; outline:none;" required>
            </div>

            <div class="form-group" style="margin-bottom:30px;">
                <label style="display:block; font-size:0.85rem; font-weight:700; color:#334155; margin-bottom:8px;">CONFIRM PASSWORD</label>
                <input type="password" name="confirm_password" style="width:100%; padding:12px; border:1px solid #cbd5e1; border-radius:8px; outline:none;" required>
            </div>
            
            <button type="submit" class="btn-contact" style="width:100%; border:none; cursor:pointer; padding:15px; font-size:1rem;">Create Account</button>
        </form>

        <div style="margin-top:25px; text-align:center; font-size:0.9rem; color:#64748b;">
            Already have an account? <a href="login.php" style="color:#d4af37; font-weight:700; text-decoration:none;">Log In</a>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>