<?php include 'includes/header.php'; 

// --- 1. AUTOMATION LOGIC ---
date_default_timezone_set('Asia/Bangkok');
$today = date('Y-m-d'); 

// Define your classes
$all_classes = [
    [
        'id' => 1,
        'title' => 'Stock Investment Mastery',
        'start_date' => '2025-12-15', 
        'display_date' => 'Dec 15, 2025',
        'image' => 'https://images.unsplash.com/photo-1611974765270-ca12586343bb?q=80&w=800',
        'desc' => 'Master the market fundamentals. Learn trends, picking winning stocks, and portfolio management.',
        'level' => 'Beginner',
        'duration' => '4 Weeks'
    ],
    [
        'id' => 2,
        'title' => 'Advanced Stock Investment',
        'start_date' => '2026-02-01', 
        'display_date' => 'Feb 01, 2026',
        'image' => 'https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?q=80&w=800',
        'desc' => 'Deep dive into technical analysis, options, and risk strategies for serious investors.',
        'level' => 'Advanced',
        'duration' => '6 Weeks'
    ]
];

$current_classes = [];
$upcoming_classes = [];

foreach ($all_classes as $class) {
    if ($today >= $class['start_date']) {
        $current_classes[] = $class;
    } else {
        $upcoming_classes[] = $class;
    }
}
?>

<div class="page-hero" style="height:350px;">
    <div class="hero-content">
        <h1 class="hero-title lang-en">Wise Invest Academy</h1>
        <h1 class="hero-title lang-mm" style="display:none">Wise Invest အကယ်ဒမီ</h1>
        <p class="hero-subtitle lang-en">Level up your trading skills with expert-led courses.</p>
        <p class="hero-subtitle lang-mm" style="display:none">ကျွမ်းကျင်သူများ ဦးဆောင်သော သင်တန်းများဖြင့် သင်၏ အရည်အချင်းကို မြှင့်တင်ပါ။</p>
    </div>
</div>

<section class="courses-section">
    
    <div class="class-section-header">
        <h2 class="lang-en">Live Classes</h2>
        <h2 class="lang-mm" style="display:none">လက်ရှိ သင်တန်းများ</h2>
        <p style="color:#64748b;">Happening right now. Join the action.</p>
    </div>

    <?php if (empty($current_classes)): ?>
        <div class="empty-state-box">
            <i class="far fa-clock"></i>
            <h4 class="lang-en">No classes currently in session.</h4>
            <h4 class="lang-mm" style="display:none">လောလောဆယ် ဖွင့်လှစ်ထားသော သင်တန်းမရှိပါ။</h4>
            <p>Check out our upcoming schedule below.</p>
        </div>
    <?php else: ?>
        <div class="course-grid">
            <?php foreach ($current_classes as $class): ?>
                <div class="course-card">
                    <div class="course-thumb" style="background-image: url('<?php echo $class['image']; ?>');">
                        <span class="status-badge badge-live">LIVE NOW</span>
                    </div>
                    <div class="course-body">
                        <div class="class-date-float">
                            <i class="far fa-play-circle"></i> Started: <?php echo $class['display_date']; ?>
                        </div>
                        
                        <h3 class="course-title"><?php echo $class['title']; ?></h3>
                        <p class="course-desc"><?php echo $class['desc']; ?></p>
                        
                        <div class="course-chips">
                            <span class="chip"><i class="fas fa-layer-group"></i> <?php echo $class['level']; ?></span>
                            <span class="chip"><i class="far fa-clock"></i> <?php echo $class['duration']; ?></span>
                        </div>

                        <a href="contact.php?course=<?php echo urlencode($class['title']); ?>" class="btn-course-glow">
                            Join Session <i class="fas fa-arrow-right" style="margin-left:5px;"></i>
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>


    <div style="height: 100px;"></div>


    <div class="class-section-header">
        <h2 class="lang-en">Upcoming Intakes</h2>
        <h2 class="lang-mm" style="display:none">ဖွင့်လှစ်မည့် သင်တန်းများ</h2>
        <p style="color:#64748b;">Secure your spot before seats fill up.</p>
    </div>

    <?php if (empty($upcoming_classes)): ?>
        <div class="empty-state-box">
            <p>No upcoming classes scheduled yet.</p>
        </div>
    <?php else: ?>
        <div class="course-grid">
            <?php foreach ($upcoming_classes as $class): 
                // Calculate Days Left
                $start = new DateTime($class['start_date']);
                $now = new DateTime($today);
                $days_left = $now->diff($start)->days;
            ?>
                <div class="course-card">
                    <div class="course-thumb" style="background-image: url('<?php echo $class['image']; ?>');">
                        <span class="status-badge badge-upcoming">Enroll Open</span>
                    </div>
                    <div class="course-body">
                        <div class="class-date-float" style="background:#0f172a;">
                            <i class="far fa-calendar-alt"></i> Starts: <?php echo $class['display_date']; ?>
                        </div>
                        
                        <h3 class="course-title"><?php echo $class['title']; ?></h3>
                        <p class="course-desc"><?php echo $class['desc']; ?></p>
                        
                        <div class="course-chips">
                            <span class="chip"><i class="fas fa-layer-group"></i> <?php echo $class['level']; ?></span>
                            <span class="chip"><i class="far fa-clock"></i> <?php echo $class['duration']; ?></span>
                        </div>

                        <a href="contact.php?course=<?php echo urlencode($class['title']); ?>" class="btn-course-glow" style="background:white; color:#0f172a; border:2px solid #0f172a;">
                            Register - <?php echo $days_left; ?> Days Left
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

</section>

<?php include 'includes/footer.php'; ?>