<?php
include 'includes/header.php';
include 'includes/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$is_premium = isset($_SESSION['membership_type']) && $_SESSION['membership_type'] === 'premium';

// Category filter
$cat = isset($_GET['cat']) ? (int)$_GET['cat'] : 0;

// Pagination
$per_page = 9;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;

// Build WHERE
$where = "WHERE video_type='premium'";
if ($cat > 0) $where .= " AND folder_id=$cat";

// Count
$count = $conn->query("SELECT COUNT(*) total FROM premium_content $where")
              ->fetch_assoc()['total'];
$total_pages = max(1, ceil($count / $per_page));
if ($page > $total_pages) $page = $total_pages;

$offset = ($page - 1) * $per_page;

// Fetch videos
$videos = $conn->query("
    SELECT * FROM premium_content
    $where
    ORDER BY folder_id, id DESC
    LIMIT $per_page OFFSET $offset
");

// Categories
$cats = $conn->query("SELECT * FROM video_folders ORDER BY name ASC");
?>

<section class="premium-gallery">

<header class="gallery-header">
    <h1>🎬 Premium Video Library</h1>
    <p>Advanced strategies, exclusive lessons & deep insights</p>

    <div class="filter-bar">
        <a href="premium-videos.php" class="<?= $cat==0?'active':'' ?>">All</a>
        <?php while($c=$cats->fetch_assoc()): ?>
            <a href="?cat=<?= $c['id'] ?>" class="<?= $cat==$c['id']?'active':'' ?>">
                <?= htmlspecialchars($c['name']) ?>
            </a>
        <?php endwhile; ?>
    </div>
</header>

<?php if ($videos && $videos->num_rows > 0): ?>
<div class="video-grid">

<?php while($v=$videos->fetch_assoc()):

    // ✅ FIXED LOCK LOGIC (ADMIN CONTROL ONLY)
    $locked = ((int)$v['is_locked'] === 1);

    $url = $v['video_url'];

    // Detect YouTube
    $yt = '';
    if (preg_match('~(youtu\.be/|v=)([^&?/]+)~', $url, $m)) {
        $yt = $m[2];
        $thumb = "https://img.youtube.com/vi/$yt/hqdefault.jpg";
    }
?>

<div class="video-card <?= $locked?'locked':'' ?>"
<?php if(!$locked && $yt): ?>
onclick="this.innerHTML='<iframe src=https://www.youtube.com/embed/<?= $yt ?>?autoplay=1 allowfullscreen></iframe>'"
<?php endif; ?>
>

<?php if ($yt): ?>
    <img src="<?= $thumb ?>" alt="">
<?php else: ?>
    <blockquote class="tiktok-embed"
        cite="<?= htmlspecialchars($url) ?>"
        data-video-id="<?= basename($url) ?>">
        <section><a href="<?= htmlspecialchars($url) ?>">Loading…</a></section>
    </blockquote>
<?php endif; ?>

<?php if ($locked): ?>
    <div class="lock-overlay">
        <div class="lock-box">
            <div class="lock-icon">🔒</div>
            <h3>Premium Strategy</h3>
            <p>This lesson reveals advanced methods used by experienced traders.</p>
            <a href="upgrade.php" class="unlock-btn">Unlock Full Access</a>
            <small>✔ Lifetime access for members</small>
        </div>
    </div>
<?php else: ?>
    <span class="play-btn">▶</span>
<?php endif; ?>

</div>

<?php endwhile; ?>
</div>
<?php else: ?>
<p class="empty">No premium videos yet.</p>
<?php endif; ?>

<?php if ($total_pages > 1): ?>
<div class="pagination">
<?php for($p=1;$p<=$total_pages;$p++): ?>
    <a href="?page=<?= $p ?><?= $cat?'&cat='.$cat:'' ?>"
       class="<?= $p==$page?'active':'' ?>">
        <?= $p ?>
    </a>
<?php endfor; ?>
</div>
<?php endif; ?>

</section>

<script async src="https://www.tiktok.com/embed.js"></script>

<style>
/* ===== PREMIUM GALLERY ===== */
body { background:#020617; }

.premium-gallery {
    padding:60px 20px;
    min-height:100vh;
}

.gallery-header {
    text-align:center;
    margin-bottom:40px;
}

.gallery-header h1 {
    color:#fff;
    font-size:2.4rem;
}

.gallery-header p {
    color:#94a3b8;
}

.filter-bar {
    margin-top:20px;
    display:flex;
    gap:10px;
    justify-content:center;
    flex-wrap:wrap;
}

.filter-bar a {
    padding:8px 18px;
    border-radius:999px;
    border:1px solid #1e293b;
    color:#cbd5f5;
    text-decoration:none;
    transition:.25s;
}

.filter-bar a.active,
.filter-bar a:hover {
    background:#facc15;
    color:#000;
}

/* GRID */
.video-grid {
    max-width:1300px;
    margin:0 auto;
    display:grid;
    grid-template-columns:repeat(auto-fill,minmax(320px,1fr));
    gap:26px;
}

/* CARD */
.video-card {
    position:relative;
    border-radius:22px;
    overflow:hidden;
    cursor:pointer;
    box-shadow:0 30px 80px rgba(0,0,0,.65);
    transition:.35s;
}

.video-card:hover {
    transform:translateY(-10px) scale(1.015);
    box-shadow:0 40px 90px rgba(250,204,21,.45);
}

.video-card img,
.video-card iframe,
.video-card blockquote {
    width:100%;
    aspect-ratio:16/9;
    object-fit:cover;
    border:none;
}

/* PLAY */
.play-btn {
    position:absolute;
    inset:0;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:3.5rem;
    color:#facc15;
    background:rgba(0,0,0,.35);
}

/* LOCKED */
.locked img,
.locked iframe,
.locked blockquote {
    filter:blur(7px) brightness(.7);
    transform:scale(1.05);
}

.lock-overlay {
    position:absolute;
    inset:0;
    background:radial-gradient(circle at top, rgba(2,6,23,.55), rgba(2,6,23,.9));
    display:flex;
    align-items:center;
    justify-content:center;
}

.lock-box {
    background:rgba(2,6,23,.75);
    padding:26px;
    border-radius:18px;
    max-width:260px;
    text-align:center;
    backdrop-filter:blur(12px);
    animation:fadeUp .6s ease;
}

.lock-icon {
    font-size:2.8rem;
    margin-bottom:8px;
}

.lock-box h3 {
    color:#facc15;
    margin-bottom:8px;
}

.lock-box p {
    color:#cbd5f5;
    font-size:.85rem;
    margin-bottom:14px;
}

.unlock-btn {
    display:inline-block;
    padding:10px 18px;
    border-radius:999px;
    background:linear-gradient(135deg,#facc15,#f97316);
    color:#000;
    font-weight:700;
    text-decoration:none;
    transition:.25s;
}

.unlock-btn:hover {
    transform:translateY(-2px);
    box-shadow:0 10px 30px rgba(250,204,21,.5);
}

.lock-box small {
    display:block;
    margin-top:10px;
    font-size:.7rem;
    color:#94a3b8;
}

/* PAGINATION */
.pagination {
    margin-top:40px;
    display:flex;
    justify-content:center;
    gap:8px;
}

.pagination a {
    padding:8px 14px;
    border-radius:8px;
    border:1px solid #1e293b;
    color:#cbd5f5;
    text-decoration:none;
}

.pagination a.active {
    background:#facc15;
    color:#000;
}

/* EMPTY */
.empty {
    text-align:center;
    color:#94a3b8;
    margin-top:60px;
}

/* ANIMATION */
@keyframes fadeUp {
    from { opacity:0; transform:translateY(14px); }
    to { opacity:1; transform:none; }
}
</style>

<?php include 'includes/footer.php'; ?>