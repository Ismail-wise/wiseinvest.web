<footer>
    <div class="footer-top">
        
        <div class="footer-col f-brand">
            <h3 class="f-head">Wise Invest</h3>
            <p>Empowering global investors with professional tools, education, and community insights.</p>
            
            <div class="f-socials">
                <a href="#" class="f-social-btn"><i class="fab fa-facebook-f"></i></a>
                <a href="#" class="f-social-btn"><i class="fab fa-twitter"></i></a>
                <a href="#" class="f-social-btn"><i class="fab fa-linkedin-in"></i></a>
                <a href="#" class="f-social-btn"><i class="fab fa-youtube"></i></a>
            </div>
        </div>

        <div class="footer-col f-links">
            <h3 class="f-head">Quick Links</h3>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About Us</a></li>
                <li><a href="services.php">Services</a></li>
                <li><a href="classes.php">Master Classes</a></li>
                <li><a href="contact.php">Contact Support</a></li>
            </ul>
        </div>

        <div class="footer-col f-links">
            <h3 class="f-head">Calculator & Tools</h3>
            <ul>
                <li><a href="calculators.php">Profit Calculator</a></li>
                <li><a href="calculators.php">ROI Estimator</a></li>
                <li><a href="premium-screener.php">Market Screener</a></li>
                <li><a href="articles.php">Market News</a></li>
            </ul>
        </div>

        <div class="footer-col f-contact">
            <h3 class="f-head">Stay Updated</h3>
            
            <div class="f-contact-item">
                <i class="fas fa-map-marker-alt f-icon"></i>
                <div class="f-text">
                    <span>Office Location</span>
                    <p>Chiang Mai, Thailand</p>
                </div>
            </div>

            <form class="f-newsletter">
                <input type="email" placeholder="Enter email...">
                <button type="submit"><i class="fas fa-paper-plane"></i></button>
            </form>
        </div>

    </div>

    <div class="quote-slider-container" id="quote-slider">
        <div class="quote-slide">"Price is what you pay. Value is what you get." - Warren Buffett</div>
    </div>

    <div class="footer-bottom">
        <p>&copy; <?php echo date("Y"); ?> Wise Invest. All Rights Reserved.</p>
    </div>
</footer>

<div class="floating-widget">

    <!-- LOGIN (MOBILE FLOAT) -->
    <a href="login.php" class="float-btn btn-login-float">
        <i class="fas fa-user"></i>
        <span class="float-tooltip">Log In</span>
    </a>

    <!-- LIVE CHAT -->
    <button onclick="toggleChatBox()" class="float-btn btn-livechat">
        <i class="fas fa-comments"></i>
        <span class="float-tooltip">Live Support</span>
    </button>

    <!-- WHATSAPP -->
    <a href="https://wa.me/660933396350" target="_blank" class="float-btn btn-whatsapp">
        <i class="fab fa-whatsapp"></i>
        <span class="float-tooltip">WhatsApp Us</span>
    </a>

</div>

<div id="visitor-chat-box" style="display:none; position:fixed; bottom:100px; right:30px; width:350px; height:450px; background:white; border-radius:12px; box-shadow:0 5px 30px rgba(0,0,0,0.2); z-index:9999; border:1px solid #e2e8f0; flex-direction:column;">
    
    <div style="background:#0f172a; padding:15px; border-radius:12px 12px 0 0; color:white; display:flex; justify-content:space-between; align-items:center;">
        <span style="font-weight:700;"><i class="fas fa-headset" style="color:var(--gold); margin-right:8px;"></i> Support</span>
        <button onclick="toggleChatBox()" style="background:none; border:none; color:white; cursor:pointer;"><i class="fas fa-times"></i></button>
    </div>

    <div id="v-msg-area" style="flex:1; padding:15px; overflow-y:auto; background:#f8fafc; display:flex; flex-direction:column; gap:10px;">
        <div style="text-align:center; color:#94a3b8; font-size:0.9rem;">
            Welcome! How can we help you today?
        </div>
    </div>

    <form id="v-chat-form" style="padding:10px; border-top:1px solid #e2e8f0; display:flex;">
        <input type="text" id="v-input" placeholder="Type..." style="flex:1; border:none; outline:none; padding:10px;">
        <button type="submit" style="background:var(--gold); border:none; width:40px; border-radius:4px; cursor:pointer;"><i class="fas fa-paper-plane"></i></button>
    </form>
</div>

<?php if (basename($_SERVER['PHP_SELF']) !== 'calculators.php'): ?>
<script src="<?php echo $root; ?>/main.js?v=<?php echo time(); ?>"></script>
<?php endif; ?>

<script>
    // CHAT WIDGET LOGIC (Kept here to avoid conflicts)
    function toggleChatBox() {
        const box = document.getElementById('visitor-chat-box');
        box.style.display = (box.style.display === 'none') ? 'flex' : 'none';
        if(box.style.display === 'flex') fetchVisitorMessages();
    }

    function fetchVisitorMessages() {
        fetch('support_api.php?action=fetch')
        .then(res => res.json())
        .then(data => {
            const area = document.getElementById('v-msg-area');
            if(data.length > 0) area.innerHTML = ''; 
            data.forEach(m => {
                const style = m.sender === 'user' 
                    ? 'align-self:flex-end; background:#0f172a; color:white; border-radius:10px 10px 0 10px;' 
                    : 'align-self:flex-start; background:#e2e8f0; color:#334155; border-radius:10px 10px 10px 0;';
                area.innerHTML += `<div style="padding:8px 12px; max-width:80%; font-size:0.9rem; ${style}">${m.msg}</div>`;
            });
        });
    }

    document.getElementById('v-chat-form').addEventListener('submit', function(e){
        e.preventDefault();
        const txt = document.getElementById('v-input').value;
        if(!txt) return;
        const fd = new FormData();
        fd.append('message', txt);
        fetch('support_api.php?action=send', { method:'POST', body:fd })
        .then(() => {
            document.getElementById('v-input').value = '';
            fetchVisitorMessages();
        });
    });

    setInterval(() => {
        if(document.getElementById('visitor-chat-box').style.display === 'flex') fetchVisitorMessages();
    }, 3000);
</script>

</body>
</html>
