<?php
// header.php - FINAL VERSION WITH STOCK FILTER

// 1. SESSION & CONFIG
if (session_status() === PHP_SESSION_NONE) { session_start(); }

// LANGUAGE SWITCHING
if (isset($_GET['lang'])) {
    $_SESSION['language'] = $_GET['lang'] === 'mm' ? 'mm' : 'en';
    header('Location: ' . strtok($_SERVER['REQUEST_URI'], '?'));
    exit();
}

if (!isset($_SESSION['language'])) {
    $_SESSION['language'] = 'en';
}

// 2. ROOT PATH
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
$root = $protocol . "://" . $_SERVER['HTTP_HOST'];

// 3. DATABASE
if (file_exists('includes/db.php')) {
    include_once 'includes/db.php';
}
?>

<!DOCTYPE html>
<html lang="<?php echo htmlspecialchars($_SESSION['language'] ?? 'en'); ?>">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Wise Invest - Global Market Intelligence</title>

<link rel="icon" type="image/jpeg" href="<?php echo $root; ?>/images/logo.jpg">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Padauk:wght@400;700&display=swap" rel="stylesheet">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<link rel="stylesheet" href="<?php echo $root; ?>/style.css?v=<?php echo time(); ?>">

</head>

<body>

<div id="fb-root"></div>
<script async defer crossorigin="anonymous"
src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v19.0">
</script>

<header id="main-header">

<!-- TOP MARKET BAR -->

<div class="top-bar">

<div class="tradingview-widget-container">
<div class="tradingview-widget-container__widget"></div>

<script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js" async>
{
"symbols": [
{ "proName": "FOREXCOM:SPXUSD", "title": "S&P 500" },
{ "proName": "FOREXCOM:NSXUSD", "title": "US 100" },
{ "proName": "NASDAQ:AAPL", "title": "Apple" },
{ "proName": "NASDAQ:TSLA", "title": "Tesla" },
{ "proName": "NASDAQ:NVDA", "title": "Nvidia" },
{ "proName": "BINANCE:BTCUSDT", "title": "Bitcoin" },
{ "proName": "TVC:GOLD", "title": "Gold" }
],
"showSymbolLogo": true,
"isTransparent": true,
"displayMode": "adaptive",
"colorTheme": "dark",
"locale": "en"
}
</script>

</div>
</div>


<!-- MAIN NAV BAR -->

<div class="main-bar">

<a href="index.php" class="header-logo">
<img src="<?php echo $root; ?>/images/logo.jpg" alt="Wise Invest Logo">

<div class="logo-text">
<span class="logo-title">Wise Invest</span>

<span class="logo-subtitle lang-en">
Your Global Investing Gateway
</span>

<span class="logo-subtitle lang-mm" style="display:none;">
သင်၏ ကမ္ဘာလုံးဆိုင်ရာ ရင်းနှီးမြှုပ်နှံမှု တံခါးပေါက်
</span>

</div>
</a>


<!-- DESKTOP NAV -->

<nav class="desktop-nav">

<ul class="nav-links">

<li><a href="index.php">Home</a></li>

<li class="has-dropdown">
<a href="articles.php">Learning <i class="fas fa-chevron-down"></i></a>

<ul class="dropdown">
<li><a href="articles.php">Articles</a></li>
<li><a href="classes.php">Classes</a></li>
<li><a href="videos.php">Videos</a></li>
<li><a href="calculators.php">Calculators</a></li>
</ul>
</li>

<li><a href="community.php">Community</a></li>

<?php if(isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'premium'): ?>

<li class="has-dropdown">

<a href="#" class="premium-nav-link">
<i class="fas fa-crown"></i> Premium
<i class="fas fa-chevron-down"></i>
</a>

<ul class="dropdown">

<li><a href="glossary.php">Glossary</a></li>
<li><a href="premium-calculator.php">Calculator</a></li>
<li><a href="premium-portfolio.php">Portfolio</a></li>
<li><a href="premium-budget.php">Budget Planner</a></li>
<li><a href="premium-videos.php">Premium Videos</a></li>

<!-- NEW MENU -->
<li><a href="stock-filter.php">Stock Filter</a></li>

</ul>

</li>

<?php endif; ?>

<li><a href="services.php">Services</a></li>
<li><a href="about.php">About</a></li>
<li><a href="contact.php">Contact Us</a></li>

</ul>

</nav>


<!-- HEADER ACTIONS -->

<div class="header-actions">

<form action="quote.php" method="GET" class="header-search">

<input type="text" name="symbol" placeholder="Search Ticker..." required autocomplete="off">

<button type="submit">
<i class="fas fa-search"></i>
</button>

</form>


<button id="lang-switcher" class="lang-btn" title="Switch Language">

<i class="fas fa-globe"></i>
<span>EN</span>

</button>


<?php if(isset($_SESSION['user_id'])): ?>

<div class="user-menu has-dropdown">

<a href="#" class="user-avatar">
<?php echo substr($_SESSION['user_name'], 0, 1); ?>
</a>

<ul class="dropdown user-dropdown">

<li>
<a href="#"><strong><?php echo $_SESSION['user_name']; ?></strong></a>
</li>

<?php if(isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>

<li>
<a href="admin.php">Admin Panel</a>
</li>

<?php endif; ?>

<li>
<a href="logout.php" class="logout-link">Logout</a>
</li>

</ul>

</div>

<?php else: ?>

<a href="login.php" class="btn-login-new">Log In</a>

<?php endif; ?>

</div>


<!-- MOBILE MENU BUTTON -->

<button id="mobile-menu-toggle" class="mobile-hamburger">
<span></span>
<span></span>
<span></span>
</button>

</div>

</header>


<!-- MOBILE NAV -->

<div id="mobile-nav-container">

<div class="mobile-nav-content">

<form action="quote.php" method="GET" class="mobile-search">

<input type="text" name="symbol" placeholder="Search Ticker..." required autocomplete="off">

<button type="submit">
<i class="fas fa-search"></i>
</button>

</form>


<ul class="mobile-nav-links">

<li><a href="index.php">Home</a></li>

<li class="mobile-menu-heading lang-en">Learning</li>
<li class="mobile-menu-heading lang-mm" style="display:none;">လေ့လာရန်</li>

<li class="mobile-menu-sublink"><a href="articles.php">Articles</a></li>
<li class="mobile-menu-sublink"><a href="classes.php">Classes</a></li>
<li class="mobile-menu-sublink"><a href="videos.php">Videos</a></li>
<li class="mobile-menu-sublink"><a href="calculators.php">Calculators</a></li>

<li><a href="community.php">Community</a></li>


<?php if(isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'premium'): ?>

<li class="mobile-menu-heading premium">
<i class="fas fa-crown"></i> Premium Zone
</li>

<li class="mobile-menu-sublink"><a href="glossary.php">Glossary</a></li>
<li class="mobile-menu-sublink"><a href="premium-calculator.php">Calculator</a></li>
<li class="mobile-menu-sublink"><a href="premium-portfolio.php">Portfolio</a></li>
<li class="mobile-menu-sublink"><a href="premium-budget.php">Budget Planner</a></li>
<li class="mobile-menu-sublink"><a href="premium-videos.php">Premium Videos</a></li>

<!-- NEW MENU -->
<li class="mobile-menu-sublink"><a href="stock-filter.php">Stock Filter</a></li>

<?php endif; ?>


<li class="mobile-menu-heading lang-en">More</li>
<li class="mobile-menu-heading lang-mm" style="display:none;">အခြား</li>

<li class="mobile-menu-sublink"><a href="services.php">Services</a></li>
<li class="mobile-menu-sublink"><a href="about.php">About</a></li>
<li class="mobile-menu-sublink"><a href="contact.php">Contact Us</a></li>

</ul>


<div class="mobile-auth">

<?php if(!isset($_SESSION['user_id'])): ?>

<a href="login.php" class="btn btn-login-mobile">
Log In
</a>

<?php endif; ?>

</div>

</div>

</div>

<main>