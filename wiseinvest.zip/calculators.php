<?php
include 'includes/db.php';
include 'includes/header.php';

if (file_exists('includes/functions.php')) {
    include 'includes/functions.php';
}

if (isset($_GET['get_stock_data'])) {
    ob_clean();
    $ticker = $_GET['get_stock_data'];
    $data = function_exists('getStockQuote') ? getStockQuote($ticker, $conn) : ['price' => 0, 'change' => 0, 'percent' => 0];
    echo json_encode($data);
    exit();
}
?>
input, button{
  font-size:16px; /* prevents iOS zoom */
}
<style>
/* ==========================================================
   PREMIUM FINTECH CALCULATORS (ALL 11)
   - Stripe/Revolut style card (sharp, top highlight)
   - Revolut flat inputs (high contrast, readable)
   - Live auto-calc (debounced)
   - Particle background + mouse-follow glow
   - Animated numeric counter on results
   - No charts
   ========================================================== */

:root{
  --ink:#F4F7FF;
  --muted:rgba(244,247,255,.72);
  --muted2:rgba(244,247,255,.58);

  --bg1:#070a12;
  --bg2:#0b1224;

  --line:rgba(255,255,255,.14);
  --line2:rgba(255,255,255,.10);

  --cyan:#6ee7ff;
  --violet:#a78bfa;
  --gold: var(--gold, #d4af37);

  --radius:18px;
  --radius2:12px;

  --shadow: 0 18px 55px rgba(0,0,0,.60);
  --focusRing: 0 0 0 4px rgba(110,231,255,.16);
}

/* ===== Shell + FX layers ===== */
.calc-shell{
  position:relative;
  min-height:100dvh;          /* mobile-safe viewport */
  overflow-x:hidden;          /* allow vertical scroll */
  overflow-y:auto;            /* ✅ IMPORTANT */
  background:
    radial-gradient(900px 320px at 15% 10%, rgba(110,231,255,.08), transparent 60%),
    radial-gradient(900px 320px at 85% 18%, rgba(167,139,250,.08), transparent 60%),
    radial-gradient(900px 360px at 50% 110%, rgba(212,175,55,.06), transparent 65%),
    linear-gradient(180deg,var(--bg1),var(--bg2));
}

#cw-particles{
  position:absolute;
  inset:0;
  z-index:0;
  opacity:.22;
  pointer-events:none;
}

#cw-glow{
  position:absolute;
  inset:-220px;
  z-index:0;
  pointer-events:none;
  opacity:.50;
  mix-blend-mode:screen;
  background: radial-gradient(380px 380px at 50% 50%,
      rgba(110,231,255,.18),
      rgba(167,139,250,.08) 40%,
      transparent 66%);
  transform: translate3d(0,0,0);
}

.calc-hero,.calc-nav-wrapper,.calc-dashboard{
  position:relative;
  z-index:1;
}

/* ===== Hero ===== */
.calc-hero{
  padding:62px 5% 42px;
  text-align:center;
  color:var(--ink);
  border-bottom:1px solid rgba(255,255,255,.10);
}
.calc-hero h1{
  margin:0 0 8px;
  font-size:2.55rem;
  font-family:'Playfair Display', serif;
  letter-spacing:.2px;
}
.calc-hero p{
  margin:0;
  color:var(--muted);
  font-weight:600;
}

/* ===== Tabs ===== */
.calc-nav-wrapper{
  position:sticky;
  top:var(--header-offset,105px);
  z-index:2;
  padding:14px 5%;
  background:rgba(10,14,26,.90);
  border-bottom:1px solid rgba(255,255,255,.10);
  backdrop-filter: blur(6px);
}
@media (max-width: 768px){
  :root{ --header-offset: 72px; } /* mobile header height */
}
.calc-tabs{
  display:flex;
  flex-wrap:wrap;
  justify-content:center;
  gap:10px;
  max-width:1200px;
  margin:0 auto;
}
.calc-tab-btn{
  padding:9px 14px;
  border-radius:999px;
  border:1px solid rgba(255,255,255,.15);
  background:rgba(255,255,255,.06);
  color:var(--muted);
  font-weight:800;
  letter-spacing:.15px;
  cursor:pointer;
  transition:transform .14s ease, background .14s ease, border-color .14s ease, color .14s ease, box-shadow .14s ease;
  user-select:none;
}
.calc-tab-btn:hover{
  transform: translateY(-1px);
  color:#fff;
  background:rgba(255,255,255,.09);
  border-color: rgba(110,231,255,.26);
  box-shadow: 0 10px 22px rgba(0,0,0,.35);
}
.calc-tab-btn.active{
  background:linear-gradient(90deg,rgba(110,231,255,.18),rgba(167,139,250,.14));
  border-color: rgba(110,231,255,.42);
  color:#fff;
  box-shadow: 0 0 0 1px rgba(110,231,255,.14) inset;
}

/* ===== Dashboard ===== */
.calc-dashboard{
  padding:40px 5% 76px;
  display:flex;
  justify-content:center;
}

/* ===== Workspace card (Stripe/Revolut style: sharp, less gradient) ===== */
.calc-workspace{
  width:100%;
  max-width: 920px;
  padding: 30px;
  background: rgba(10,14,26,.88);
  border: 1px solid var(--line);
  border-radius: var(--radius);
  box-shadow: var(--shadow);
  color: var(--ink);
  position: relative;
  overflow:hidden;

  display:none !important;
  opacity:0;
  transform: translateY(10px);
  transition: opacity .18s ease, transform .18s ease;
}

/* Top highlight bar */
.calc-workspace::before{
  content:"";
  position:absolute;
  left:14px;
  right:14px;
  top:12px;
  height:3px;
  border-radius:999px;
  background: linear-gradient(90deg,
    rgba(110,231,255,.95),
    rgba(167,139,250,.85),
    rgba(212,175,55,.50)
  );
  box-shadow: 0 0 16px rgba(110,231,255,.18);
  pointer-events:none;
}

/* Crisp inner ring */
.calc-workspace::after{
  content:"";
  position:absolute;
  inset:0;
  border-radius: var(--radius);
  box-shadow: 0 0 0 1px rgba(255,255,255,.08) inset,
              0 12px 60px rgba(0,0,0,.35) inset;
  pointer-events:none;
}

.calc-workspace.active{
  display:block !important;
  opacity:1;
  transform: translateY(0);
  animation: cwReveal .24s ease;
}
@keyframes cwReveal{
  from{ opacity:0; transform: translateY(14px); }
  to{ opacity:1; transform: translateY(0); }
}

/* ===== Typography ===== */
.cw-header{ text-align:center; margin-bottom:18px; }
.cw-title{
  margin:0 0 6px;
  font-family:'Playfair Display', serif;
  font-size: 1.9rem;
  color: var(--ink);
}
.cw-desc{
  margin:0;
  color: var(--muted);
  font-weight:600;
}

/* ===== Form grid ===== */
.cw-grid{
  display:grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap:14px;
  margin-top: 18px;
}
@media (max-width: 700px){
  .cw-grid{ grid-template-columns: 1fr; }
}

/* ===== Revolut flat inputs (high contrast) ===== */
.cw-label{
  display:block;
  margin-bottom: 8px;
  font-weight: 900;
  font-size: .92rem;
  color: rgba(244,247,255,.92);
  letter-spacing: .18px;
}

.cw-input{
  width:100%;
  height: 46px;
  padding: 0 14px;
  border-radius: var(--radius2);

  border: 1px solid rgba(255,255,255,.18);
  background: rgba(255,255,255,.06); /* flat */
  color: #fff;
  font-size: 1rem;

  outline: none;
  transition: border-color .14s ease, box-shadow .14s ease, background .14s ease;
  -webkit-appearance: none;
  appearance: none;
}

.cw-input::placeholder{
  color: rgba(255,255,255,.58);
}

.cw-input:focus{
  border-color: rgba(110,231,255,.65);
  background: rgba(255,255,255,.08);
  box-shadow: var(--focusRing);
}

.cw-input.cw-invalid{
  border-color: rgba(239,68,68,.9);
  box-shadow: 0 0 0 4px rgba(239,68,68,.14);
  animation: cwShake .28s ease;
}
@keyframes cwShake{
  0%{ transform: translateX(0); }
  25%{ transform: translateX(-4px); }
  50%{ transform: translateX(4px); }
  75%{ transform: translateX(-3px); }
  100%{ transform: translateX(0); }
}

/* ===== Actions ===== */
.cw-actions{
  display:flex;
  gap:10px;
  margin-top: 16px;
}
.cw-actions .btn-primary{ flex:1; }

.btn-primary{
  height: 46px;
  border-radius: var(--radius2);
  border: 0;
  cursor:pointer;
  font-weight: 1000;
  letter-spacing: .2px;
  color: #071018;
  background: linear-gradient(90deg, rgba(110,231,255,.95), rgba(167,139,250,.85));
  box-shadow: 0 10px 26px rgba(0,0,0,.35);
  transition: transform .14s ease, filter .14s ease, box-shadow .14s ease;
}
.btn-primary:hover{
  transform: translateY(-1px);
  filter: brightness(1.05);
  box-shadow: 0 16px 34px rgba(0,0,0,.45);
}
.btn-primary:active{ transform: translateY(1px) scale(.99); }

.btn-ghost{
  width: 130px;
  height: 46px;
  border-radius: var(--radius2);
  border: 1px solid rgba(255,255,255,.18);
  background: rgba(255,255,255,.06);
  color: rgba(244,247,255,.92);
  cursor:pointer;
  font-weight: 1000;
  transition: background .14s ease, border-color .14s ease, transform .14s ease;
}
.btn-ghost:hover{
  background: rgba(255,255,255,.09);
  border-color: rgba(110,231,255,.28);
}
.btn-ghost:active{ transform: translateY(1px) scale(.99); }

/* ===== Results ===== */
.cw-result{
  margin-top: 16px;
  padding: 16px;
  border-radius: var(--radius2);
  border: 1px solid rgba(255,255,255,.14);
  background: rgba(0,0,0,.35);
  text-align:center;

  display:none;
  opacity:0;
  transform: translateY(8px);
  transition: opacity .18s ease, transform .18s ease;
}
.cw-result.show{
  display:block;
  opacity:1;
  transform: translateY(0);
}
.cw-result strong{
  display:inline-block;
  font-size: 1.55rem;
  color: #fff;
  letter-spacing: .2px;
}
.cw-sub{
  display:block;
  margin-top: 6px;
  color: var(--muted2);
  font-size: .95rem;
}

@media (max-width: 520px){
  .calc-nav-wrapper{ top: 78px; }
  .calc-workspace{ padding: 20px; border-radius: 16px; }
  .cw-title{ font-size: 1.55rem; }
}

/* Reduced motion */
@media (prefers-reduced-motion: reduce){
  #cw-particles, #cw-glow{ display:none; }
  .calc-tab-btn, .calc-workspace, .cw-input, .btn-primary, .btn-ghost, .cw-result { transition:none !important; }
  .cw-input.cw-invalid{ animation:none !important; }
}
</style>

<div class="calc-shell" id="calc-shell">
  <canvas id="cw-particles"></canvas>
  <div id="cw-glow" aria-hidden="true"></div>

  <div class="calc-hero">
    <h1>Investment Tools</h1>
    <p>Premium fintech calculators • readable • fast • auto-calculating</p>
  </div>

  <div class="calc-nav-wrapper">
    <div class="calc-tabs">
      <button type="button" class="calc-tab-btn active" onclick="switchCalc('freedom', this)">Fin. Freedom</button>
      <button type="button" class="calc-tab-btn" onclick="switchCalc('hist', this)">Historical</button>
      <button type="button" class="calc-tab-btn" onclick="switchCalc('future', this)">Future Wealth</button>
      <button type="button" class="calc-tab-btn" onclick="switchCalc('roi', this)">ROI</button>
      <button type="button" class="calc-tab-btn" onclick="switchCalc('pl', this)">Profit/Loss</button>
      <button type="button" class="calc-tab-btn" onclick="switchCalc('be', this)">Break-Even</button>
      <button type="button" class="calc-tab-btn" onclick="switchCalc('ci', this)">Compound</button>
      <button type="button" class="calc-tab-btn" onclick="switchCalc('sip', this)">SIP</button>
      <button type="button" class="calc-tab-btn" onclick="switchCalc('rr', this)">Risk Ratio</button>
      <button type="button" class="calc-tab-btn" onclick="switchCalc('cagr', this)">CAGR</button>
      <button type="button" class="calc-tab-btn" onclick="switchCalc('div', this)">Dividend</button>
    </div>
  </div>

  <section class="calc-dashboard">

    <!-- 1) Financial Freedom -->
    <div class="calc-workspace active" id="calc-freedom">
      <div class="cw-header">
        <h2 class="cw-title">Financial Freedom</h2>
        <p class="cw-desc">Freedom number using monthly expenses and safe withdrawal rate (SWR).</p>
      </div>

      <div class="cw-grid">
        <div>
          <label class="cw-label">Monthly Expenses ($)</label>
          <input class="cw-input" type="number" step="any" id="ff-expenses" placeholder="e.g., 2000">
        </div>
        <div>
          <label class="cw-label">Safe Withdrawal Rate (%)</label>
          <input class="cw-input" type="number" step="any" id="ff-swr" placeholder="e.g., 4">
        </div>
        <div>
          <label class="cw-label">Current Invested Assets ($) (optional)</label>
          <input class="cw-input" type="number" step="any" id="ff-assets" placeholder="e.g., 50000">
        </div>
        <div>
          <label class="cw-label">Expected Annual Return (%) (optional)</label>
          <input class="cw-input" type="number" step="any" id="ff-return" placeholder="e.g., 8">
        </div>
      </div>

      <div class="cw-actions">
        <button class="btn-primary" type="button" data-calc="freedom">Calculate</button>
        <button class="btn-ghost" type="button" data-reset="ff">Reset</button>
      </div>

      <div class="cw-result" id="ff-result"></div>
    </div>

    <!-- 2) Historical -->
    <div class="calc-workspace" id="calc-hist">
      <div class="cw-header">
        <h2 class="cw-title">Historical Growth</h2>
        <p class="cw-desc">Initial investment compounded over time.</p>
      </div>

      <div class="cw-grid">
        <div>
          <label class="cw-label">Initial Investment ($)</label>
          <input class="cw-input" type="number" step="any" id="hist-initial" placeholder="e.g., 1000">
        </div>
        <div>
          <label class="cw-label">Annual Rate (%)</label>
          <input class="cw-input" type="number" step="any" id="hist-rate" placeholder="e.g., 10">
        </div>
        <div>
          <label class="cw-label">Years</label>
          <input class="cw-input" type="number" step="1" id="hist-years" placeholder="e.g., 10">
        </div>
        <div>
          <label class="cw-label">Compounds / Year (optional)</label>
          <input class="cw-input" type="number" step="1" id="hist-comp" placeholder="e.g., 1">
        </div>
      </div>

      <div class="cw-actions">
        <button class="btn-primary" type="button" data-calc="historical">Calculate</button>
        <button class="btn-ghost" type="button" data-reset="hist">Reset</button>
      </div>

      <div class="cw-result" id="hist-result"></div>
    </div>

    <!-- 3) Future Wealth -->
    <div class="calc-workspace" id="calc-future">
      <div class="cw-header">
        <h2 class="cw-title">Future Wealth</h2>
        <p class="cw-desc">Initial + monthly contributions with monthly compounding.</p>
      </div>

      <div class="cw-grid">
        <div>
          <label class="cw-label">Initial Investment ($)</label>
          <input class="cw-input" type="number" step="any" id="fut-initial" placeholder="e.g., 5000">
        </div>
        <div>
          <label class="cw-label">Monthly Contribution ($)</label>
          <input class="cw-input" type="number" step="any" id="fut-monthly" placeholder="e.g., 200">
        </div>
        <div>
          <label class="cw-label">Annual Rate (%)</label>
          <input class="cw-input" type="number" step="any" id="fut-rate" placeholder="e.g., 8">
        </div>
        <div>
          <label class="cw-label">Years</label>
          <input class="cw-input" type="number" step="1" id="fut-years" placeholder="e.g., 15">
        </div>
      </div>

      <div class="cw-actions">
        <button class="btn-primary" type="button" data-calc="future">Calculate</button>
        <button class="btn-ghost" type="button" data-reset="fut">Reset</button>
      </div>

      <div class="cw-result" id="fut-result"></div>
    </div>

    <!-- 4) ROI -->
    <div class="calc-workspace" id="calc-roi">
      <div class="cw-header">
        <h2 class="cw-title">ROI</h2>
        <p class="cw-desc">Return on investment from initial and current value.</p>
      </div>

      <div class="cw-grid">
        <div>
          <label class="cw-label">Initial Value ($)</label>
          <input class="cw-input" type="number" step="any" id="roi-initial" placeholder="e.g., 1000">
        </div>
        <div>
          <label class="cw-label">Current Value ($)</label>
          <input class="cw-input" type="number" step="any" id="roi-current" placeholder="e.g., 1250">
        </div>
      </div>

      <div class="cw-actions">
        <button class="btn-primary" type="button" data-calc="roi">Calculate</button>
        <button class="btn-ghost" type="button" data-reset="roi">Reset</button>
      </div>

      <div class="cw-result" id="roi-result"></div>
    </div>

    <!-- 5) Profit / Loss -->
    <div class="calc-workspace" id="calc-pl">
      <div class="cw-header">
        <h2 class="cw-title">Profit / Loss</h2>
        <p class="cw-desc">Net P/L based on buy, sell, quantity and fees.</p>
      </div>

      <div class="cw-grid">
        <div>
          <label class="cw-label">Buy Price ($)</label>
          <input class="cw-input" type="number" step="any" id="pl-buy" placeholder="e.g., 10">
        </div>
        <div>
          <label class="cw-label">Sell Price ($)</label>
          <input class="cw-input" type="number" step="any" id="pl-sell" placeholder="e.g., 12">
        </div>
        <div>
          <label class="cw-label">Quantity</label>
          <input class="cw-input" type="number" step="any" id="pl-qty" placeholder="e.g., 100">
        </div>
        <div>
          <label class="cw-label">Fees ($)</label>
          <input class="cw-input" type="number" step="any" id="pl-fees" placeholder="e.g., 5">
        </div>
      </div>

      <div class="cw-actions">
        <button class="btn-primary" type="button" data-calc="pl">Calculate</button>
        <button class="btn-ghost" type="button" data-reset="pl">Reset</button>
      </div>

      <div class="cw-result" id="pl-result"></div>
    </div>

    <!-- 6) Break-Even -->
    <div class="calc-workspace" id="calc-be">
      <div class="cw-header">
        <h2 class="cw-title">Break-Even</h2>
        <p class="cw-desc">Break-even price including fees and extra costs.</p>
      </div>

      <div class="cw-grid">
        <div>
          <label class="cw-label">Buy Price ($)</label>
          <input class="cw-input" type="number" step="any" id="be-buy" placeholder="e.g., 10">
        </div>
        <div>
          <label class="cw-label">Quantity</label>
          <input class="cw-input" type="number" step="any" id="be-qty" placeholder="e.g., 100">
        </div>
        <div>
          <label class="cw-label">Fees ($)</label>
          <input class="cw-input" type="number" step="any" id="be-fees" placeholder="e.g., 5">
        </div>
        <div>
          <label class="cw-label">Extra Cost ($) (optional)</label>
          <input class="cw-input" type="number" step="any" id="be-extra" placeholder="e.g., 0">
        </div>
      </div>

      <div class="cw-actions">
        <button class="btn-primary" type="button" data-calc="be">Calculate</button>
        <button class="btn-ghost" type="button" data-reset="be">Reset</button>
      </div>

      <div class="cw-result" id="be-result"></div>
    </div>

    <!-- 7) Compound Interest -->
    <div class="calc-workspace" id="calc-ci">
      <div class="cw-header">
        <h2 class="cw-title">Compound Interest</h2>
        <p class="cw-desc">Initial + monthly contributions with monthly compounding.</p>
      </div>

      <div class="cw-grid">
        <div>
          <label class="cw-label">Initial ($)</label>
          <input class="cw-input" type="number" step="any" id="ci-initial" placeholder="e.g., 1000">
        </div>
        <div>
          <label class="cw-label">Monthly ($)</label>
          <input class="cw-input" type="number" step="any" id="ci-monthly" placeholder="e.g., 100">
        </div>
        <div>
          <label class="cw-label">Annual Rate (%)</label>
          <input class="cw-input" type="number" step="any" id="ci-rate" placeholder="e.g., 8">
        </div>
        <div>
          <label class="cw-label">Years</label>
          <input class="cw-input" type="number" step="1" id="ci-years" placeholder="e.g., 10">
        </div>
      </div>

      <div class="cw-actions">
        <button class="btn-primary" type="button" data-calc="ci">Calculate</button>
        <button class="btn-ghost" type="button" data-reset="ci">Reset</button>
      </div>

      <div class="cw-result" id="ci-result"></div>
    </div>

    <!-- 8) SIP -->
    <div class="calc-workspace" id="calc-sip">
      <div class="cw-header">
        <h2 class="cw-title">SIP</h2>
        <p class="cw-desc">Monthly SIP maturity (supports optional annual step-up).</p>
      </div>

      <div class="cw-grid">
        <div>
          <label class="cw-label">Monthly SIP Amount ($)</label>
          <input class="cw-input" type="number" step="any" id="sip-amount" placeholder="e.g., 200">
        </div>
        <div>
          <label class="cw-label">Annual Rate (%)</label>
          <input class="cw-input" type="number" step="any" id="sip-rate" placeholder="e.g., 10">
        </div>
        <div>
          <label class="cw-label">Years</label>
          <input class="cw-input" type="number" step="1" id="sip-years" placeholder="e.g., 15">
        </div>
        <div>
          <label class="cw-label">Step-Up %/Year (optional)</label>
          <input class="cw-input" type="number" step="any" id="sip-step" placeholder="e.g., 0">
        </div>
      </div>

      <div class="cw-actions">
        <button class="btn-primary" type="button" data-calc="sip">Calculate</button>
        <button class="btn-ghost" type="button" data-reset="sip">Reset</button>
      </div>

      <div class="cw-result" id="sip-result"></div>
    </div>

    <!-- 9) Risk / Reward -->
    <div class="calc-workspace" id="calc-rr">
      <div class="cw-header">
        <h2 class="cw-title">Risk / Reward</h2>
        <p class="cw-desc">Compare reward vs risk using entry, stop, target.</p>
      </div>

      <div class="cw-grid">
        <div>
          <label class="cw-label">Entry</label>
          <input class="cw-input" type="number" step="any" id="rr-entry" placeholder="e.g., 100">
        </div>
        <div>
          <label class="cw-label">Stop Loss</label>
          <input class="cw-input" type="number" step="any" id="rr-stop" placeholder="e.g., 95">
        </div>
        <div>
          <label class="cw-label">Target</label>
          <input class="cw-input" type="number" step="any" id="rr-target" placeholder="e.g., 115">
        </div>
        <div>
          <label class="cw-label">Position Size (optional)</label>
          <input class="cw-input" type="number" step="any" id="rr-size" placeholder="e.g., 10">
        </div>
      </div>

      <div class="cw-actions">
        <button class="btn-primary" type="button" data-calc="rr">Calculate</button>
        <button class="btn-ghost" type="button" data-reset="rr">Reset</button>
      </div>

      <div class="cw-result" id="rr-result"></div>
    </div>

    <!-- 10) CAGR -->
    <div class="calc-workspace" id="calc-cagr">
      <div class="cw-header">
        <h2 class="cw-title">CAGR</h2>
        <p class="cw-desc">Compound annual growth rate over time.</p>
      </div>

      <div class="cw-grid">
        <div>
          <label class="cw-label">Start Value ($)</label>
          <input class="cw-input" type="number" step="any" id="cagr-start" placeholder="e.g., 1000">
        </div>
        <div>
          <label class="cw-label">End Value ($)</label>
          <input class="cw-input" type="number" step="any" id="cagr-end" placeholder="e.g., 2000">
        </div>
        <div>
          <label class="cw-label">Years</label>
          <input class="cw-input" type="number" step="1" id="cagr-years" placeholder="e.g., 5">
        </div>
        <div>
          <label class="cw-label">Show Total Return? (1=yes, 0=no)</label>
          <input class="cw-input" type="number" step="1" id="cagr-show" placeholder="e.g., 1">
        </div>
      </div>

      <div class="cw-actions">
        <button class="btn-primary" type="button" data-calc="cagr">Calculate</button>
        <button class="btn-ghost" type="button" data-reset="cagr">Reset</button>
      </div>

      <div class="cw-result" id="cagr-result"></div>
    </div>

    <!-- 11) Dividend -->
    <div class="calc-workspace" id="calc-div">
      <div class="cw-header">
        <h2 class="cw-title">Dividend Yield</h2>
        <p class="cw-desc">Yield from annual dividend per share and share price.</p>
      </div>

      <div class="cw-grid">
        <div>
          <label class="cw-label">Annual Dividend / Share ($)</label>
          <input class="cw-input" type="number" step="any" id="div-amount" placeholder="e.g., 2">
        </div>
        <div>
          <label class="cw-label">Share Price ($)</label>
          <input class="cw-input" type="number" step="any" id="div-price" placeholder="e.g., 50">
        </div>
        <div>
          <label class="cw-label">Shares (optional)</label>
          <input class="cw-input" type="number" step="any" id="div-shares" placeholder="e.g., 100">
        </div>
        <div>
          <label class="cw-label">Tax Rate % (optional)</label>
          <input class="cw-input" type="number" step="any" id="div-tax" placeholder="e.g., 10">
        </div>
      </div>

      <div class="cw-actions">
        <button class="btn-primary" type="button" data-calc="div">Calculate</button>
        <button class="btn-ghost" type="button" data-reset="div">Reset</button>
      </div>

      <div class="cw-result" id="div-result"></div>
    </div>

  </section>
</div>

<script>
/* ==========================================================
   CORE UI
   ========================================================== */
function switchCalc(id, btn) {
  document.querySelectorAll('.calc-workspace').forEach(el => el.classList.remove('active'));
  document.querySelectorAll('.calc-tab-btn').forEach(el => el.classList.remove('active'));
  const target = document.getElementById('calc-' + id);
  if (target) target.classList.add('active');
  if (btn) btn.classList.add('active');

  try { history.replaceState(null, "", "#" + id); } catch(e) {}

  if (target && window.innerWidth < 900) {
    target.scrollIntoView({ behavior: "smooth", block: "start" });
  }
}

/* ==========================================================
   HELPERS + FORMAT
   ========================================================== */
const moneyFmt = new Intl.NumberFormat(undefined, { maximumFractionDigits: 2 });
const intFmt = new Intl.NumberFormat(undefined, { maximumFractionDigits: 0 });

function $(id){ return document.getElementById(id); }

function num(id){
  const el = $(id);
  if (!el) return NaN;
  const v = parseFloat(el.value);
  return Number.isFinite(v) ? v : NaN;
}

function markInvalid(ids){
  ids.forEach(id => { const el = $(id); if (el) el.classList.add("cw-invalid"); });
  setTimeout(() => ids.forEach(id => { const el = $(id); if (el) el.classList.remove("cw-invalid"); }), 650);
}

function clearResult(id){
  const box = $(id);
  if (!box) return;
  box.classList.remove("show");
  box.innerHTML = "";
}

/* ==========================================================
   ANIMATED COUNTER (for results)
   - Put value in <strong data-animate="currency|percent|number" data-value="1234.56"></strong>
   ========================================================== */
function easeOutCubic(t){ return 1 - Math.pow(1 - t, 3); }

function formatAnimated(type, value){
  if (!Number.isFinite(value)) return "—";
  if (type === "currency") return "$" + moneyFmt.format(value);
  if (type === "percent")  return value.toFixed(2) + "%";
  if (type === "number")   return moneyFmt.format(value);
  return String(value);
}

function animateCounters(container){
  if (!container) return;
  const nodes = container.querySelectorAll("strong[data-animate][data-value]");
  nodes.forEach(node => {
    const type = node.getAttribute("data-animate") || "number";
    const end = parseFloat(node.getAttribute("data-value"));
    if (!Number.isFinite(end)) {
      node.textContent = "—";
      return;
    }

    const duration = 520; // ms
    const start = 0;
    const t0 = performance.now();

    function frame(now){
      const t = Math.min(1, (now - t0) / duration);
      const k = easeOutCubic(t);
      const cur = start + (end - start) * k;
      node.textContent = formatAnimated(type, cur);
      if (t < 1) requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
  });
}

/* Unified show result helper */
function showResultBox(id, html){
  const box = $(id);
  if (!box) return;
  box.innerHTML = html;
  box.classList.add("show");
  animateCounters(box);
}

function resetByPrefix(prefix){
  document.querySelectorAll(`[id^="${prefix}-"]`).forEach(el => {
    if (el.tagName === "INPUT") el.value = "";
    el.classList.remove("cw-invalid");
  });
}

/* Debounce */
function debounce(fn, wait=260){
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), wait);
  };
}

/* ==========================================================
   CALCULATORS (11)
   ========================================================== */
function calcFreedom(){
  const monthly = num("ff-expenses");
  const swr = num("ff-swr");
  const assets = num("ff-assets");
  const ret = num("ff-return");

  if (!Number.isFinite(monthly) || !Number.isFinite(swr) || monthly <= 0 || swr <= 0){
    markInvalid(["ff-expenses","ff-swr"]);
    return showResultBox("ff-result", `Invalid input.<span class="cw-sub">Monthly expenses and SWR must be greater than 0.</span>`);
  }

  const annual = monthly * 12;
  const freedom = annual / (swr/100);

  let extra = "";
  if (Number.isFinite(assets) && assets > 0){
    const gap = Math.max(0, freedom - assets);
    extra += `<span class="cw-sub">Current assets: $${moneyFmt.format(assets)} • Gap: $${moneyFmt.format(gap)}</span>`;
    if (Number.isFinite(ret) && ret > 0 && gap > 0){
      const r = ret/100;
      const years = Math.log(freedom/assets) / Math.log(1+r);
      if (Number.isFinite(years) && years > 0){
        extra += `<span class="cw-sub">If assets grow at ${ret.toFixed(2)}%/yr (no new savings): ~${years.toFixed(1)} years</span>`;
      }
    }
  }

  showResultBox("ff-result",
    `Freedom Number: <strong data-animate="currency" data-value="${freedom}"></strong>${extra}`
  );
}

function calcHistorical(){
  const p = num("hist-initial");
  const rate = num("hist-rate");
  const y = num("hist-years");
  let m = num("hist-comp");

  if (![p,rate,y].every(Number.isFinite) || p < 0 || rate < 0 || y < 0){
    markInvalid(["hist-initial","hist-rate","hist-years"]);
    return showResultBox("hist-result", `Please fill in all fields.<span class="cw-sub">Use valid numbers.</span>`);
  }
  if (!Number.isFinite(m) || m <= 0) m = 1;

  const r = rate / 100;
  const fv = p * Math.pow(1 + (r/m), m*y);

  showResultBox("hist-result",
    `Final Value: <strong data-animate="currency" data-value="${fv}"></strong>`
  );
}

function calcFuture(){
  const p = num("fut-initial");
  const m = num("fut-monthly");
  const rate = num("fut-rate");
  const years = num("fut-years");

  if (![p,m,rate,years].every(Number.isFinite) || years < 0){
    markInvalid(["fut-initial","fut-monthly","fut-rate","fut-years"]);
    return showResultBox("fut-result", `Please fill in all fields.<span class="cw-sub">Use valid numbers.</span>`);
  }

  const r = (rate/100)/12;
  const n = Math.floor(years*12);
  let fv = p;
  for (let i=1;i<=n;i++) fv = fv*(1+r) + m;

  showResultBox("fut-result",
    `Future Value: <strong data-animate="currency" data-value="${fv}"></strong>`
  );
}

function calcROI(){
  const initial = num("roi-initial");
  const current = num("roi-current");
  if (![initial,current].every(Number.isFinite) || initial <= 0){
    markInvalid(["roi-initial","roi-current"]);
    return showResultBox("roi-result", `Invalid input.<span class="cw-sub">Initial must be greater than 0.</span>`);
  }
  const roi = ((current-initial)/initial)*100;
  showResultBox("roi-result",
    `ROI: <strong data-animate="percent" data-value="${roi}"></strong>`
  );
}

function calcPL(){
  const buy = num("pl-buy");
  const sell = num("pl-sell");
  const qty = num("pl-qty");
  const fees = num("pl-fees");
  if (![buy,sell,qty,fees].every(Number.isFinite)){
    markInvalid(["pl-buy","pl-sell","pl-qty","pl-fees"]);
    return showResultBox("pl-result", `Please fill in all fields.<span class="cw-sub">Use valid numbers.</span>`);
  }
  const pl = (sell-buy)*qty - fees;
  showResultBox("pl-result",
    `${pl>=0 ? "Net Profit" : "Net Loss"}: <strong data-animate="currency" data-value="${pl}"></strong>`
  );
}

function calcBE(){
  const buy = num("be-buy");
  const qty = num("be-qty");
  const fees = num("be-fees");
  const extra = num("be-extra");
  const ex = Number.isFinite(extra) ? extra : 0;

  if (![buy,qty,fees].every(Number.isFinite) || qty <= 0){
    markInvalid(["be-buy","be-qty","be-fees"]);
    return showResultBox("be-result", `Invalid input.<span class="cw-sub">Quantity must be greater than 0.</span>`);
  }
  const be = ((buy*qty)+fees+ex)/qty;
  showResultBox("be-result",
    `Break-Even Price: <strong data-animate="currency" data-value="${be}"></strong>`
  );
}

function calcCI(){
  const initial = num("ci-initial");
  const monthly = num("ci-monthly");
  const rate = num("ci-rate");
  const years = num("ci-years");

  if (![initial,monthly,rate,years].every(Number.isFinite) || years < 0){
    markInvalid(["ci-initial","ci-monthly","ci-rate","ci-years"]);
    return showResultBox("ci-result", `Please fill in all fields.<span class="cw-sub">Use valid numbers.</span>`);
  }
  const r = (rate/100)/12;
  const n = Math.floor(years*12);
  let fv = initial;
  for (let i=1;i<=n;i++) fv = fv*(1+r) + monthly;

  showResultBox("ci-result",
    `Final Value: <strong data-animate="currency" data-value="${fv}"></strong>`
  );
}

function calcSIP(){
  const amount = num("sip-amount");
  const rate = num("sip-rate");
  const years = num("sip-years");
  const step = num("sip-step");

  if (![amount,rate,years].every(Number.isFinite) || years < 0){
    markInvalid(["sip-amount","sip-rate","sip-years"]);
    return showResultBox("sip-result", `Please fill in all fields.<span class="cw-sub">Use valid numbers.</span>`);
  }

  const r = (rate/100)/12;
  const n = Math.floor(years*12);
  const stepPct = (Number.isFinite(step) && step > 0) ? (step/100) : 0;

  let fv = 0;
  let monthly = amount;
  for (let i=1;i<=n;i++){
    fv = fv*(1+r) + monthly;
    if (stepPct > 0 && i % 12 === 0) monthly = monthly*(1+stepPct);
  }

  showResultBox("sip-result",
    `Maturity: <strong data-animate="currency" data-value="${fv}"></strong>` +
    (stepPct>0 ? `<span class="cw-sub">Includes ${step.toFixed(2)}% yearly step-up (approx.)</span>` : ``)
  );
}

function calcRR(){
  const entry = num("rr-entry");
  const stop = num("rr-stop");
  const target = num("rr-target");

  if (![entry,stop,target].every(Number.isFinite)){
    markInvalid(["rr-entry","rr-stop","rr-target"]);
    return showResultBox("rr-result", `Please fill in all fields.<span class="cw-sub">Use valid numbers.</span>`);
  }
  const risk = Math.abs(entry-stop);
  const reward = Math.abs(target-entry);
  if (risk === 0){
    markInvalid(["rr-entry","rr-stop"]);
    return showResultBox("rr-result", `Invalid input.<span class="cw-sub">Entry and Stop cannot be the same.</span>`);
  }
  const ratio = reward/risk;

  // Animate the ratio part
  showResultBox("rr-result",
    `Risk / Reward = <strong data-animate="number" data-value="${ratio}"></strong><span class="cw-sub">Displayed as 1 : ratio</span>`
  );
}

function calcCAGR(){
  const start = num("cagr-start");
  const end = num("cagr-end");
  const years = num("cagr-years");
  const showTotal = num("cagr-show");

  if (![start,end,years].every(Number.isFinite) || start<=0 || years<=0){
    markInvalid(["cagr-start","cagr-end","cagr-years"]);
    return showResultBox("cagr-result", `Invalid input.<span class="cw-sub">Start value and years must be greater than 0.</span>`);
  }
  const cagr = (Math.pow(end/start, 1/years) - 1)*100;

  let extra = "";
  if (showTotal === 1){
    const total = ((end-start)/start)*100;
    extra = `<span class="cw-sub">Total return: ${total.toFixed(2)}%</span>`;
  }

  showResultBox("cagr-result",
    `CAGR: <strong data-animate="percent" data-value="${cagr}"></strong>${extra}`
  );
}

function calcDiv(){
  const amount = num("div-amount");
  const price = num("div-price");
  const shares = num("div-shares");
  const tax = num("div-tax");

  if (![amount,price].every(Number.isFinite) || price<=0){
    markInvalid(["div-amount","div-price"]);
    return showResultBox("div-result", `Invalid input.<span class="cw-sub">Price must be greater than 0.</span>`);
  }
  const yieldPct = (amount/price)*100;

  let extra = "";
  if (Number.isFinite(shares) && shares > 0){
    const gross = amount*shares;
    if (Number.isFinite(tax) && tax > 0){
      const net = gross*(1-tax/100);
      extra = `<span class="cw-sub">Gross: $${moneyFmt.format(gross)} • Net after ${tax.toFixed(2)}% tax: $${moneyFmt.format(net)}</span>`;
    } else {
      extra = `<span class="cw-sub">Annual dividend (gross): $${moneyFmt.format(gross)}</span>`;
    }
  }

  showResultBox("div-result",
    `Dividend Yield: <strong data-animate="percent" data-value="${yieldPct}"></strong>${extra}`
  );
}

/* ==========================================================
   LIVE AUTO-CALC (DEBOUNCED)
   ========================================================== */
const calcMap = {
  freedom: calcFreedom,
  historical: calcHistorical,
  future: calcFuture,
  roi: calcROI,
  pl: calcPL,
  be: calcBE,
  ci: calcCI,
  sip: calcSIP,
  rr: calcRR,
  cagr: calcCAGR,
  div: calcDiv
};
const liveDebounced = {};
Object.keys(calcMap).forEach(k => liveDebounced[k] = debounce(calcMap[k], 260));

function wireLive(workspaceId, calcKey){
  const ws = document.getElementById(workspaceId);
  if (!ws) return;
  ws.querySelectorAll("input").forEach(inp => {
    inp.addEventListener("input", () => liveDebounced[calcKey]());
    inp.addEventListener("change", () => liveDebounced[calcKey]());
  });
}

/* ==========================================================
   BUTTON WIRING
   ========================================================== */
function bindButtons(){
  document.querySelectorAll("[data-calc]").forEach(btn => {
    btn.addEventListener("click", () => {
      const key = btn.getAttribute("data-calc");
      if (calcMap[key]) calcMap[key]();
    });
  });

  document.querySelectorAll("[data-reset]").forEach(btn => {
    btn.addEventListener("click", () => {
      const prefix = btn.getAttribute("data-reset");
      resetByPrefix(prefix);

      const resultMap = {
        ff:"ff-result", hist:"hist-result", fut:"fut-result", roi:"roi-result", pl:"pl-result",
        be:"be-result", ci:"ci-result", sip:"sip-result", rr:"rr-result", cagr:"cagr-result", div:"div-result"
      };
      if (resultMap[prefix]) clearResult(resultMap[prefix]);
    });
  });
}

/* ==========================================================
   FX: MOUSE GLOW
   ========================================================== */
function initMouseGlow(){
  const shell = document.getElementById("calc-shell");
  const glow  = document.getElementById("cw-glow");
  if (!shell || !glow) return;

  let x = window.innerWidth * 0.5, y = 200;
  let tx = x, ty = y;

  function tick(){
    x += (tx - x) * 0.12;
    y += (ty - y) * 0.12;
    glow.style.transform = `translate3d(${x - window.innerWidth/2}px, ${y - 260}px, 0)`;
    requestAnimationFrame(tick);
  }

  function onMove(cx, cy){
    const r = shell.getBoundingClientRect();
    tx = cx - r.left;
    ty = cy - r.top + window.scrollY; // follow even while scrolling
  }

  window.addEventListener("mousemove", (e) => onMove(e.clientX, e.clientY), { passive:true });
  window.addEventListener("touchmove", (e) => {
    if (!e.touches || !e.touches[0]) return;
    onMove(e.touches[0].clientX, e.touches[0].clientY);
  }, { passive:true });

  tick();
}

/* ==========================================================
   FX: PARTICLES (SUBTLE)
   ========================================================== */
function initParticles(){
  const canvas = document.getElementById("cw-particles");
  const shell = document.getElementById("calc-shell");
  if (!canvas || !shell) return;

  const ctx = canvas.getContext("2d");
  const particles = [];
  let w = 0, h = 0;
  let dpr = Math.max(1, Math.min(2, window.devicePixelRatio || 1));
  const rand = (a,b) => a + Math.random()*(b-a);

  function makeParticle(){
    const hue = Math.random() < 0.65 ? 195 : 265;
    return {
      x: rand(0,w),
      y: rand(0,h),
      vx: rand(-0.24, 0.24),
      vy: rand(-0.24, 0.24),
      r: rand(1.1, 2.0),
      hue,
      a: rand(0.22, 0.55)
    };
  }

  function resize(){
    const rect = shell.getBoundingClientRect();
    w = Math.max(320, Math.floor(rect.width));
    h = Math.max(
  shell.scrollHeight,
  window.innerHeight * 1.2   // mobile safety
);

    dpr = Math.max(1, Math.min(2, window.devicePixelRatio || 1));
    canvas.width = Math.floor(w * dpr);
    canvas.height = Math.floor(h * dpr);
    canvas.style.width = w + "px";
    canvas.style.height = h + "px";
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    const target = Math.max(28, Math.min(90, Math.floor((w*h) / 22000)));
    while (particles.length < target) particles.push(makeParticle());
    while (particles.length > target) particles.pop();
  }

  function step(){
    ctx.clearRect(0,0,w,h);

    for (const p of particles){
      p.x += p.vx; p.y += p.vy;

      if (p.x < -20) p.x = w + 20;
      if (p.x > w + 20) p.x = -20;
      if (p.y < -20) p.y = h + 20;
      if (p.y > h + 20) p.y = -20;

      ctx.beginPath();
      ctx.fillStyle = `hsla(${p.hue}, 90%, 70%, ${p.a})`;
      ctx.arc(p.x, p.y, p.r, 0, Math.PI*2);
      ctx.fill();
    }

    const maxDist = 150;
    for (let i=0;i<particles.length;i++){
      for (let j=i+1;j<particles.length;j++){
        const a = particles[i], b = particles[j];
        const dx = a.x - b.x, dy = a.y - b.y;
        const dist = Math.hypot(dx,dy);
        if (dist < maxDist){
          const alpha = (1 - dist/maxDist) * 0.10;
          ctx.strokeStyle = `rgba(110,231,255,${alpha})`;
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(a.x,a.y);
          ctx.lineTo(b.x,b.y);
          ctx.stroke();
        }
      }
    }

    requestAnimationFrame(step);
  }

  window.addEventListener("resize", resize, { passive:true });
  resize();
  step();
}

/* ==========================================================
   BOOT
   ========================================================== */
document.addEventListener("DOMContentLoaded", () => {
  bindButtons();

  // Live auto-calc wiring
  wireLive("calc-freedom", "freedom");
  wireLive("calc-hist", "historical");
  wireLive("calc-future", "future");
  wireLive("calc-roi", "roi");
  wireLive("calc-pl", "pl");
  wireLive("calc-be", "be");
  wireLive("calc-ci", "ci");
  wireLive("calc-sip", "sip");
  wireLive("calc-rr", "rr");
  wireLive("calc-cagr", "cagr");
  wireLive("calc-div", "div");

  // FX
  initParticles();
  initMouseGlow();

  // Open from hash (#hist etc.)
  const hash = (location.hash || "").replace("#","").trim();
  if (hash){
    const btn = Array.from(document.querySelectorAll(".calc-tab-btn"))
      .find(b => (b.getAttribute("onclick") || "").includes("'" + hash + "'"));
    if (btn) switchCalc(hash, btn);
  }
});
</script>

<?php include 'includes/footer.php'; ?>