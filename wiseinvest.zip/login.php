<?php 

// 1. ENABLE ERROR REPORTING (To debug white screens)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// 2. INCLUDE HEADER (This handles Session and DB connection)
include 'includes/header.php'; 

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Use the connection from header.php ($conn)
    $email = $conn->real_escape_string($_POST['email']);
    $password = $_POST['password'];

    // Select role AND expiry date
    $stmt = $conn->prepare("SELECT id, fullname, password, membership_type, role, premium_expiry FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        
        // Verify the password
        if (password_verify($password, $user['password'])) {
            
            // --- CHECK FOR PREMIUM MEMBERSHIP EXPIRATION ---
            $membership_status = $user['membership_type']; 
            
            if ($user['membership_type'] === 'premium' && $user['premium_expiry'] !== NULL) {
                $expiry = new DateTime($user['premium_expiry']);
                $now = new DateTime();
                
                // If membership has expired, downgrade the user to 'free'
                if ($now > $expiry) {
                    $uid = $user['id'];
                    $conn->query("UPDATE users SET membership_type = 'free', premium_expiry = NULL WHERE id = $uid");
                    $membership_status = 'free'; // Update status for the current session
                }
            }
            // ------------------------------------------------

            // --- SET ALL SESSION VARIABLES AFTER SUCCESSFUL LOGIN ---
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['fullname'];
            $_SESSION['user_type'] = $membership_status; 
            
            // === THIS IS THE CRUCIAL FIX ===
            // Set the user's role (e.g., 'admin' or 'user')
            $_SESSION['role'] = $user['role'];
            
            // Redirect to the homepage
            echo "<script>window.location.href='index.php';</script>";
            exit();

        } else {
            $error = "Incorrect password.";
        }
    } else {
        $error = "No account found with this email.";
    }
}
?>

<!-- HTML for the login form -->
<div style="min-height:80vh; display:flex; align-items:center; justify-content:center; background:linear-gradient(135deg, #0f172a 0%, #1e293b 100%); padding:20px;">
    <div style="background:white; width:100%; max-width:450px; padding:40px; border-radius:16px; box-shadow:0 25px 50px rgba(0,0,0,0.25);">
        
        <div style="text-align:center; margin-bottom:30px;">
            <h2 style="font-family:'Playfair Display'; color:#0f172a; font-size:2rem; margin-bottom:5px;">Welcome Back</h2>
            <p style="color:#64748b;">Secure Login</p>
        </div>

        <?php if($error): ?>
            <div style="background:#fee2e2; color:#991b1b; padding:12px; border-radius:8px; margin-bottom:20px; font-size:0.9rem; text-align:center; border:1px solid #fecaca;">
                <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="form-group" style="margin-bottom:20px;">
                <label style="display:block; font-size:0.85rem; font-weight:700; color:#334155; margin-bottom:8px;">EMAIL ADDRESS</label>
                <input type="email" name="email" style="width:100%; padding:12px; border:1px solid #cbd5e1; border-radius:8px; outline:none;" required>
            </div>
            
            <div class="form-group" style="margin-bottom:30px;">
                <div style="display:flex; justify-content:space-between; margin-bottom:8px;">
                    <label style="font-size:0.85rem; font-weight:700; color:#334155;">PASSWORD</label>
                    <a href="#" style="font-size:0.8rem; color:#d4af37;">Forgot?</a>
                </div>
                <input type="password" name="password" style="width:100%; padding:12px; border:1px solid #cbd5e1; border-radius:8px; outline:none;" required>
            </div>
            
            <button type="submit" class="btn-contact" style="width:100%; border:none; cursor:pointer; padding:15px; font-size:1rem;">Access Account</button>
        </form>

        <div style="margin-top:25px; text-align:center; font-size:0.9rem; color:#64748b;">
            New to Wise Invest? <a href="signup.php" style="color:#d4af37; font-weight:700; text-decoration:none;">Create Account</a>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
