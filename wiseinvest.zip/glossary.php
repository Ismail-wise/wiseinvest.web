<?php 
include 'includes/db.php'; 
include 'includes/header.php'; 

// 1. SECURITY: Premium Only Check
if(!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'premium') {
    echo "<div style='padding:100px; text-align:center;'>
            <h2>Premium Access Only</h2>
            <p>Upgrade to Wise Invest Premium to access the Financial Glossary.</p>
            <a href='index.php' class='btn btn-gold' style='background:#d4af37; padding:10px 20px; border-radius:5px; color:black; text-decoration:none; font-weight:bold;'>Go Back</a>
          </div>";
    include 'includes/footer.php';
    exit();
}

// 2. SEARCH LOGIC
$search_result = null;
$search_term = "";

if (isset($_GET['term'])) {
    $search_term = $conn->real_escape_string($_GET['term']);
    $sql = "SELECT * FROM glossary WHERE term LIKE '%$search_term%' LIMIT 1";
    $result = $conn->query($sql);
    if($result && $result->num_rows > 0) {
        $search_result = $result->fetch_assoc();
    }
}

// 3. FETCH ALL TERMS (For the list)
$all_terms_res = $conn->query("SELECT term FROM glossary ORDER BY term ASC");
?>

<style>
    /* Page Specific Styles */
    .glossary-hero {
        background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
        color: white; padding: 80px 20px; text-align: center;
    }
    .search-box {
        max-width: 600px; margin: 0 auto; display: flex; gap: 10px;
    }
    .search-input {
        flex: 1; padding: 15px 25px; border-radius: 50px; border: none; outline: none; font-size: 1.1rem;
    }
    .search-btn {
        background: #d4af37; border: none; padding: 0 30px; border-radius: 50px; 
        font-weight: bold; cursor: pointer; color: #0f172a; transition: 0.3s;
    }
    .search-btn:hover { background: #b5952f; }

    /* Terms Grid */
    .terms-container {
        max-width: 1000px; margin: 50px auto; padding: 0 20px;
    }
    .term-pill {
        display: inline-block; background: white; border: 1px solid #e2e8f0;
        padding: 8px 15px; border-radius: 20px; margin: 5px;
        color: #334155; text-decoration: none; font-size: 0.9rem; transition: 0.2s;
        box-shadow: 0 2px 5px rgba(0,0,0,0.03);
    }
    .term-pill:hover {
        background: #d4af37; color: #0f172a; border-color: #d4af37; transform: translateY(-2px);
    }
    .term-pill.active {
        background: #0f172a; color: #d4af37; border-color: #0f172a;
    }
</style>

<div class="glossary-hero">
    <h1 style="font-family:'Playfair Display'; font-size:3rem; margin-bottom:10px; color:#d4af37;">Financial Glossary</h1>
    <p style="color:#94a3b8; margin-bottom:40px;">Master the language of money. Search for definitions & formulas.</p>
    
    <form action="glossary.php" method="GET" class="search-box">
        <input type="text" name="term" value="<?php echo htmlspecialchars($search_term); ?>" class="search-input" placeholder="Search term (e.g. CAGR)...">
        <button type="submit" class="search-btn">Search</button>
    </form>
</div>

<?php if($search_result): ?>
<div style="max-width:800px; margin: -30px auto 50px auto; position: relative; z-index: 10;">
    <div style="background:white; padding:40px; border-radius:16px; box-shadow:0 10px 30px rgba(0,0,0,0.1); border-top:5px solid #d4af37;">
        <h2 style="font-size:2.5rem; margin-top:0; color:#0f172a;"><?php echo $search_result['term']; ?></h2>
        
        <p style="font-size:1.1rem; line-height:1.8; color:#334155; margin-bottom:30px;">
            <?php echo nl2br(htmlspecialchars($search_result['definition'])); ?>
        </p>

        <?php if(!empty($search_result['equation'])): ?>
            <div style="background:#f8fafc; padding:20px; border-radius:8px; text-align:center; border:1px dashed #cbd5e1;">
                <strong style="display:block; color:#94a3b8; margin-bottom:10px; font-size:0.8rem; letter-spacing:1px;">EQUATION</strong>
                <span style="font-size:1.4rem; font-family:'Courier New', monospace; font-weight:bold; color:#0f172a;">
                    <?php echo $search_result['equation']; ?>
                </span>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php elseif($search_term != ""): ?>
    <div style="text-align:center; padding:50px; color:#94a3b8;">
        <i class="fas fa-search" style="font-size:3rem; margin-bottom:20px;"></i>
        <h3>Term not found</h3>
        <p>Try browsing the list below.</p>
    </div>
<?php endif; ?>

<div class="terms-container">
    <h3 style="text-align:center; color:#0f172a; margin-bottom:30px; font-family:'Playfair Display';">Browse All Terms</h3>
    
    <div style="text-align:center;">
        <?php if($all_terms_res && $all_terms_res->num_rows > 0): ?>
            <?php while($t = $all_terms_res->fetch_assoc()): ?>
                <a href="glossary.php?term=<?php echo urlencode($t['term']); ?>" 
                   class="term-pill <?php echo ($search_term === $t['term']) ? 'active' : ''; ?>">
                    <?php echo htmlspecialchars($t['term']); ?>
                </a>
            <?php endwhile; ?>
        <?php else: ?>
            <p style="color:#94a3b8;">No terms added yet.</p>
        <?php endif; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>