<?php

// 1. SETUP & SECURITY
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'includes/db.php';
if (session_status() === PHP_SESSION_NONE) { session_start(); }
include 'includes/header.php';

if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    echo "<script>window.location.href='index.php';</script>";
    exit();
}

// 2. HANDLE ACTIONS
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // --- VIDEO LOCK / UNLOCK ---
    if (isset($_POST['toggle_lock'])) {
        $vid = intval($_POST['video_id']);
        $state = intval($_POST['lock_state']); // 1 = lock, 0 = unlock
        $conn->query("UPDATE premium_content SET is_locked = $state WHERE id = $vid");
    }

    // --- USERS: UPGRADE / CHANGE DURATION ---
    if (isset($_POST['upgrade_user'])) {
        $uid = intval($_POST['user_id']);
        $duration = $_POST['duration'];
        $expiry = NULL;

        // Calculate Expiry Date
        if ($duration !== 'life') {
            $date_string = '+1 month';
            if ($duration === '3m') $date_string = '+3 months';
            if ($duration === '6m') $date_string = '+6 months';
            if ($duration === '1y') $date_string = '+1 year';
            $expiry = date('Y-m-d H:i:s', strtotime($date_string));
        }

        // Update User
        $stmt = $conn->prepare("UPDATE users SET membership_type = 'premium', premium_expiry = ? WHERE id = ?");
        $stmt->bind_param("si", $expiry, $uid);
        $stmt->execute();
    }

    // --- USERS: REVOKE ---
    if (isset($_POST['downgrade_user'])) {
        $uid = intval($_POST['user_id']);
        $conn->query("UPDATE users SET membership_type = 'free', premium_expiry = NULL WHERE id = $uid");
    }

    // --- BULK ACTIONS ---
    if (isset($_POST['gift_all_3m'])) {
        $new_expiry = date('Y-m-d H:i:s', strtotime('+3 months'));
        $conn->query("UPDATE users SET membership_type = 'premium', premium_expiry = '$new_expiry'");
        echo "<script>alert('Success! Everyone is now Premium for 3 months.'); window.location.href='admin.php';</script>";
        exit();
    }

    if (isset($_POST['convert_lifetime_to_3m'])) {
        $new_expiry = date('Y-m-d H:i:s', strtotime('+3 months'));
        $conn->query("UPDATE users SET premium_expiry = '$new_expiry' WHERE membership_type = 'premium' AND premium_expiry IS NULL");
        echo "<script>alert('Reset Complete.'); window.location.href='admin.php';</script>";
        exit();
    }

    // --- GLOSSARY ---
    if (isset($_POST['add_term'])) {
        $term = $conn->real_escape_string($_POST['g_term']);
        $def  = $conn->real_escape_string($_POST['g_def']);
        $eq   = $conn->real_escape_string($_POST['g_eq']);
        $conn->query("INSERT INTO glossary (term, definition, equation) VALUES ('$term', '$def', '$eq')");
    }

    if (isset($_POST['delete_term'])) {
        $gid = intval($_POST['term_id']);
        $conn->query("DELETE FROM glossary WHERE id = $gid");
    }

    // --- CONTENT (VIDEOS, NEWS, CHAT) ---
    if (isset($_POST['add_folder'])) {
        $name = $conn->real_escape_string($_POST['folder_name']);
        $conn->query("INSERT INTO video_folders (name) VALUES ('$name')");
    }

    if (isset($_POST['delete_folder'])) {
        $fid = intval($_POST['folder_id']);
        $conn->query("UPDATE premium_content SET folder_id = 0 WHERE folder_id = $fid");
        $conn->query("DELETE FROM video_folders WHERE id = $fid");
    }

    if (isset($_POST['add_video'])) {
        $title = $conn->real_escape_string($_POST['v_title']);
        $url   = $conn->real_escape_string($_POST['v_url']);
        $desc  = $conn->real_escape_string($_POST['v_desc']);
        $fid   = intval($_POST['folder_id']);
        $v_type = $_POST['video_type'];

        $is_locked = isset($_POST['is_locked']) ? 1 : 0;

        $conn->query(
            "INSERT INTO premium_content
            (title, description, video_url, folder_id, video_type, is_locked)
            VALUES ('$title', '$desc', '$url', '$fid', '$v_type', $is_locked)"
        );
    }

    if (isset($_POST['delete_video'])) {
        $conn->query("DELETE FROM premium_content WHERE id = " . intval($_POST['video_id']));
    }

    if (isset($_POST['add_article'])) {
        $title = $conn->real_escape_string($_POST['a_title']);
        $cat   = $conn->real_escape_string($_POST['a_category']);
        $cont  = $conn->real_escape_string($_POST['a_content']);

        $sql = "INSERT INTO articles (title, category, content, created_at) VALUES ('$title', '$cat', '$cont', NOW())";
        if ($conn->query($sql) === TRUE) {
            $aid = $conn->insert_id;
            if (isset($_FILES['a_thumbnail']) && $_FILES['a_thumbnail']['error'] == 0) {
                $target = "uploads/articles/" . $aid . "/";
                if (!file_exists($target)) { mkdir($target, 0777, true); }
                $file = $target . basename($_FILES["a_thumbnail"]["name"]);
                if (move_uploaded_file($_FILES["a_thumbnail"]["tmp_name"], $file)) {
                    $conn->query("UPDATE articles SET image='$file' WHERE id='$aid'");
                }
            }
        }
    }

    if (isset($_POST['delete_article'])) {
        $conn->query("DELETE FROM articles WHERE id = " . intval($_POST['article_id']));
    }

    if (isset($_POST['send_reply'])) {
        $msg = $conn->real_escape_string($_POST['message']);
        $tid = intval($_POST['target_id']);
        $conn->query("INSERT INTO support_messages (user_id, message, sender) VALUES ($tid, '$msg', 'admin')");
    }

    echo "<script>window.location.href='admin.php';</script>";
    exit();
}

// 3. FETCH DATA
$stats = [
    'total' => $conn->query("SELECT COUNT(*) FROM users")->fetch_row()[0],
    'prem'  => $conn->query("SELECT COUNT(*) FROM users WHERE membership_type='premium'")->fetch_row()[0]
];
$stats['free'] = $stats['total'] - $stats['prem'];

// USERS + SEARCH + PAGINATION (FIXED)
$where = " WHERE 1=1 ";
$search = "";

if (isset($_GET['search']) && trim($_GET['search']) !== "") {
    $search = trim($_GET['search']);
    $s = $conn->real_escape_string($search);
    $where .= " AND (fullname LIKE '%$s%' OR email LIKE '%$s%') ";
}

$per_page = 50;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;
$offset = ($page - 1) * $per_page;

// Count total (uses SAME where)
$count_res = $conn->query("SELECT COUNT(*) AS total FROM users $where");
$total_users = (int)$count_res->fetch_assoc()['total'];
$total_pages = (int)ceil($total_users / $per_page);

// Fetch users
$user_sql = "SELECT * FROM users $where ORDER BY id DESC LIMIT $per_page OFFSET $offset";
$users_res = $conn->query($user_sql);

$folders_res  = $conn->query("SELECT * FROM video_folders ORDER BY name ASC");
$videos_res   = $conn->query("SELECT v.*, f.name as folder_name FROM premium_content v LEFT JOIN video_folders f ON v.folder_id = f.id ORDER BY v.id DESC");
$articles_res = $conn->query("SELECT * FROM articles ORDER BY id DESC");
$chat_users   = $conn->query("SELECT DISTINCT u.id, u.fullname FROM support_messages sm JOIN users u ON sm.user_id = u.id ORDER BY sm.id DESC");

$glossary_res = null;
if ($conn->query("SHOW TABLES LIKE 'glossary'")->num_rows > 0) {
    $glossary_res = $conn->query("SELECT * FROM glossary ORDER BY term ASC");
}
?>

<style>
    :root { --sidebar-width: 260px; --header-height: 70px; --admin-bg: #f3f4f6; --dark: #0f172a; --gold: #d4af37; }
    body { background-color: var(--admin-bg); margin: 0; font-family: 'Padauk', 'Segoe UI', sans-serif; }

    .admin-wrapper { display: flex; min-height: 100vh; }

    .sidebar { width: var(--sidebar-width); background: var(--dark); color: white; position: fixed; height: 100vh; padding-top: 20px; transition: 0.3s; z-index: 100; overflow-y:auto; }
    .sidebar-brand { text-align: center; padding-bottom: 20px; border-bottom: 1px solid rgba(255,255,255,0.1); }
    .sidebar-brand h2 { color: var(--gold); margin: 0; font-family: 'Playfair Display', serif; }
    .sidebar-menu { list-style: none; padding: 20px 0; margin: 0; }
    .sidebar-menu li { padding: 5px 20px; margin-bottom: 5px; }
    .nav-btn { display: flex; align-items: center; gap: 15px; width: 100%; padding: 12px 15px; border: none; background: transparent; color: #94a3b8; font-size: 1rem; cursor: pointer; border-radius: 8px; transition: 0.3s; text-align: left; }
    .nav-btn:hover, .nav-btn.active { background: rgba(212, 175, 55, 0.15); color: var(--gold); }
    .nav-btn i { width: 25px; }

    .main-content { margin-left: var(--sidebar-width); flex: 1; padding: 30px; padding-top: 100px; }

    .admin-section { display: none; animation: fadeIn 0.4s ease; }
    .admin-section.active { display: block; }
    @keyframes fadeIn { from{opacity:0; transform:translateY(10px);} to{opacity:1; transform:translateY(0);} }

    .card { background: white; border-radius: 12px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); overflow: hidden; margin-bottom: 30px; }
    .card-header { padding: 20px; border-bottom: 1px solid #e5e7eb; display: flex; justify-content: space-between; align-items: center; background: white; }
    .card-title { font-size: 1.2rem; font-weight: 700; color: var(--dark); margin: 0; }

    .table-box { overflow-x: auto; }
    .u-table { width: 100%; border-collapse: separate; border-spacing: 0; }
    .u-table th { background: #f8fafc; color: #64748b; font-weight: 700; text-align: left; padding: 18px; font-size: 0.8rem; text-transform: uppercase; letter-spacing: 1px; border-bottom: 2px solid #e2e8f0; }
    .u-table td { padding: 18px; border-bottom: 1px solid #f1f5f9; vertical-align: middle; color: #334155; }
    .u-table tr:hover { background: #fdfdfd; }

    .user-avatar { width: 40px; height: 40px; background: #e2e8f0; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 700; color: #475569; margin-right: 15px; font-size: 1.1rem; }
    .user-flex { display: flex; align-items: center; }

    .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 20px; margin-bottom: 30px; }
    .stat-box { background: white; padding: 25px; border-radius: 12px; display: flex; align-items: center; gap: 20px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
    .stat-icon { width: 60px; height: 60px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.8rem; }

    .admin-input, .admin-select { width: 100%; padding: 12px; border: 1px solid #cbd5e1; border-radius: 8px; margin-bottom: 10px; font-family: inherit; font-size: 0.9rem; background: #fcfcfc; }
    .admin-select:focus, .admin-input:focus { outline: none; border-color: var(--gold); background: white; }

    .btn { padding: 10px 20px; border-radius: 8px; border: none; font-weight: 600; cursor: pointer; transition: 0.2s; font-size: 0.9rem; text-decoration:none; display:inline-block; }
    .btn-small { padding: 8px 12px; font-size: 0.85rem; }
    .btn-gold { background: linear-gradient(135deg, #d4af37 0%, #b5952f 100%); color: #000; box-shadow: 0 4px 10px rgba(212, 175, 55, 0.2); }
    .btn-gold:hover { transform: translateY(-2px); box-shadow: 0 6px 15px rgba(212, 175, 55, 0.3); }
    .btn-red { background: #fee2e2; color: #991b1b; }
    .btn-red:hover { background: #fecaca; }
    .btn-green { background: #dcfce7; color: #166534; }

    .badge { padding: 6px 12px; border-radius: 30px; font-size: 0.75rem; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px; }
    .badge-prem { background: rgba(212, 175, 55, 0.15); color: #b5952f; border: 1px solid rgba(212, 175, 55, 0.3); }
    .badge-free { background: #f1f5f9; color: #64748b; border: 1px solid #e2e8f0; }

    @media (max-width: 1024px) {
        .sidebar { width: 70px; }
        .sidebar-brand h2, .nav-btn span { display: none; }
        .nav-btn { justify-content: center; padding: 15px; }
        .main-content { margin-left: 70px; }
    }
</style>

<div class="admin-wrapper">
    <aside class="sidebar">
        <div class="sidebar-brand">
            <h2>Wise Admin</h2>
            <i class="fas fa-crown" style="color:var(--gold); font-size:1.5rem; display:none;"></i>
        </div>

        <ul class="sidebar-menu">
            <li><button class="nav-btn active" onclick="showSection('dashboard')"><i class="fas fa-home"></i> <span>Dashboard</span></button></li>
            <li><button class="nav-btn" onclick="showSection('users')"><i class="fas fa-users"></i> <span>Users</span></button></li>
            <li><button class="nav-btn" onclick="showSection('news')"><i class="fas fa-newspaper"></i> <span>News</span></button></li>
            <li><button class="nav-btn" onclick="showSection('glossary')"><i class="fas fa-book"></i> <span>Glossary</span></button></li>
            <li><button class="nav-btn" onclick="showSection('videos')"><i class="fas fa-video"></i> <span>Videos</span></button></li>
            <li><button class="nav-btn" onclick="showSection('chat')"><i class="fas fa-comments"></i> <span>Support</span></button></li>

            <!-- ✅ GALLERY REMOVED -->
        </ul>
    </aside>

    <main class="main-content">

        <div id="dashboard" class="admin-section active">
            <h1 style="margin-bottom:20px;">Overview</h1>

            <div class="stats-grid">
                <div class="stat-box">
                    <div class="stat-icon" style="background:#e0f2fe; color:#0369a1;"><i class="fas fa-users"></i></div>
                    <div>
                        <h2 style="margin:0;"><?php echo number_format($stats['total']); ?></h2>
                        <span style="color:#64748b;">Total Users</span>
                    </div>
                </div>

                <div class="stat-box">
                    <div class="stat-icon" style="background:rgba(212, 175, 55, 0.15); color:var(--gold);"><i class="fas fa-crown"></i></div>
                    <div>
                        <h2 style="margin:0;"><?php echo number_format($stats['prem']); ?></h2>
                        <span style="color:#64748b;">Premium</span>
                    </div>
                </div>

                <div class="stat-box">
                    <div class="stat-icon" style="background:#f1f5f9; color:#475569;"><i class="fas fa-user"></i></div>
                    <div>
                        <h2 style="margin:0;"><?php echo number_format($stats['free']); ?></h2>
                        <span style="color:#64748b;">Free</span>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-header"><h3 class="card-title">🚀 Bulk Actions</h3></div>
                <div style="padding:20px; display:flex; gap:20px; flex-wrap:wrap;">
                    <form method="POST" onsubmit="return confirm('GIFT EVERYONE 3 MONTHS?');">
                        <input type="hidden" name="gift_all_3m" value="1">
                        <button type="submit" class="btn btn-green" style="padding:15px 30px;">
                            <i class="fas fa-gift"></i> Gift All Users (3 Months)
                        </button>
                    </form>

                    <form method="POST" onsubmit="return confirm('RESET LIFETIME USERS TO 3 MONTHS?');">
                        <input type="hidden" name="convert_lifetime_to_3m" value="1">
                        <button type="submit" class="btn btn-red" style="padding:15px 30px;">
                            <i class="fas fa-exclamation-triangle"></i> Reset Lifetime Users
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <div id="users" class="admin-section">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">User Management</h3>

                    <form method="GET" style="display:flex; gap:10px;">
                        <input type="text" name="search" class="admin-input" placeholder="Search users..." style="width:250px; margin:0;"
                               value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                        <button type="submit" class="btn btn-gold">Search</button>
                    </form>
                </div>

                <div class="table-box">
                    <table class="u-table">
                        <thead>
                            <tr>
                                <th>User Profile</th>
                                <th>Current Status</th>
                                <th>Manage Membership</th>
                            </tr>
                        </thead>

                        <tbody>
                        <?php if($users_res && $users_res->num_rows > 0): ?>
                            <?php while($u = $users_res->fetch_assoc()): ?>
                                <tr>
                                    <td>
                                        <div class="user-flex">
                                            <div class="user-avatar"><?php echo strtoupper(substr($u['fullname'], 0, 1)); ?></div>
                                            <div>
                                                <strong style="color:var(--dark); font-size:1rem;"><?php echo htmlspecialchars($u['fullname']); ?></strong><br>
                                                <span style="color:#94a3b8; font-size:0.85rem;"><?php echo htmlspecialchars($u['email']); ?></span>
                                            </div>
                                        </div>
                                    </td>

                                    <td>
                                        <?php if($u['membership_type'] == 'premium'): ?>
                                            <span class="badge badge-prem"><i class="fas fa-check-circle"></i> PREMIUM</span>
                                            <div style="font-size:0.75rem; margin-top:8px; color:#b5952f; font-weight:600;">
                                                Expires: <?php echo $u['premium_expiry'] ? date('M d, Y', strtotime($u['premium_expiry'])) : 'LIFETIME'; ?>
                                            </div>
                                        <?php else: ?>
                                            <span class="badge badge-free">FREE ACCOUNT</span>
                                        <?php endif; ?>
                                    </td>

                                    <td>
                                        <div style="display:flex; gap:10px; align-items:center;">
                                            <form method="POST" style="display:flex; gap:10px; align-items:center;">
                                                <input type="hidden" name="user_id" value="<?php echo $u['id']; ?>">
                                                <input type="hidden" name="upgrade_user" value="1">

                                                <select name="duration" class="admin-select" style="width:130px; margin:0; padding:8px; cursor:pointer;">
                                                    <option value="1m">1 Month</option>
                                                    <option value="3m">3 Months</option>
                                                    <option value="6m">6 Months</option>
                                                    <option value="1y">1 Year</option>
                                                    <option value="life" style="color:var(--gold); font-weight:bold;">Lifetime</option>
                                                </select>

                                                <button type="submit" class="btn btn-gold" style="padding:8px 15px;">
                                                    <i class="fas fa-arrow-up"></i> <?php echo ($u['membership_type']=='premium') ? 'Extend' : 'Upgrade'; ?>
                                                </button>
                                            </form>

                                            <?php if($u['membership_type'] == 'premium'): ?>
                                            <form method="POST" onsubmit="return confirm('Revoke Premium?');">
                                                <input type="hidden" name="user_id" value="<?php echo $u['id']; ?>">
                                                <input type="hidden" name="downgrade_user" value="1">
                                                <button type="submit" class="btn btn-red" style="padding:8px 12px;" title="Revoke Access">
                                                    <i class="fas fa-ban"></i>
                                                </button>
                                            </form>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="3" style="text-align:center; padding:30px; color:#94a3b8;">
                                    No users found matching your search.
                                </td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- ✅ PAGINATION (CORRECT PLACE + WORKS WITH SEARCH) -->
                <?php if ($total_pages > 1): ?>
                    <div style="padding:15px 20px; display:flex; gap:8px; flex-wrap:wrap; align-items:center; border-top:1px solid #f1f5f9;">
                        <?php
                            $base = "?";
                            if ($search !== "") $base .= "search=" . urlencode($search) . "&";
                        ?>

                        <?php if ($page > 1): ?>
                            <a class="btn btn-small" href="<?= $base ?>page=<?= $page - 1 ?>">Prev</a>
                        <?php endif; ?>

                        <?php for ($p = 1; $p <= $total_pages; $p++): ?>
                            <?php if ($p == $page): ?>
                                <span class="btn btn-small" style="opacity:0.6; pointer-events:none;"><?= $p ?></span>
                            <?php else: ?>
                                <a class="btn btn-small" href="<?= $base ?>page=<?= $p ?>"><?= $p ?></a>
                            <?php endif; ?>
                        <?php endfor; ?>

                        <?php if ($page < $total_pages): ?>
                            <a class="btn btn-small" href="<?= $base ?>page=<?= $page + 1 ?>">Next</a>
                        <?php endif; ?>

                        <span style="margin-left:10px; opacity:0.8;">
                            Page <?= $page ?> / <?= $total_pages ?> (<?= $total_users ?> users)
                        </span>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div id="glossary" class="admin-section">
            <div class="card">
                <div class="card-header"><h3 class="card-title">Financial Glossary</h3></div>

                <div style="display:grid; grid-template-columns: 1fr 2fr; gap:30px; padding:20px;">
                    <form method="POST" style="background:#f8fafc; padding:20px; border-radius:8px;">
                        <input type="hidden" name="add_term" value="1">

                        <label style="font-weight:bold; font-size:0.9rem;">Term</label>
                        <input type="text" name="g_term" class="admin-input" placeholder="e.g. CAGR" required>

                        <label style="font-weight:bold; font-size:0.9rem;">Definition</label>
                        <textarea name="g_def" class="admin-input" rows="4" placeholder="Explain it..." required></textarea>

                        <label style="font-weight:bold; font-size:0.9rem;">Equation (Optional)</label>
                        <input type="text" name="g_eq" class="admin-input" placeholder="e.g. (EV / EBITDA)">

                        <button type="submit" class="btn btn-gold" style="width:100%;">Add Term</button>
                    </form>

                    <div style="max-height:500px; overflow-y:auto;">
                        <table class="u-table">
                            <thead><tr><th>Term</th><th>Action</th></tr></thead>
                            <tbody>
                            <?php if($glossary_res && $glossary_res->num_rows > 0): ?>
                                <?php while($g = $glossary_res->fetch_assoc()): ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo htmlspecialchars($g['term']); ?></strong><br>
                                            <small style="color:#64748b;"><?php echo substr($g['definition'],0,50); ?>...</small>
                                        </td>
                                        <td>
                                            <form method="POST" onsubmit="return confirm('Delete?');">
                                                <input type="hidden" name="term_id" value="<?php echo $g['id']; ?>">
                                                <input type="hidden" name="delete_term" value="1">
                                                <button class="btn btn-red"><i class="fas fa-trash"></i></button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="2">No terms yet. Add one!</td></tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div id="news" class="admin-section">
            <div class="card">
                <div class="card-header"><h3 class="card-title">Article Manager</h3></div>

                <div style="padding:20px;">
                    <form method="POST" enctype="multipart/form-data" style="display:grid; grid-template-columns: 1fr 1fr; gap:15px;">
                        <input type="hidden" name="add_article" value="1">
                        <input type="text" name="a_title" class="admin-input" placeholder="Title" required>

                        <select name="a_category" class="admin-select">
                            <option value="Brokerage Knowledges">Brokerage Knowledges</option>
                            <option value="Investment Knowledges">Investment Knowledges</option>
                        </select>

                        <input type="file" name="a_thumbnail" class="admin-input" required accept="image/*">

                        <div style="grid-column: 1 / -1;">
                            <textarea name="a_content" class="admin-input" rows="5" placeholder="Article Content..." required></textarea>
                            <button type="submit" class="btn btn-gold">Publish Article</button>
                        </div>
                    </form>
                </div>

                <div class="table-box" style="border-top:1px solid #eee;">
                    <table class="u-table">
                        <thead><tr><th>Article</th><th>Action</th></tr></thead>
                        <tbody>
                        <?php if($articles_res && $articles_res->num_rows > 0): ?>
                            <?php while($art = $articles_res->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($art['title']); ?> <span class="badge badge-free"><?php echo $art['category']; ?></span></td>
                                    <td>
                                        <form method="POST" onsubmit="return confirm('Delete?');">
                                            <input type="hidden" name="article_id" value="<?php echo $art['id']; ?>">
                                            <input type="hidden" name="delete_article" value="1">
                                            <button class="btn btn-red">X</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div id="videos" class="admin-section">
            <div style="display:grid; grid-template-columns: 1fr 2fr; gap:20px;">
                <div class="card">
                    <div class="card-header">1. Premium Folders</div>
                    <div style="padding:20px;">
                        <form method="POST">
                            <input type="hidden" name="add_folder" value="1">
                            <input type="text" name="folder_name" class="admin-input" placeholder="Class Name (e.g. Day Trading)" required>
                            <button class="btn btn-gold">Create Folder</button>
                        </form>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">2. Upload Video</div>
                    <div style="padding:20px;">
                        <form method="POST" style="display:grid; gap:10px;">
                            <input type="hidden" name="add_video" value="1">

                            <input type="text" name="v_title" class="admin-input" placeholder="Title" required>
                            <input type="text" name="v_url" class="admin-input" placeholder="YouTube URL" required>

                            <label><strong>Where should this video go?</strong></label>
                            <select name="video_type" class="admin-select">
                                <option value="free">Free Library (Learning > Videos)</option>
                                <option value="premium">Premium Hub (Premium > Videos)</option>
                            </select>

                            <label><strong>Select Folder (Premium Only)</strong></label>
                            <select name="folder_id" class="admin-select">
                                <option value="0">None / Uncategorized</option>
                                <?php
                                $folders_arr = [];
                                if($folders_res) {
                                    while($f = $folders_res->fetch_assoc()) {
                                        $folders_arr[] = $f;
                                        echo "<option value='".$f['id']."'>".$f['name']."</option>";
                                    }
                                }
                                ?>
                            </select>

                            <input type="text" name="v_desc" class="admin-input" placeholder="Description">

                            <label style="display:flex; align-items:center; gap:8px;">
                                <input type="checkbox" name="is_locked" value="1">
                                🔒 Lock this video (preview only)
                            </label>

                            <button class="btn btn-gold">Upload Video</button>
                        </form>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-header">Existing Videos</div>
                <div style="max-height:400px; overflow-y:auto;">
                    <table class="u-table">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Type</th>
                                <th>Folder</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php while($v = $videos_res->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $v['title']; ?></td>
                                <td>
                                    <?php if($v['video_type'] == 'free'): ?>
                                        <span class="badge badge-free">FREE</span>
                                    <?php else: ?>
                                        <span class="badge badge-prem">PREMIUM</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo $v['folder_name'] ? $v['folder_name'] : '-'; ?></td>
                                <td>
                                    <?php if ($v['is_locked']): ?>
                                        <span class="badge badge-free">🔒 LOCKED</span>
                                    <?php else: ?>
                                        <span class="badge badge-prem">🔓 OPEN</span>
                                    <?php endif; ?>
                                </td>

                                <td style="display:flex; gap:8px;">
                                    <form method="POST">
                                        <input type="hidden" name="toggle_lock" value="1">
                                        <input type="hidden" name="video_id" value="<?php echo $v['id']; ?>">
                                        <input type="hidden" name="lock_state" value="<?php echo $v['is_locked'] ? 0 : 1; ?>">
                                        <button class="btn btn-green">
                                            <?php echo $v['is_locked'] ? 'Unlock' : 'Lock'; ?>
                                        </button>
                                    </form>

                                    <form method="POST" onsubmit="return confirm('Delete this video?');">
                                        <input type="hidden" name="video_id" value="<?php echo $v['id']; ?>">
                                        <input type="hidden" name="delete_video" value="1">
                                        <button class="btn btn-red">X</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div id="chat" class="admin-section">
            <div class="card" style="height:600px; display:flex; flex-direction:column;">
                <div class="card-header"><h3 class="card-title">Support Inbox</h3></div>

                <div style="flex:1; display:flex; overflow:hidden;">
                    <div style="width:250px; border-right:1px solid #eee; overflow-y:auto; padding:10px;">
                        <?php if($chat_users && $chat_users->num_rows > 0): ?>
                            <?php while($c = $chat_users->fetch_assoc()): ?>
                                <div onclick="loadChat(<?php echo $c['id']; ?>, this)" style="padding:10px; border-bottom:1px solid #f1f5f9; cursor:pointer; font-size:0.9rem;">
                                    <i class="fas fa-user-circle"></i> <?php echo $c['fullname']; ?>
                                </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <div style="padding:10px; color:#999;">No messages.</div>
                        <?php endif; ?>
                    </div>

                    <div style="flex:1; display:flex; flex-direction:column; background:#f8fafc;">
                        <div id="adm-chat-window" style="flex:1; padding:20px; overflow-y:auto; display:flex; flex-direction:column; gap:10px;">
                            <div style="text-align:center; color:#94a3b8; margin-top:50px;">Select a user to chat</div>
                        </div>

                        <form method="POST" id="reply-form" style="padding:15px; background:white; border-top:1px solid #eee; display:none;">
                            <input type="hidden" name="send_reply" value="1">
                            <input type="hidden" name="target_id" id="reply_target">
                            <div style="display:flex; gap:10px;">
                                <input type="text" name="message" id="reply_msg" class="admin-input" placeholder="Type reply..." style="margin:0;">
                                <button type="submit" class="btn btn-gold">Send</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </main>
</div>

<script>
function showSection(id) {
    document.querySelectorAll('.admin-section').forEach(el => el.classList.remove('active'));
    document.getElementById(id).classList.add('active');

    document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.remove('active'));

    document.querySelectorAll('.nav-btn').forEach(btn => {
        if (btn.getAttribute('onclick')?.includes(id)) {
            btn.classList.add('active');
        }
    });
}

function loadChat(uid, elem) {
    document.getElementById('reply_target').value = uid;
    document.getElementById('reply-form').style.display = 'block';

    fetch('support_api.php?action=fetch&target_id=' + uid)
    .then(r => r.json())
    .then(data => {
        const box = document.getElementById('adm-chat-window');
        box.innerHTML = '';
        data.forEach(m => {
            let style = m.sender === 'admin'
                ? 'align-self:flex-end; background:#0f172a; color:white;'
                : 'align-self:flex-start; background:white; border:1px solid #ddd;';
            box.innerHTML += `<div style="padding:8px 12px; border-radius:8px; max-width:70%; font-size:0.9rem; ${style}">${m.msg}</div>`;
        });
        box.scrollTop = box.scrollHeight;
    });
}

// ✅ If user clicked pagination or searched, auto-open Users tab
<?php if (isset($_GET['page']) || (isset($_GET['search']) && trim($_GET['search']) !== "")): ?>
window.addEventListener('DOMContentLoaded', () => showSection('users'));
<?php endif; ?>
</script>

<?php include 'includes/footer.php'; ?>