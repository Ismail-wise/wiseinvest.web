<?php 
include 'includes/db.php'; 
include 'includes/header.php'; 

// SECURITY: Must be logged in
if(!isset($_SESSION['user_id'])) {
    echo "<script>alert('Please Log In to join the community.'); window.location.href='login.php';</script>";
    exit();
}

// --- HANDLE SUBMISSIONS ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    
    // 1. CREATE POST
    if ($_POST['action'] === 'create_post') {
        $content = $conn->real_escape_string($_POST['content']);
        $uid = $_SESSION['user_id'];
        $video_link = '';
        $image_url = '';

        if (!empty($_POST['video_link'])) {
            $v = $conn->real_escape_string($_POST['video_link']);
            if (strpos($v, 'watch?v=') !== false) {
                $video_link = str_replace('watch?v=', 'embed/', $v);
                $video_link = explode('&', $video_link)[0];
            } elseif (strpos($v, 'youtu.be/') !== false) {
                $video_link = str_replace('youtu.be/', 'www.youtube.com/embed/', $v);
            }
        }

        if (isset($_FILES['post_image']) && $_FILES['post_image']['error'] == 0) {
            $target_dir = "uploads/";
            if (!file_exists($target_dir)) { mkdir($target_dir, 0777, true); }
            $file_name = time() . '_' . basename($_FILES["post_image"]["name"]);
            $target_file = $target_dir . $file_name;
            $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
            $valid_ext = array("jpg", "jpeg", "png", "gif", "webp");
            if(in_array($file_type, $valid_ext)){
                if(move_uploaded_file($_FILES["post_image"]["tmp_name"], $target_file)){
                    $image_url = $target_file;
                }
            }
        }

        if ($content || $image_url || $video_link) {
            $stmt = $conn->prepare("INSERT INTO social_posts (user_id, content, image_url, video_link) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("isss", $uid, $content, $image_url, $video_link);
            $stmt->execute();
        }
        echo "<script>window.location.href='community.php';</script>";
        exit();
    }

    // 2. ADD COMMENT
    if ($_POST['action'] === 'add_comment') {
        $pid = intval($_POST['post_id']);
        $uid = $_SESSION['user_id'];
        $cmt = $conn->real_escape_string($_POST['comment']);
        if ($cmt) {
            $conn->query("INSERT INTO social_comments (post_id, user_id, comment) VALUES ($pid, $uid, '$cmt')");
        }
        echo "<script>window.location.href='community.php';</script>";
        exit();
    }

    // 3. HANDLE REACTION (AJAX)
    if ($_POST['action'] === 'react') {
        $pid = intval($_POST['post_id']);
        $type = $conn->real_escape_string($_POST['type']);
        $uid = $_SESSION['user_id'];

        $check = $conn->query("SELECT id FROM post_reactions WHERE post_id=$pid AND user_id=$uid");
        if($check->num_rows > 0) {
            $conn->query("UPDATE post_reactions SET reaction_type='$type' WHERE post_id=$pid AND user_id=$uid");
        } else {
            $conn->query("INSERT INTO post_reactions (post_id, user_id, reaction_type) VALUES ($pid, $uid, '$type')");
        }
        echo "success";
        exit();
    }

    // 4. NEW: DELETE POST
    if ($_POST['action'] === 'delete_post') {
        $pid = intval($_POST['post_id']);
        $uid = $_SESSION['user_id'];
        // Security Check: Ensure user owns the post
        $conn->query("DELETE FROM social_posts WHERE id=$pid AND user_id=$uid");
        echo "<script>window.location.href='community.php';</script>";
        exit();
    }

    // 5. NEW: EDIT POST
    if ($_POST['action'] === 'edit_post') {
        $pid = intval($_POST['post_id']);
        $uid = $_SESSION['user_id'];
        $new_content = $conn->real_escape_string($_POST['content']);
        // Security Check: Ensure user owns the post
        $conn->query("UPDATE social_posts SET content='$new_content' WHERE id=$pid AND user_id=$uid");
        echo "<script>window.location.href='community.php';</script>";
        exit();
    }
}
?>

<style>
    /* EXISTING STYLES */
    .community-wrapper { background: #f0f2f5; min-height: calc(100vh - 90px); padding: 30px 5%; }
    .comm-tabs { display: flex; justify-content: center; gap: 20px; margin-bottom: 30px; }
    .tab-btn { padding: 12px 30px; background: white; border: 1px solid #cbd5e1; border-radius: 50px; font-weight: 700; color: #64748b; cursor: pointer; display: flex; align-items: center; gap: 8px; transition: 0.3s; }
    .tab-btn.active { background: var(--primary); color: var(--gold); border-color: var(--primary); box-shadow: 0 5px 15px rgba(15, 23, 42, 0.2); }
    .tab-content { display: none; animation: fadeIn 0.4s ease; }
    .tab-content.active { display: block; }
    .feed-container { max-width: 650px; margin: 0 auto; }
    .create-post-card { background: white; border-radius: 12px; padding: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); margin-bottom: 25px; }
    .cp-header { font-weight: 700; color: #334155; margin-bottom: 15px; display:flex; gap:10px; align-items:center; }
    .cp-avatar-small { width: 30px; height: 30px; background: #0f172a; color: var(--gold); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 0.8rem; }
    .cp-input { width: 100%; border: none; background: #f1f5f9; padding: 15px; border-radius: 8px; resize: none; font-family: inherit; font-size: 1rem; margin-bottom: 15px; transition: 0.3s; }
    .cp-input:focus { outline: none; background: #e2e8f0; }
    .cp-tools { display: flex; gap: 10px; border-top: 1px solid #f1f5f9; padding-top: 15px; align-items: center; }
    .btn-tool { background: #f8fafc; color: #64748b; padding: 8px 15px; border-radius: 20px; font-size: 0.9rem; font-weight: 600; cursor: pointer; border: 1px solid transparent; display: flex; align-items: center; gap: 6px; transition: 0.2s; }
    .btn-tool:hover { background: #e2e8f0; color: #0f172a; }
    .btn-tool.photo i { color: #4ade80; }
    .cp-post-btn { margin-left: auto; background: var(--gold); color: #0f172a; border: none; padding: 8px 25px; border-radius: 6px; font-weight: 700; cursor: pointer; }
    .post-card { background: white; border-radius: 12px; box-shadow: 0 2px 5px rgba(0,0,0,0.05); margin-bottom: 20px; border: 1px solid #e2e8f0; overflow: hidden; }
    .post-header { padding: 15px; display: flex; align-items: center; gap: 12px; position: relative; } /* Added position relative */
    .p-avatar { width: 40px; height: 40px; background: #0f172a; color: var(--gold); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 700; }
    .p-info h4 { font-size: 0.95rem; font-weight: 700; color: #0f172a; margin: 0; }
    .p-info span { font-size: 0.75rem; color: #94a3b8; }
    .post-content { padding: 5px 15px 15px 15px; color: #334155; font-size: 0.95rem; line-height: 1.5; }
    .post-visuals { width: 100%; background: black; display: flex; justify-content: center; }
    .post-visuals img { max-width: 100%; max-height: 500px; object-fit: contain; }
    .post-visuals iframe { width: 100%; height: 350px; border: none; }
    .post-footer { background: #f8fafc; padding: 10px 15px; border-top: 1px solid #f1f5f9; }
    .comments-area { max-height: 200px; overflow-y: auto; margin-bottom: 10px; }
    .comment-single { font-size: 0.85rem; margin-bottom: 6px; background: white; padding: 6px 10px; border-radius: 8px; border: 1px solid #e2e8f0; display: inline-block; }
    .c-author { font-weight: 700; color: #0f172a; margin-right: 5px; }
    .comment-form { display: flex; gap: 10px; }
    .c-box { flex: 1; padding: 8px 15px; border-radius: 20px; border: 1px solid #cbd5e1; outline: none; font-size: 0.9rem; }
    .c-btn { background: none; border: none; color: var(--primary); font-weight: 700; cursor: pointer; }
    .chat-wrapper-inner { height: 600px; background: white; border-radius: 16px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); display: flex; flex-direction: column; border: 1px solid #e2e8f0; max-width: 1000px; margin: 0 auto; }
    .chat-header { background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%); padding: 15px 20px; color: white; display: flex; justify-content: space-between; align-items: center; border-bottom: 3px solid var(--gold); }
    .chat-box { flex: 1; padding: 20px; overflow-y: auto; background-color: #f8fafc; display: flex; flex-direction: column; gap: 15px; }
    .msg-row { display: flex; flex-direction: column; align-items: flex-start; }
    .msg-bubble { background: white; padding: 10px 15px; border-radius: 0 12px 12px 12px; border: 1px solid #e2e8f0; max-width: 70%; position: relative; }
    .msg-row.me { align-items: flex-end; }
    .msg-row.me .msg-bubble { background: #0f172a; color: white; border-radius: 12px 0 12px 12px; }
    .chat-input-area { padding: 20px; background: white; border-top: 1px solid #e2e8f0; display: flex; gap: 10px; }
    .c-input { flex: 1; padding: 12px 15px; border: 1px solid #cbd5e1; border-radius: 50px; outline: none; }
    .c-send { width: 50px; height: 50px; background: var(--gold); border: none; border-radius: 50%; color: #0f172a; cursor: pointer; display: flex; align-items: center; justify-content: center; }
    @keyframes fadeIn { from { opacity:0; transform:translateY(10px); } to { opacity:1; transform:translateY(0); } }

    /* REACTION STYLES */
    .reaction-bar { display: flex; gap: 15px; padding: 10px 0; border-bottom: 1px solid #eee; margin-bottom: 10px; }
    .react-btn { background: none; border: none; cursor: pointer; display: flex; align-items: center; gap: 5px; font-size: 0.9rem; color: #64748b; transition: 0.2s; padding: 5px 10px; border-radius: 20px; }
    .react-btn:hover { background: #f1f5f9; }
    .react-btn.active { background: #e0f2fe; color: #0284c7; font-weight: bold; }
    .react-btn i { font-size: 1.1rem; }
    .react-count { font-size: 0.8rem; font-weight: bold; }

    /* MENTION STYLES */
    .mention-highlight { color: #2563eb; font-weight: bold; background: #eff6ff; padding: 0 4px; border-radius: 4px; }
    .msg-bubble.mentioned-me { border: 2px solid var(--gold); box-shadow: 0 0 10px rgba(212, 175, 55, 0.3); animation: pulse 2s infinite; }
    @keyframes pulse { 0% { box-shadow: 0 0 0 0 rgba(212, 175, 55, 0.4); } 70% { box-shadow: 0 0 0 10px rgba(212, 175, 55, 0); } 100% { box-shadow: 0 0 0 0 rgba(212, 175, 55, 0); } }

    /* NEW: POST OPTIONS MENU (EDIT/DELETE) */
    .post-options { margin-left: auto; position: relative; }
    .opt-btn { background: none; border: none; font-size: 1.2rem; cursor: pointer; color: #94a3b8; padding: 5px; }
    .opt-menu { display: none; position: absolute; right: 0; top: 100%; background: white; border: 1px solid #e2e8f0; box-shadow: 0 5px 15px rgba(0,0,0,0.1); border-radius: 8px; width: 120px; z-index: 10; overflow: hidden; }
    .opt-menu.show { display: block; }
    .opt-item { display: block; width: 100%; text-align: left; padding: 10px; background: none; border: none; cursor: pointer; font-size: 0.9rem; color: #334155; transition: 0.2s; }
    .opt-item:hover { background: #f8fafc; }
    .opt-item.danger { color: #ef4444; }
    .opt-item.danger:hover { background: #fef2f2; }
    
    /* Edit Mode */
    .edit-post-form textarea { width: 100%; border: 1px solid #cbd5e1; border-radius: 8px; padding: 10px; font-family: inherit; margin-bottom: 10px; }
    /* ===============================
   FINTECH FOUNDATION (STEP 1)
================================ */

/* Page background */
.community-wrapper {
    background: linear-gradient(180deg, #f1f5f9 0%, #e2e8f0 100%);
}

/* Main feed container */
.feed-container {
    max-width: 720px;
}

/* Card elevation upgrade */
.create-post-card,
.post-card,
.chat-wrapper-inner {
    box-shadow: 0 10px 30px rgba(15, 23, 42, 0.08);
    border-radius: 16px;
}

/* Softer card borders */
.create-post-card,
.post-card {
    border: 1px solid rgba(226, 232, 240, 0.9);
}

/* Section spacing rhythm */
.create-post-card {
    margin-bottom: 30px;
}

/* Typography polish */
.post-content,
.cp-input,
.comment-single {
    line-height: 1.65;
    letter-spacing: 0.1px;
}

/* Feed & Chat tabs polish */
.comm-tabs {
    margin-bottom: 40px;
}

.tab-btn {
    background: rgba(255, 255, 255, 0.85);
    backdrop-filter: blur(6px);
}

.tab-btn.active {
    transform: translateY(-1px);
}

/* Scrollbar (WebKit only – safe) */
.comments-area::-webkit-scrollbar,
.chat-box::-webkit-scrollbar {
    width: 6px;
}

.comments-area::-webkit-scrollbar-thumb,
.chat-box::-webkit-scrollbar-thumb {
    background: #cbd5e1;
    border-radius: 6px;
}
/* ===============================
   STEP 2 — CREATE POST FINTECH HERO
================================ */

/* Create Post Card – Hero Look */
.create-post-card {
    position: relative;
    overflow: hidden;
}

/* Top gradient bar (TradingView style) */
.create-post-card::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    height: 4px;
    width: 100%;
    background: linear-gradient(
        90deg,
        #d4af37,
        #60a5fa,
        #22d3ee
    );
}

/* Focus glow when typing */
.cp-input:focus {
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.15);
    transition: box-shadow 0.25s ease;
}

/* Post button upgrade */
.cp-post-btn {
    background: linear-gradient(135deg, #d4af37, #facc15);
    box-shadow: 0 8px 20px rgba(212, 175, 55, 0.35);
    transition: all 0.25s ease;
}

.cp-post-btn:hover {
    transform: translateY(-1px);
    box-shadow: 0 12px 30px rgba(212, 175, 55, 0.45);
}

/* Create post card hover lift */
.create-post-card:hover {
    transform: translateY(-2px);
    transition: transform 0.3s ease;
}
/* ===============================
   STEP 3 — FEED CARDS & INTERACTIONS
================================ */

/* Post card hover depth */
.post-card {
    transition: all 0.3s ease;
    background: rgba(255, 255, 255, 0.95);
}

.post-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 18px 40px rgba(15, 23, 42, 0.12);
}

/* Post header alignment polish */
.post-header {
    border-bottom: 1px solid #f1f5f9;
}

/* Username emphasis */
.p-info h4 {
    font-size: 0.95rem;
    letter-spacing: 0.2px;
}

/* Timestamp lighter */
.p-info span {
    opacity: 0.8;
}

/* Post content readability */
.post-content {
    font-size: 0.95rem;
    padding-top: 10px;
}

/* Reaction bar spacing */
.reaction-bar {
    padding-top: 12px;
}

/* Reaction buttons – fintech feel */
.react-btn {
    background: transparent;
    border-radius: 999px;
    padding: 6px 14px;
    transition: all 0.2s ease;
}

.react-btn:hover {
    background: rgba(148, 163, 184, 0.15);
    transform: translateY(-1px);
}

/* Active reaction highlight */
.react-btn.active {
    background: rgba(37, 99, 235, 0.12);
    color: #2563eb;
}

/* Comment bubbles softer */
.comment-single {
    background: #ffffff;
    box-shadow: 0 4px 12px rgba(15, 23, 42, 0.05);
}

/* Visual separation between posts */
.post-card + .post-card {
    margin-top: 28px;
}
/* ===============================
   STEP 4 — MICRO ANIMATIONS
================================ */

/* Fade-up animation */
@keyframes fadeUp {
    from {
        opacity: 0;
        transform: translateY(14px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Apply to post cards */
.post-card {
    animation: fadeUp 0.45s ease both;
}

/* Stagger effect (soft) */
.post-card:nth-child(1) { animation-delay: 0.05s; }
.post-card:nth-child(2) { animation-delay: 0.08s; }
.post-card:nth-child(3) { animation-delay: 0.11s; }
.post-card:nth-child(4) { animation-delay: 0.14s; }

/* Smooth tab transition */
.tab-content {
    transition: opacity 0.25s ease, transform 0.25s ease;
}

.tab-content.active {
    opacity: 1;
    transform: translateY(0);
}

.tab-content:not(.active) {
    opacity: 0;
    transform: translateY(6px);
}
/* ===============================
   INSTANT FINTECH DESIGN BOOST
================================ */

/* Darker premium background */
.community-wrapper {
    background: radial-gradient(
        circle at top,
        #f8fafc 0%,
        #e2e8f0 60%,
        #cbd5e1 100%
    );
}

/* Glassmorphism effect */
.create-post-card,
.post-card,
.chat-wrapper-inner {
    background: rgba(255, 255, 255, 0.82);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
}

/* Stronger premium edges */
.create-post-card,
.post-card {
    border: 1px solid rgba(255, 255, 255, 0.6);
}

/* Feed feels more spacious */
.feed-container {
    padding-bottom: 40px;
}

/* Avatar upgrade */
.p-avatar,
.cp-avatar-small {
    background: linear-gradient(135deg, #0f172a, #1e293b);
    box-shadow: 0 4px 12px rgba(15, 23, 42, 0.4);
}

/* Reaction icons pop more */
.react-btn i {
    transition: transform 0.2s ease;
}

.react-btn:hover i {
    transform: scale(1.15);
}

/* Post content card glow on hover */
.post-card:hover {
    box-shadow:
        0 20px 45px rgba(15, 23, 42, 0.15),
        0 0 0 1px rgba(212, 175, 55, 0.25);
}

/* Chat header looks more premium */
.chat-header {
    letter-spacing: 0.3px;
}

/* Tabs more fintech-like */
.tab-btn {
    box-shadow: 0 6px 20px rgba(15, 23, 42, 0.08);
}

.tab-btn.active {
    box-shadow: 0 10px 30px rgba(15, 23, 42, 0.18);
}

/* Gentle section separators */
.create-post-card::after {
    content: "";
    position: absolute;
    bottom: -20px;
    left: 50%;
    transform: translateX(-50%);
    width: 60%;
    height: 1px;
    background: linear-gradient(
        90deg,
        transparent,
        rgba(148, 163, 184, 0.5),
        transparent
    );
}
/* ===============================
   FUTURISTIC FINTECH MODE
================================ */

/* Deep futuristic background */
.community-wrapper {
    background:
        radial-gradient(circle at 20% 10%, rgba(56,189,248,0.15), transparent 40%),
        radial-gradient(circle at 80% 20%, rgba(34,211,238,0.12), transparent 45%),
        linear-gradient(180deg, #020617 0%, #020617 40%, #030712 100%);
    color: #e5e7eb;
}

/* Glass + neon cards */
.create-post-card,
.post-card,
.chat-wrapper-inner {
    background: rgba(15, 23, 42, 0.72);
    backdrop-filter: blur(16px);
    -webkit-backdrop-filter: blur(16px);
    border: 1px solid rgba(148, 163, 184, 0.18);
}

/* Neon edge glow on hover */
.post-card:hover,
.create-post-card:hover {
    box-shadow:
        0 0 0 1px rgba(56, 189, 248, 0.35),
        0 25px 60px rgba(15, 23, 42, 0.9);
}

/* Typography color correction for dark mode */
.post-content,
.cp-input,
.comment-single,
.p-info h4,
.p-info span {
    color: #e5e7eb;
}

/* Inputs futuristic */
.cp-input {
    background: rgba(2, 6, 23, 0.8);
    color: #e5e7eb;
    border: 1px solid rgba(148, 163, 184, 0.25);
}

.cp-input::placeholder {
    color: #94a3b8;
}

/* Input focus neon */
.cp-input:focus {
    box-shadow:
        0 0 0 2px rgba(56, 189, 248, 0.35),
        0 0 25px rgba(56, 189, 248, 0.25);
}

/* Post button cyber look */
.cp-post-btn {
    background: linear-gradient(135deg, #38bdf8, #22d3ee);
    color: #020617;
    text-shadow: 0 0 6px rgba(255,255,255,0.35);
}

.cp-post-btn:hover {
    box-shadow:
        0 0 20px rgba(56, 189, 248, 0.6),
        0 0 40px rgba(34, 211, 238, 0.4);
}

/* Tabs – futuristic pills */
.tab-btn {
    background: rgba(2, 6, 23, 0.7);
    color: #cbd5f5;
    border: 1px solid rgba(148, 163, 184, 0.25);
}

.tab-btn.active {
    background: linear-gradient(135deg, #38bdf8, #22d3ee);
    color: #020617;
}

/* Reaction bar cyber feel */
.react-btn {
    color: #94a3b8;
}

.react-btn.active {
    color: #38bdf8;
    background: rgba(56, 189, 248, 0.12);
    box-shadow: inset 0 0 10px rgba(56, 189, 248, 0.35);
}

/* Chat header cyber */
.chat-header {
    background: linear-gradient(135deg, #020617, #020617);
    border-bottom: 1px solid rgba(56, 189, 248, 0.35);
}

/* Scrollbar cyber */
.chat-box::-webkit-scrollbar-thumb,
.comments-area::-webkit-scrollbar-thumb {
    background: linear-gradient(180deg, #38bdf8, #22d3ee);
}
/* =================================
   STEP 1 — FUTURISTIC DARK BASE
================================= */

/* Dark terminal background */
.community-wrapper {
    background:
        radial-gradient(circle at 15% 10%, rgba(56,189,248,0.12), transparent 40%),
        radial-gradient(circle at 85% 20%, rgba(34,211,238,0.10), transparent 45%),
        linear-gradient(180deg, #020617 0%, #020617 60%, #030712 100%);
    color: #e5e7eb;
}

/* Global text correction for dark mode */
.post-content,
.comment-single,
.p-info h4,
.p-info span,
.cp-header span,
.comm-tabs {
    color: #e5e7eb;
}

/* Cards become dark glass */
.create-post-card,
.post-card,
.chat-wrapper-inner {
    background: rgba(15, 23, 42, 0.75);
    backdrop-filter: blur(14px);
    -webkit-backdrop-filter: blur(14px);
    border: 1px solid rgba(148, 163, 184, 0.18);
}

/* Tabs dark */
.tab-btn {
    background: rgba(2, 6, 23, 0.7);
    color: #94a3b8;
    border: 1px solid rgba(148, 163, 184, 0.25);
}

.tab-btn.active {
    background: linear-gradient(135deg, #38bdf8, #22d3ee);
    color: #020617;
}
/* =================================
   STEP 2 — NEON INPUTS & BUTTONS
================================= */

/* Textarea & input – cyber terminal */
.cp-input {
    background: rgba(2, 6, 23, 0.85);
    color: #e5e7eb;
    border: 1px solid rgba(148, 163, 184, 0.25);
    transition: all 0.25s ease;
}

/* Placeholder color */
.cp-input::placeholder {
    color: #64748b;
}

/* Neon focus glow */
.cp-input:focus {
    border-color: #38bdf8;
    box-shadow:
        0 0 0 2px rgba(56, 189, 248, 0.35),
        0 0 20px rgba(56, 189, 248, 0.25);
}

/* Post button – cyber glow */
.cp-post-btn {
    background: linear-gradient(135deg, #38bdf8, #22d3ee);
    color: #020617;
    font-weight: 800;
    letter-spacing: 0.3px;
    box-shadow:
        0 0 0 rgba(0,0,0,0);
    transition: all 0.25s ease;
}

/* Post button hover */
.cp-post-btn:hover {
    transform: translateY(-1px);
    box-shadow:
        0 0 18px rgba(56, 189, 248, 0.6),
        0 0 36px rgba(34, 211, 238, 0.4);
}

/* Photo upload button */
.btn-tool.photo {
    background: rgba(2, 6, 23, 0.7);
    border: 1px solid rgba(148, 163, 184, 0.25);
    color: #cbd5e1;
}

.btn-tool.photo:hover {
    background: rgba(56, 189, 248, 0.15);
    border-color: #38bdf8;
    color: #e5e7eb;
}
/* =================================
   STEP 3 — NEON CARDS & HOVER GLOW
================================= */

/* Card base enhancement */
.post-card,
.create-post-card {
    position: relative;
    transition: all 0.35s ease;
}

/* Cyber glow on hover */
.post-card:hover,
.create-post-card:hover {
    box-shadow:
        0 0 0 1px rgba(56, 189, 248, 0.45),
        0 30px 70px rgba(15, 23, 42, 0.95),
        0 0 35px rgba(56, 189, 248, 0.35);
    transform: translateY(-3px);
}

/* Gradient glow border */
.post-card::before,
.create-post-card::before {
    content: "";
    position: absolute;
    inset: 0;
    border-radius: inherit;
    pointer-events: none;
    background: linear-gradient(
        120deg,
        transparent 30%,
        rgba(56, 189, 248, 0.35),
        rgba(34, 211, 238, 0.35),
        transparent 70%
    );
    opacity: 0;
    transition: opacity 0.35s ease;
}

/* Activate glow */
.post-card:hover::before,
.create-post-card:hover::before {
    opacity: 1;
}
/* =================================
   STEP 4 — FUTURISTIC MICRO-MOTION
================================= */

/* Fade-up motion */
@keyframes cyberFadeUp {
    from {
        opacity: 0;
        transform: translateY(16px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Apply to cards */
.post-card {
    animation: cyberFadeUp 0.45s ease both;
}

/* Slight stagger for depth */
.post-card:nth-child(1) { animation-delay: 0.05s; }
.post-card:nth-child(2) { animation-delay: 0.08s; }
.post-card:nth-child(3) { animation-delay: 0.11s; }
.post-card:nth-child(4) { animation-delay: 0.14s; }

/* Smooth tab transitions */
.tab-content {
    transition: opacity 0.25s ease, transform 0.25s ease;
}

.tab-content:not(.active) {
    opacity: 0;
    transform: translateY(8px);
}

.tab-content.active {
    opacity: 1;
    transform: translateY(0);
}
/* ===============================
   COMMENT VISIBILITY FIX (DARK MODE)
================================= */

/* Comment bubble background */
.comment-single {
    background: rgba(2, 6, 23, 0.9);
    color: #e5e7eb; /* main readable text */
    border: 1px solid rgba(148, 163, 184, 0.25);
}

/* Comment author name */
.c-author {
    color: #38bdf8; /* neon blue for name */
}

/* Comments area spacing */
.comments-area {
    color: #e5e7eb;
}

/* Comment input (write comment box) */
.c-box {
    background: rgba(2, 6, 23, 0.85);
    color: #e5e7eb;
    border: 1px solid rgba(148, 163, 184, 0.3);
}

/* Comment input placeholder */
.c-box::placeholder {
    color: #94a3b8;
}

/* Comment send button */
.c-btn {
    color: #38bdf8;
}

</style>

<div class="community-wrapper">
    
    <!-- ================= COMMUNITY INTRO ================= -->
<div style="
    max-width:1000px;
    margin:0 auto 30px auto;
    background:#ffffff;
    border-radius:16px;
    padding:25px 30px;
    box-shadow:0 10px 30px rgba(0,0,0,0.08);
    border:1px solid #e2e8f0;
">
    <h2 style="margin-top:0; color:#0f172a; font-family:'Playfair Display', serif;">
        Welcome to the Wise Invest Community
    </h2>

    <p style="color:#334155; line-height:1.7;">
        This is a private, education-focused investing community created for serious learners.
        Our goal is to help members understand global markets, manage risk responsibly,
        and grow with discipline — not hype.
    </p>

    <div style="
        background:#f8fafc;
        border-left:4px solid #d4af37;
        padding:15px 20px;
        border-radius:8px;
        margin:20px 0;
        color:#334155;
    ">
        <strong>Important:</strong>  
        This is <b>NOT</b> a signal group.  
        There are no guaranteed profits, no paid tips, and no financial advice.
        Education and discussion come first.
    </div>

    <h4 style="margin-bottom:10px; color:#0f172a;">Community Guidelines</h4>
    <ul style="color:#475569; line-height:1.8; padding-left:20px;">
        <li>Be respectful and professional at all times</li>
        <li>No spam, promotions, or signal selling</li>
        <li>Focus on learning, analysis, and long-term thinking</li>
        <li>Respect different experience levels (beginners are welcome)</li>
        <li>Admins reserve the right to remove harmful content</li>
    </ul>
</div>
    
    <div class="comm-tabs">
    <div class="tab-btn active" onclick="switchTab('feed')">
        <i class="fas fa-rss"></i> Community Feed
    </div>
    <div class="tab-btn" onclick="switchTab('chat')">
        <i class="fas fa-comments"></i> Live Discussion
    </div>
</div>

    <div id="tab-feed" class="tab-content active">
        <div class="feed-container">
            
            <div class="create-post-card">
    <div class="cp-header">
        <div class="cp-avatar-small"><?php echo substr($_SESSION['user_name'], 0, 1); ?></div>
        <span>Create Post</span>
    </div>

    <!-- GENTLE REMINDER -->
    <div style="
        background:#f8fafc;
        border-left:4px solid #d4af37;
        padding:12px 16px;
        border-radius:8px;
        margin-bottom:15px;
        font-size:0.9rem;
        color:#334155;
    ">
        💡 Tip: Share questions, insights, or learning experiences.  
        This community is education-first — not a signal group.
    </div>

    <!-- CREATE POST FORM -->
    <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="action" value="create_post">

        <textarea
            name="content"
            class="cp-input"
            rows="2"
            placeholder="Share an insight, question, or learning (education-focused)"
        ></textarea>

        <div id="extra-fields" style="display:block; margin-bottom:10px;">
            <input
                type="text"
                name="video_link"
                class="cp-input"
                style="padding:10px; font-size:0.9rem;"
                placeholder="Paste YouTube Link (Optional)"
            >
        </div>

        <div class="cp-tools">
            <label class="btn-tool photo">
                <i class="fas fa-camera"></i> Photo
                <input
                    type="file"
                    name="post_image"
                    accept="image/*"
                    style="display:none;"
                    onchange="previewImage(this)"
                >
            </label>

            <button type="submit" class="cp-post-btn">Post</button>
        </div>

        <div id="img-preview" style="margin-top:15px; display:none;">
            <img
                id="preview-src"
                src=""
                style="max-height:150px; border-radius:8px; border:1px solid #ddd;"
            >
        </div>
    </form>
</div>


            <?php
            // Fetch Posts
            $posts_sql = "SELECT p.*, u.fullname FROM social_posts p JOIN users u ON p.user_id = u.id ORDER BY p.created_at DESC LIMIT 20";
            if (isset($conn)) {
                $posts_res = $conn->query($posts_sql);

                if ($posts_res && $posts_res->num_rows > 0) {
                    while($post = $posts_res->fetch_assoc()) {
                        
                        // REACTION DATA
                        $pid = $post['id'];
                        $uid = $_SESSION['user_id'];
                        
                        $r_sql = "SELECT reaction_type, COUNT(*) as cnt FROM post_reactions WHERE post_id=$pid GROUP BY reaction_type";
                        $r_res = $conn->query($r_sql);
                        $reacts = ['like'=>0, 'love'=>0, 'wow'=>0, 'dislike'=>0];
                        if($r_res) { while($r = $r_res->fetch_assoc()) { $reacts[$r['reaction_type']] = $r['cnt']; } }

                        $my_r_sql = "SELECT reaction_type FROM post_reactions WHERE post_id=$pid AND user_id=$uid";
                        $my_r_res = $conn->query($my_r_sql);
                        $my_react = ($my_r_res && $my_r_res->num_rows > 0) ? $my_r_res->fetch_assoc()['reaction_type'] : '';
                        
                        // NEW: CHECK OWNERSHIP
                        $is_owner = ($post['user_id'] == $_SESSION['user_id']);
                        ?>
                        <div class="post-card">
                            <div class="post-header">
                                <div class="p-avatar"><?php echo substr($post['fullname'], 0, 1); ?></div>
                                <div class="p-info">
                                    <h4><?php echo $post['fullname']; ?></h4>
                                    <span><?php echo date('M j \a\t g:i a', strtotime($post['created_at'])); ?></span>
                                </div>
                                
                                <?php if($is_owner): ?>
                                <div class="post-options">
                                    <button class="opt-btn" onclick="toggleMenu(<?php echo $pid; ?>)"><i class="fas fa-ellipsis-v"></i></button>
                                    <div id="menu-<?php echo $pid; ?>" class="opt-menu">
                                        <button class="opt-item" onclick="enableEdit(<?php echo $pid; ?>)"><i class="fas fa-edit"></i> Edit</button>
                                        <form method="POST" onsubmit="return confirm('Are you sure you want to delete this post?');">
                                            <input type="hidden" name="action" value="delete_post">
                                            <input type="hidden" name="post_id" value="<?php echo $pid; ?>">
                                            <button type="submit" class="opt-item danger"><i class="fas fa-trash"></i> Delete</button>
                                        </form>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="post-content" id="content-view-<?php echo $pid; ?>">
                                <?php echo nl2br(htmlspecialchars($post['content'])); ?>
                            </div>

                            <?php if($is_owner): ?>
                            <div id="content-edit-<?php echo $pid; ?>" style="display:none; padding:15px;">
                                <form method="POST" class="edit-post-form">
                                    <input type="hidden" name="action" value="edit_post">
                                    <input type="hidden" name="post_id" value="<?php echo $pid; ?>">
                                    <textarea name="content" rows="3"><?php echo htmlspecialchars($post['content']); ?></textarea>
                                    <div style="display:flex; justify-content:flex-end; gap:10px;">
                                        <button type="button" class="btn-tool" onclick="cancelEdit(<?php echo $pid; ?>)">Cancel</button>
                                        <button type="submit" class="cp-post-btn">Save</button>
                                    </div>
                                </form>
                            </div>
                            <?php endif; ?>

                            <?php if(!empty($post['image_url']) || !empty($post['video_link'])): ?>
                                <div class="post-visuals">
                                    <?php if(!empty($post['image_url'])): ?>
                                        <img src="<?php echo $post['image_url']; ?>" alt="Post Image">
                                    <?php endif; ?>
                                    <?php if(!empty($post['video_link'])): ?>
                                        <iframe src="<?php echo $post['video_link']; ?>" allowfullscreen></iframe>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>

                            <div class="post-footer">
                                <div class="reaction-bar">
                                    <button class="react-btn <?php echo ($my_react=='like')?'active':''; ?>" onclick="sendReaction(this, <?php echo $pid; ?>, 'like')">
                                        <i class="fas fa-thumbs-up"></i> Like <span class="react-count"><?php echo ($reacts['like']>0)?$reacts['like']:''; ?></span>
                                    </button>
                                    <button class="react-btn <?php echo ($my_react=='love')?'active':''; ?>" onclick="sendReaction(this, <?php echo $pid; ?>, 'love')">
                                        <i class="fas fa-heart" style="color:<?php echo ($my_react=='love')?'#ef4444':''; ?>"></i> Love <span class="react-count"><?php echo ($reacts['love']>0)?$reacts['love']:''; ?></span>
                                    </button>
                                    <button class="react-btn <?php echo ($my_react=='wow')?'active':''; ?>" onclick="sendReaction(this, <?php echo $pid; ?>, 'wow')">
                                        <i class="fas fa-surprise" style="color:<?php echo ($my_react=='wow')?'#eab308':''; ?>"></i> Wow <span class="react-count"><?php echo ($reacts['wow']>0)?$reacts['wow']:''; ?></span>
                                    </button>
                                    <button class="react-btn <?php echo ($my_react=='dislike')?'active':''; ?>" onclick="sendReaction(this, <?php echo $pid; ?>, 'dislike')">
                                        <i class="fas fa-thumbs-down"></i> Dislike <span class="react-count"><?php echo ($reacts['dislike']>0)?$reacts['dislike']:''; ?></span>
                                    </button>
                                </div>

                                <?php
                                $cmt_sql = "SELECT c.*, u.fullname FROM social_comments c JOIN users u ON c.user_id = u.id WHERE post_id = $pid ORDER BY c.created_at ASC";
                                $cmt_res = $conn->query($cmt_sql);
                                ?>
                                <div class="comments-area">
                                    <?php while($cmt = $cmt_res->fetch_assoc()): ?>
                                        <div class="comment-single">
                                            <span class="c-author"><?php echo $cmt['fullname']; ?></span>
                                            <?php echo htmlspecialchars($cmt['comment']); ?>
                                        </div><br>
                                    <?php endwhile; ?>
                                </div>

                                <form method="POST" class="comment-form">
                                    <input type="hidden" name="action" value="add_comment">
                                    <input type="hidden" name="post_id" value="<?php echo $post['id']; ?>">
                                    <input type="text" name="comment" class="c-box" placeholder="Write a comment..." required>
                                    <button type="submit" class="c-btn">Send</button>
                                </form>
                            </div>
                        </div>
                        <?php
                    }
                } else {
                    echo "<div style='text-align:center; padding:40px; color:#94a3b8;'><i class='fas fa-newspaper' style='font-size:40px; margin-bottom:10px;'></i><br>No posts yet. Start the conversation!</div>";
                }
            }
            ?>
        </div>
    </div>

    <div id="tab-chat" class="tab-content">
        <div class="chat-wrapper-inner">
            <div class="chat-header">
                <div>
                    <h2 style="font-family:'Playfair Display'; margin:0; font-size:1.5rem;">Wise Chat</h2>
                    <span style="font-size:0.8rem; color:#94a3b8;">Type @name to mention someone!</span>
                </div>
                <div style="background:#ef4444; padding:4px 10px; border-radius:20px; font-size:0.7rem; font-weight:700;">LIVE</div>
            </div>

            <div class="chat-box" id="chat-box">
                <div style="text-align:center; color:#94a3b8; margin-top:20px;">Loading conversation...</div>
            </div>

            <form id="chat-form" class="chat-input-area">
                <input type="text" id="msg-input" class="c-input" placeholder="Type a message..." autocomplete="off">
                <button type="submit" class="c-send"><i class="fas fa-paper-plane"></i></button>
            </form>
        </div>
    </div>

</div>

<script>
    // 1. IMAGE PREVIEW
    function previewImage(input) {
        const preview = document.getElementById('img-preview');
        const img = document.getElementById('preview-src');
        if (input.files && input.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                img.src = e.target.result;
                preview.style.display = 'block';
            }
            reader.readAsDataURL(input.files[0]);
        } else {
            preview.style.display = 'none';
        }
    }

    // 2. TAB SWITCHER
    function switchTab(tabName) {
    document.querySelectorAll('.tab-content').forEach(el => {
        el.classList.remove('active');
    });

    document.querySelectorAll('.tab-btn').forEach(el => {
        el.classList.remove('active');
    });

    const activeTab = document.getElementById('tab-' + tabName);
    activeTab.classList.add('active');

    const btns = document.querySelectorAll('.tab-btn');
    if (tabName === 'feed') btns[0].classList.add('active');
    if (tabName === 'chat') btns[1].classList.add('active');
}


    // 3. SEND REACTION
    function sendReaction(btn, postId, type) {
        const allBtns = btn.parentNode.querySelectorAll('.react-btn');
        allBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');

        const formData = new FormData();
        formData.append('action', 'react');
        formData.append('post_id', postId);
        formData.append('type', type);

        fetch('community.php', { method: 'POST', body: formData })
        .then(res => res.text())
        .then(data => {
            if(data.trim() === 'success') { location.reload(); }
        });
    }

    // 4. NEW: POST MENU TOGGLES
    function toggleMenu(id) {
        document.getElementById('menu-'+id).classList.toggle('show');
    }
    // Close menus when clicking outside
    window.onclick = function(event) {
        if (!event.target.matches('.opt-btn') && !event.target.matches('.opt-btn i')) {
            var dropdowns = document.getElementsByClassName("opt-menu");
            for (var i = 0; i < dropdowns.length; i++) {
                if (dropdowns[i].classList.contains('show')) {
                    dropdowns[i].classList.remove('show');
                }
            }
        }
    }

    // 5. NEW: EDIT MODE TOGGLES
    function enableEdit(id) {
        document.getElementById('content-view-'+id).style.display = 'none';
        document.getElementById('content-edit-'+id).style.display = 'block';
    }
    function cancelEdit(id) {
        document.getElementById('content-view-'+id).style.display = 'block';
        document.getElementById('content-edit-'+id).style.display = 'none';
    }

    // 6. CHAT LOGIC
    const chatBox = document.getElementById('chat-box');
    const chatForm = document.getElementById('chat-form');
    const msgInput = document.getElementById('msg-input');
    const currentUser = "<?php echo isset($_SESSION['user_name']) ? $_SESSION['user_name'] : ''; ?>";

    function fetchMessages() {
        if(!document.getElementById('tab-chat').classList.contains('active')) return;
        fetch('chat_api.php?action=fetch')
        .then(response => response.json())
        .then(data => {
            chatBox.innerHTML = '';
            data.forEach(msg => {
                const isMe = msg.user === currentUser;
                const alignment = isMe ? 'me' : '';
                let userDisplay = msg.user;
                if(msg.type === 'premium') userDisplay += ' <i class="fas fa-crown premium-badge"></i>';

                let content = msg.msg.replace(/@(\w+)/g, '<span class="mention-highlight">@$1</span>');
                let bubbleClass = "msg-bubble";
                if(msg.msg.toLowerCase().includes('@' + currentUser.toLowerCase())) {
                    bubbleClass += " mentioned-me";
                }

                const html = `
                    <div class="msg-row ${alignment}">
                        <small style="color:#64748b; margin:0 5px;">${userDisplay}</small>
                        <div class="${bubbleClass}">${content}</div>
                    </div>
                `;
                chatBox.innerHTML += html;
            });
        });
    }

    if(chatForm) {
        chatForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const text = msgInput.value.trim();
            if(text !== "") {
                const formData = new FormData();
                formData.append('message', text);
                fetch('chat_api.php?action=send', { method: 'POST', body: formData }).then(() => {
                    msgInput.value = '';
                    fetchMessages();
                    setTimeout(() => chatBox.scrollTop = chatBox.scrollHeight, 200);
                });
            }
        });
    }
    setInterval(fetchMessages, 3000);
    document.querySelectorAll('.post-card').forEach(card => {
    card.addEventListener('mousemove', e => {
        const r = card.getBoundingClientRect();
        card.style.backgroundPosition =
            `${((e.clientX - r.left) / r.width) * 100}% 
             ${((e.clientY - r.top) / r.height) * 100}%`;
    });
});
</script>

<?php include 'includes/footer.php'; ?>