<?php include 'includes/header.php'; ?>

<div class="page-hero">
    <div class="hero-content">
        <h1 class="hero-title lang-en">About Wise Invest</h1>
        <h1 class="hero-title lang-mm" style="display:none">Wise Invest အကြောင်း</h1>
        
        <p class="hero-subtitle lang-en">Your Trusted Partner in Wealth Creation</p>
        <p class="hero-subtitle lang-mm" style="display:none">ကြွယ်ဝချမ်းသာမှု တည်ဆောက်ရာတွင် သင်၏ ယုံကြည်စိတ်ချရသော မိတ်ဖက်</p>
    </div>
</div>

<section class="about-section">
    <div class="power-grid">
        
        <div class="power-col-text">
            <h4 style="color:var(--gold); font-weight:bold; letter-spacing:1px; margin-bottom:10px;">
                <span class="lang-en">INTRODUCTION</span>
                <span class="lang-mm" style="display:none">မိတ်ဆက်</span>
            </h4>
            
            <h2 style="font-family:'Playfair Display', serif; font-size:2.5rem; color:#0f172a; margin-bottom:20px; line-height:1.2;">
                <span class="lang-en">Mingalabar...</span>
                <span class="lang-mm" style="display:none">မင်္ဂလာပါ...</span>
            </h2>
            
            <p style="color:#64748b; font-size:1.1rem; line-height:1.8; margin-bottom:20px;">
                <span class="lang-en">We would like to introduce our Vision, Mission, and Core Values clearly to you. We are here to simplify the stock market for everyone.</span>
                <span class="lang-mm" style="display:none">ကျွန်တော်တိုရဲ့ Vision, Mission, Core Values ကို တိတိကျကျ မိတ်ဆက်ချင်ပါတယ်။</span>
            </p>
            
            <p style="font-style:italic; color:#94a3b8;">
                <span class="lang-en">"We will share more about Investment and Stocks soon."</span>
                <span class="lang-mm" style="display:none">"မကြာခင်မှာ Investment အကြောင်း Stocks များအကြောင်းတိုကို မျှဝေသွားးပါမယ်။"</span>
            </p>
        </div>

        <div class="power-col-cards">
            <div class="vm-card">
                <div class="vm-title"><i class="fas fa-telescope vm-icon"></i> VISION</div>
                <p class="lang-en">To become the No. 1 Investment Service Provider for Myanmar people.</p>
                <p class="lang-mm" style="display:none">မြန်မာလူမျိုးအတွက် နံပါတ် ၁ Investment Service Provider ဖြစ်လာရန်။</p>
            </div>

            <div class="vm-card">
                <div class="vm-title"><i class="fas fa-bullseye vm-icon"></i> MISSION</div>
                <p class="lang-en">We exist to help Myanmar people build their own wealth through Stocks.</p>
                <p class="lang-mm" style="display:none">မြန်မာ လူမျိုးများ ကြွယ်ဝ ချမ်းသာမှုကို ကိုယ်တိုင်တည်ဆောက်နိုင်ရန် Stocks နဲ့ အကူအညီပေးဖိုတည်ရှိနေတာဖြစ်ပါတယ်။</p>
            </div>
        </div>

    </div>
</section>

<section class="values-section">
    <h2 style="font-family:'Playfair Display', serif; font-size:2.5rem; margin-bottom:10px;">
        <span class="lang-en">Core Values</span>
        <span class="lang-mm" style="display:none">အဓိက တန်ဖိုးများ</span>
    </h2>
    <div style="width:50px; height:3px; background:var(--gold); margin:0 auto;"></div>

    <div class="values-row">
        <div class="value-box">
            <div class="value-icon-box"><i class="fas fa-shield-alt"></i></div>
            <h3 style="margin-bottom:10px;">1. Honesty</h3>
            <p class="lang-en" style="color:#cbd5e1;">Trustworthy Transparency</p>
            <p class="lang-mm" style="display:none; color:#cbd5e1;">ယုံကြည်စိတ်ချလိုရတဲ့ Transparency</p>
        </div>

        <div class="value-box">
            <div class="value-icon-box"><i class="fas fa-bolt"></i></div>
            <h3 style="margin-bottom:10px;">2. Speed</h3>
            <p class="lang-en" style="color:#cbd5e1;">Fast Execution</p>
            <p class="lang-mm" style="display:none; color:#cbd5e1;">အလျှင်အမြန်လုပ်ဆောင်ခြင်း</p>
        </div>

        <div class="value-box">
            <div class="value-icon-box"><i class="fas fa-gem"></i></div>
            <h3 style="margin-bottom:10px;">3. Value Creation</h3>
            <p class="lang-en" style="color:#cbd5e1;">Creating value for client's future</p>
            <p class="lang-mm" style="display:none; color:#cbd5e1;">Client အနာဂတ်ငွေကြေးတိုးတက်အောင် တန်ဖိုးဖန်တီးခြင်း</p>
        </div>
    </div>
</section>

<section class="team-section">
    <h2 style="font-family:'Playfair Display', serif; font-size:2.5rem; color:#0f172a;">
        <span class="lang-en">Meet Our Experts</span>
        <span class="lang-mm" style="display:none">ကျွန်ုပ်တို့၏ ကျွမ်းကျင်ပညာရှင်များ</span>
    </h2>
    <div style="width:60px; height:3px; background:var(--gold); margin:15px auto;"></div>
    <p style="color:#64748b;">The team behind Wise Invest</p>

    <div class="team-grid">
        
        <div class="team-member-circle">
            <div class="avatar-box">
                <img src="images/team1.jpg" alt="Ismai'L" class="avatar-img">
            </div>
            <div class="t-name">Ismai'L</div> <div class="t-role">Customer Relations</div> <div class="t-social">
                <a href="#"><i class="fab fa-linkedin"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
            </div>
        </div>

        <div class="team-member-circle">
            <div class="avatar-box">
                <img src="images/team2.jpg" alt="Aung Khin Sint" class="avatar-img">
            </div>
            <div class="t-name">Aung Khin Sint</div> <div class="t-role">Consultant</div> <div class="t-social">
                <a href="#"><i class="fab fa-linkedin"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
            </div>
        </div>

        <div class="team-member-circle">
            <div class="avatar-box">
                <img src="images/team3.jpg" alt="Aung Ko Ko" class="avatar-img">
            </div>
            <div class="t-name">Aung Ko Ko</div> <div class="t-role">Technician</div> <div class="t-social">
                <a href="#"><i class="fab fa-linkedin"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
            </div>
        </div>

        <div class="team-member-circle">
            <div class="avatar-box">
                <img src="images/team4.jpg" alt="Yin Lae" class="avatar-img">
            </div>
            <div class="t-name">Yin Lae</div> <div class="t-role">Account & Finance</div> <div class="t-social">
                <a href="#"><i class="fab fa-linkedin"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
            </div>
        </div>

    </div>
</section>

<?php include 'includes/footer.php'; ?>