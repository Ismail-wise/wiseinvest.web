console.log("Wise Invest: Unified System Ready");

document.addEventListener('DOMContentLoaded', () => {

    /* ================= HEADER SCROLL ================= */
    const header = document.getElementById('main-header');
    if (header) {
        window.addEventListener('scroll', () => {
            header.classList.toggle('scrolled', window.scrollY > 50);
        });
    }

    /* ================= MOBILE MENU ================= */
    const menuToggle = document.getElementById('mobile-menu-toggle');
    const mobileNav = document.getElementById('mobile-nav-container');
    if (menuToggle && mobileNav) {
        menuToggle.addEventListener('click', () => {
            menuToggle.classList.toggle('active');
            mobileNav.classList.toggle('active');
            document.body.classList.toggle('no-scroll');
        });
    }

    /* ================= LANGUAGE SWITCH ================= */
    const langSwitcher = document.getElementById('lang-switcher');
    if (langSwitcher) {
        langSwitcher.addEventListener('click', () => {
            const current = langSwitcher.querySelector('span').textContent.trim().toUpperCase();
            const newLang = current === 'EN' ? 'mm' : 'en';
            window.location.href = '?lang=' + newLang;
        });
    }

    const applyStaticLanguage = (lang) => {
        document.querySelectorAll('.lang-en').forEach(el => el.style.display = lang === 'mm' ? 'none' : 'block');
        document.querySelectorAll('.lang-mm').forEach(el => el.style.display = lang === 'mm' ? 'block' : 'none');
        if (langSwitcher) langSwitcher.querySelector('span').textContent = lang.toUpperCase();
    };

    applyStaticLanguage(document.documentElement.lang || 'en');

    /* ================= DESKTOP DROPDOWN FIX ================= */
    document.querySelectorAll('.has-dropdown > a').forEach(link => {
        link.addEventListener('click', function (e) {
            if (window.innerWidth > 1024) {
                e.preventDefault();
                const parent = this.parentElement;
                document.querySelectorAll('.has-dropdown').forEach(d => d.classList.remove('dropdown-active'));
                parent.classList.toggle('dropdown-active');
                e.stopPropagation();
            }
        });
    });

    window.addEventListener('click', () => {
        document.querySelectorAll('.has-dropdown').forEach(d => d.classList.remove('dropdown-active'));
    });

    /* ================= AUTO OPEN FIRST CALC TAB ================= */
    const firstTab = document.querySelector('.calc-tab-btn');
    if (firstTab) firstTab.click();
});

/* ================= TAB SWITCH ================= */
function switchCalc(calcId, el) {
    document.querySelectorAll('.calc-workspace').forEach(c => c.style.display = 'none');
    document.querySelectorAll('.calc-tab-btn').forEach(b => b.classList.remove('active'));

    const box = document.getElementById('calc-' + calcId);
    if (box) box.style.display = 'block';

    if (el) el.classList.add('active');
}

/* ================= HELPER ================= */
function val(id) {
    const el = document.getElementById(id);
    return el ? parseFloat(el.value) || 0 : 0;
}
function out(id, txt) {
    const el = document.getElementById(id);
    if (el) el.innerHTML = txt;
}
let FC = {
  annual: 0,
  mffc: 0
};

function calculateInflationAdjustedExpense() {
  const annual = parseFloat(document.getElementById("ia-annual").value);
  const years = parseFloat(document.getElementById("ia-years").value);
  const inflation = parseFloat(document.getElementById("ia-inflation").value) / 100;

  if (!annual || years < 0 || inflation < 0) {
    document.getElementById("ia-result").innerText =
      "Please enter valid values.";
    return;
  }

  const futureExpense = annual * Math.pow(1 + inflation, years);

  document.getElementById("ia-result").innerHTML =
    `You will need <strong>${futureExpense.toFixed(2)}</strong> per year in ${years} years.`;
}