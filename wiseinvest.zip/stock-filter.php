<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* =========================
   PREMIUM ACCESS PROTECTION
========================= */

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'premium') {
    header("Location: index.php");
    exit();
}

$page_title = "Stock Filter";
include 'header.php';

/* =========================
   FILTER DATA
========================= */

$filters = [
[
'id'=>1,
'category'=>'Growth',
'title'=>'Revenue Growth',
'threshold'=>'>= 12%',
'score'=>84,
'short'=>'Sales expansion rate',
'explanation_mm'=>'ကုမ္ပဏီ၏ ဝင်ငွေတိုးတက်နှုန်းကို တိုင်းတာသော filter ဖြစ်သည်။'
],

[
'id'=>2,
'category'=>'Growth',
'title'=>'EPS Growth',
'threshold'=>'>= 10%',
'score'=>80,
'short'=>'Earnings per share momentum',
'explanation_mm'=>'EPS Growth သည် share တစ်စုလျှင် အမြတ်တိုးတက်မှုကို ပြသသည်။'
],

[
'id'=>3,
'category'=>'Growth',
'title'=>'5-Year Revenue Stability',
'threshold'=>'>= 75/100',
'score'=>78,
'short'=>'Consistency over 5 years',
'explanation_mm'=>'၅ နှစ်အတွင်း ဝင်ငွေတည်ငြိမ်မှုကို စစ်ဆေးသည်။'
],

[
'id'=>4,
'category'=>'Growth',
'title'=>'Operating Income Growth',
'threshold'=>'>= 10%',
'score'=>76,
'short'=>'Core business earnings growth',
'explanation_mm'=>'Operating Income Growth သည် အဓိကလုပ်ငန်းမှ အမြတ်တိုးတက်မှုကို ညွှန်ပြသည်။'
],

[
'id'=>5,
'category'=>'Profitability',
'title'=>'Return on Equity (ROE)',
'threshold'=>'>= 15%',
'score'=>88,
'short'=>'Profit generated from shareholder capital',
'explanation_mm'=>'ROE သည် shareholder equity အပေါ် အမြတ်ထုတ်နိုင်မှုကို တိုင်းတာသည်။'
],

[
'id'=>6,
'category'=>'Profitability',
'title'=>'Net Profit Margin',
'threshold'=>'>= 12%',
'score'=>82,
'short'=>'Bottom-line efficiency',
'explanation_mm'=>'Net Profit Margin သည် ဝင်ငွေထဲမှ သန့်ရှင်းသောအမြတ် ရာခိုင်နှုန်းကို ဖော်ပြသည်။'
],

[
'id'=>7,
'category'=>'Profitability',
'title'=>'ROIC',
'threshold'=>'>= 12%',
'score'=>85,
'short'=>'Return on invested capital',
'explanation_mm'=>'ROIC သည် business capital အပေါ် return ကို ပြသသည်။'
],

[
'id'=>8,
'category'=>'Profitability',
'title'=>'Free Cash Flow',
'threshold'=>'Positive',
'score'=>90,
'short'=>'Cash generation ability',
'explanation_mm'=>'Free Cash Flow Positive ဆိုသည်မှာ cash generation ကောင်းကြောင်း ပြသည်။'
],

[
'id'=>9,
'category'=>'Financial Strength',
'title'=>'Debt to Equity',
'threshold'=>'<=1.0',
'score'=>73,
'short'=>'Leverage ratio',
'explanation_mm'=>'Debt to Equity သည် leverage risk ကို ဖော်ပြသည်။'
],

[
'id'=>10,
'category'=>'Financial Strength',
'title'=>'Interest Coverage',
'threshold'=>'>=5x',
'score'=>79,
'short'=>'Interest payment ability',
'explanation_mm'=>'Interest Coverage မြင့်လျှင် default risk နည်းသည်။'
],

[
'id'=>11,
'category'=>'Financial Strength',
'title'=>'Altman Z Score',
'threshold'=>'>=3',
'score'=>81,
'short'=>'Bankruptcy risk indicator',
'explanation_mm'=>'Altman Z Score သည် bankruptcy risk ကို ခန့်မှန်းရန် အသုံးပြုသည်။'
],

[
'id'=>12,
'category'=>'Valuation',
'title'=>'P/E Ratio',
'threshold'=>'<=25',
'score'=>68,
'short'=>'Price vs earnings',
'explanation_mm'=>'PE Ratio သည် valuation metric တစ်ခုဖြစ်သည်။'
],

[
'id'=>13,
'category'=>'Valuation',
'title'=>'PEG Ratio',
'threshold'=>'<=1.5',
'score'=>74,
'short'=>'PE adjusted for growth',
'explanation_mm'=>'PEG Ratio သည် growth-adjusted valuation ဖြစ်သည်။'
],

[
'id'=>14,
'category'=>'Valuation',
'title'=>'Price to FCF',
'threshold'=>'<=20',
'score'=>71,
'short'=>'Price vs free cash flow',
'explanation_mm'=>'FCF valuation metric ဖြစ်သည်။'
],

[
'id'=>15,
'category'=>'Valuation',
'title'=>'EV / EBITDA',
'threshold'=>'<=14',
'score'=>70,
'short'=>'Enterprise valuation',
'explanation_mm'=>'EV / EBITDA သည် valuation comparison metric ဖြစ်သည်။'
],

[
'id'=>16,
'category'=>'Qualitative',
'title'=>'Competitive Moat',
'threshold'=>'>=80',
'score'=>86,
'short'=>'Competitive advantage',
'explanation_mm'=>'Moat ဆိုသည်မှာ long-term competitive advantage ဖြစ်သည်။'
]
];

/* =========================
   SCORE COLOR
========================= */

function score_color($score){

if($score >=85) return "excellent";
if($score >=75) return "good";
if($score >=65) return "watch";
return "weak";

}

?>

<style>

.stock-grid{
display:grid;
grid-template-columns:repeat(auto-fit,minmax(320px,1fr));
gap:20px;
margin-top:30px;
}

.stock-card{

background:#0f172a;
border-radius:20px;
padding:22px;
border:1px solid rgba(255,255,255,0.08);
transition:.25s;
}

.stock-card:hover{
transform:translateY(-5px);
border-color:#22d3ee;
}

.stock-category{
font-size:11px;
letter-spacing:1px;
color:#94a3b8;
text-transform:uppercase;
margin-bottom:8px;
}

.stock-title{
font-size:20px;
margin:0;
color:white;
}

.stock-short{
font-size:13px;
color:#94a3b8;
margin-top:5px;
}

.stock-score{
font-size:30px;
font-weight:800;
}

.stock-meta{
margin:15px 0;
font-size:13px;
color:#94a3b8;
display:flex;
justify-content:space-between;
}

.stock-bar{
height:10px;
background:#111827;
border-radius:100px;
overflow:hidden;
}

.stock-bar-fill{
height:100%;
border-radius:100px;
}

.excellent{color:#34d399;}
.good{color:#60a5fa;}
.watch{color:#fbbf24;}
.weak{color:#f87171;}

.fill-excellent{background:linear-gradient(90deg,#34d399,#10b981);}
.fill-good{background:linear-gradient(90deg,#60a5fa,#3b82f6);}
.fill-watch{background:linear-gradient(90deg,#fbbf24,#f59e0b);}
.fill-weak{background:linear-gradient(90deg,#fb7185,#ef4444);}

</style>

<div class="stock-grid">

<?php foreach($filters as $filter):

$score=$filter['score'];
$color=score_color($score);

?>

<div class="stock-card">

<div class="stock-category">
<?=htmlspecialchars($filter['category'])?>
</div>

<h3 class="stock-title">
<?=htmlspecialchars($filter['title'])?>
</h3>

<div class="stock-short">
<?=htmlspecialchars($filter['short'])?>
</div>

<div class="stock-score <?=$color?>">
<?=$score?>
</div>

<div class="stock-meta">
<span>Threshold</span>
<span><?=$filter['threshold']?></span>
</div>

<div class="stock-bar">
<div class="stock-bar-fill fill-<?=$color?>" style="width:<?=$score?>%"></div>
</div>

<p style="margin-top:15px;color:#cbd5f5;font-size:14px;line-height:1.7;">
<?=htmlspecialchars($filter['explanation_mm'])?>
</p>

</div>

<?php endforeach; ?>

</div>

<?php
if(file_exists('footer.php')){
include 'footer.php';
}
?>