<?php
// FMP API Key (Keep this file private)
define('FMP_API_KEY', 'IBerQG3Y5BPP6ck50JGPREV5w4iiHJ60');
?>
