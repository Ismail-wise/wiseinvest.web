<?php 
include 'includes/db.php'; 
include 'includes/header.php'; 

// 1. GET THE ID FROM URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "<script>window.location.href='articles.php';</script>";
    exit();
}

$id = intval($_GET['id']);

// 2. FETCH SPECIFIC ARTICLE
$sql = "SELECT * FROM articles WHERE id = $id";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $art = $result->fetch_assoc();
    $title = htmlspecialchars($art['title']);
    $content = nl2br(htmlspecialchars($art['content'])); // Convert line breaks to HTML
    $date = date('F j, Y', strtotime($art['created_at']));
    $cat = htmlspecialchars($art['category']);
    $img = !empty($art['image']) ? $art['image'] : 'https://images.unsplash.com/photo-1611974765270-ca12586343bb?q=80&w=1200';
} else {
    echo "<div style='padding:50px; text-align:center;'><h2>Article not found</h2><a href='articles.php'>Go Back</a></div>";
    include 'includes/footer.php';
    exit();
}
?>

<div style="height: 400px; background: linear-gradient(rgba(15, 23, 42, 0.7), rgba(15, 23, 42, 0.7)), url('<?php echo $img; ?>'); background-size: cover; background-position: center; display: flex; align-items: flex-end; padding-bottom: 50px;">
    <div style="max-width: 800px; margin: 0 auto; padding: 0 20px; width: 100%; text-align: center; color: white;">
        <span style="background: #d4af37; color: #0f172a; padding: 5px 15px; border-radius: 20px; font-weight: bold; font-size: 0.9rem; text-transform: uppercase;"><?php echo $cat; ?></span>
        <h1 style="font-size: 3rem; margin: 15px 0; font-family: 'Playfair Display', serif;"><?php echo $title; ?></h1>
        <div style="font-size: 1.1rem; opacity: 0.9;"><i class="far fa-calendar-alt"></i> <?php echo $date; ?></div>
    </div>
</div>

<div style="background: white; min-height: 500px;">
    <div style="max-width: 800px; margin: -50px auto 50px auto; background: white; padding: 50px; border-radius: 12px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); position: relative;">
        
        <div style="line-height: 1.8; font-size: 1.1rem; color: #334155;">
            <?php echo $content; ?>
        </div>

        <hr style="margin: 40px 0; border: 0; border-top: 1px solid #e2e8f0;">

        <div style="text-align: center;">
            <a href="articles.php" style="display: inline-block; padding: 12px 30px; border: 2px solid #0f172a; color: #0f172a; text-decoration: none; border-radius: 50px; font-weight: bold; transition: 0.3s;">
                &larr; Back to News
            </a>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>