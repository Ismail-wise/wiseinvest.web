<?php include 'includes/header.php'; ?>

<!-- ================= HOME SPLIT HERO ================= -->
<section class="home-hero-split">

    <!-- LEFT : HERO CONTENT -->
    <div class="hero-left">
        <span class="hero-badge">Global Investment Services</span>

        <h1 class="hero-title">
            Professional Setup for<br>
            <span>Global Brokerage Accounts</span>
        </h1>

        <p class="hero-subtitle">
            We help clients open and configure international brokerage
            and payment accounts safely, legally, and efficiently.
        </p>

        <div class="hero-actions">
            <a href="services.php" class="hero-btn primary">View Services</a>
            <a href="contact.php" class="hero-btn secondary">Talk to Us</a>
        </div>
    </div>

    <!-- RIGHT : COLLECTIONS -->
    <div class="hero-right">

        <!-- IMAGES CARD WITH THUMBNAIL SLIDER -->
        <a href="gallery-images.php" class="collection-card thumb-card">
            <div class="thumb-slider">
    <img src="uploads/gallery/thumbs/img1.jpg" class="active">
    <img src="uploads/gallery/thumbs/img2.jpg">
    <img src="uploads/gallery/thumbs/img3.jpg">
</div>
            <h3>Images</h3>
            <p>Events • Activities • Moments</p>
        </a>

        <!-- VIDEOS CARD WITH THUMBNAIL SLIDER -->
        <a href="gallery-videos.php" class="collection-card thumb-card">
            <div class="thumb-slider">
                <img src="https://img.youtube.com/vi/QnEM0NZXaGA/hqdefault.jpg" class="active">
                <img src="https://img.youtube.com/vi/AhKR62GBlKw/hqdefault.jpg">
                <img src="https://img.youtube.com/vi/BrEChn_Huos/hqdefault.jpg">
            </div>
            <h3>Videos</h3>
            <p>Milestones • Media • Highlights</p>
        </a>

    </div>
</section>

<!-- ================= PREMIUM REVIEWS ================= -->
<section class="home-reviews premium-reviews">

    <div class="reviews-text">
        <h2 class="reviews-title">
            What Our <span>Clients Say</span>
        </h2>
        <p class="reviews-subtitle">
            Authentic feedback from verified Facebook clients
        </p>
    </div>

    <div class="review-stage">
        <div class="review-slider">
            <div class="review-track" id="reviewTrack"></div>
        </div>

        <div class="review-nav">
            <button onclick="prevReview()">‹</button>
            <button onclick="nextReview()">›</button>
        </div>
    </div>

    <a href="https://www.facebook.com/profile.php?id=61584267038170"
       target="_blank"
       class="review-fb-btn">
        View more reviews on Facebook →
    </a>
</section>

<!-- ================= VIDEO MODAL ================= -->
<div class="modal" id="galleryModal">
    <div class="modal-box">
        <span class="modal-close" onclick="closeVideo()">✕</span>
        <h2 id="galleryTitle"></h2>
        <div id="galleryContent"></div>
    </div>
</div>

<!-- ================= INLINE STYLES (HOME ONLY FIXES) ================= -->
<style>
/* Remove link underline / clutter */
.collection-card {
    text-decoration: none;
}

/* Thumbnail slider */
.thumb-slider {
    position: relative;
    width: 100%;
    height: 140px;
    overflow: hidden;
    border-radius: 14px;
    margin-bottom: 16px;
}

.thumb-slider img {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
    opacity: 0;
    transition: opacity .6s ease;
}

.thumb-slider img.active {
    opacity: 1;
}

/* Tighten right column spacing */
.hero-right {
    gap: 24px;
}

/* ===== WHITE LINE FIX ===== */

/* Make last section blend into footer */
.home-reviews {
    margin-bottom: 0 !important;
    padding-bottom: 80px;
    background: #020617;
}

/* Prevent layout container from adding space */
main {
    margin-bottom: 0 !important;
    padding-bottom: 0 !important;
}

/* Kill any accidental footer gap */
footer {
    margin-top: 0 !important;
    border-top: none !important;
}
/* === FIX WHITE BAR ABOVE FOOTER (HOME PAGE ONLY) === */

/* Make the main wrapper dark */
main {
    background: #020617 !important;
}

/* Remove any gap below the last section */
.home-reviews {
    margin-bottom: 0 !important;
    padding-bottom: 80px;
    background: #020617;
}

/* Ensure footer touches content */
footer {
    margin-top: 0 !important;
    border-top: none !important;
}
</style>

<!-- ================= INLINE SCRIPTS ================= -->
<script>
/* ===== THUMBNAIL AUTO SLIDER ===== */
document.querySelectorAll('.thumb-slider').forEach(slider => {
    const images = slider.querySelectorAll('img');
    let index = 0;

    setInterval(() => {
        images[index].classList.remove('active');
        index = (index + 1) % images.length;
        images[index].classList.add('active');
    }, 2500);
});

/* ===== VIDEO MODAL ===== */
function openVideo(id) {
    const modal = document.getElementById('galleryModal');
    const title = document.getElementById('galleryTitle');
    const content = document.getElementById('galleryContent');

    title.innerText = "Video";

    content.innerHTML = `
        <div style="position:relative;padding-top:56.25%">
            <iframe
                src="https://www.youtube.com/embed/${id}?autoplay=1"
                style="position:absolute;top:0;left:0;width:100%;height:100%;border:0"
                allow="autoplay; encrypted-media"
                allowfullscreen>
            </iframe>
        </div>
    `;

    modal.classList.add('active');
}

function closeVideo() {
    document.getElementById('galleryModal').classList.remove('active');
    document.getElementById('galleryContent').innerHTML = '';
}

/* ===== REVIEW SLIDER ===== */
document.addEventListener("DOMContentLoaded", () => {

    fetch('gallery-reviews.php')
        .then(res => res.text())
        .then(html => {
            document.getElementById("reviewTrack").innerHTML = html;
        });

    let index = 0;

    window.nextReview = function () {
        const cards = document.querySelectorAll(".review-card");
        if (!cards.length) return;
        index = (index + 1) % cards.length;
        update();
    };

    window.prevReview = function () {
        const cards = document.querySelectorAll(".review-card");
        if (!cards.length) return;
        index = (index - 1 + cards.length) % cards.length;
        update();
    };

    function update() {
        document.getElementById("reviewTrack")
            .style.transform = `translateX(-${index * 100}%)`;
    }

    setInterval(nextReview, 8000);
});
</script>

<?php include 'includes/footer.php'; ?>