<?php include 'includes/header.php'; ?>

<style>

/* ===== GLOBAL STYLE ===== */

body{
background:radial-gradient(circle at top,#020617,#020617);
font-family:Inter,system-ui;
color:#e5e7eb;
}

.wrapper{
max-width:1400px;
margin:auto;
padding:70px 20px;
}

.panel{
background:linear-gradient(145deg,#0f172a,#020617);
border-radius:20px;
padding:40px;
border:1px solid rgba(255,255,255,.05);
box-shadow:0 50px 120px rgba(0,0,0,.8);
}

/* ===== TITLE ===== */

.title{
font-size:30px;
color:#f59e0b;
margin-bottom:30px;
}

/* ===== INPUT GRID ===== */

.input-grid{
display:grid;
grid-template-columns:repeat(auto-fit,minmax(240px,1fr));
gap:20px;
}

/* ===== INPUT STYLE ===== */

label{
font-size:13px;
color:#94a3b8;
display:block;
margin-bottom:4px;
}

input,select{
width:100%;
padding:10px;
border-radius:8px;
border:1px solid #1e293b;
background:#020617;
color:white;
}

/* ===== TOOLTIP ===== */

.tip{
display:inline-flex;
align-items:center;
justify-content:center;
width:16px;
height:16px;
border-radius:50%;
background:#22c55e;
color:#020617;
font-size:11px;
margin-left:6px;
position:relative;
cursor:pointer;
}

.tip-text{
position:absolute;
bottom:130%;
left:50%;
transform:translateX(-50%);
background:#020617;
padding:10px;
border-radius:8px;
width:220px;
font-size:12px;
opacity:0;
pointer-events:none;
transition:.2s;
}

.tip:hover .tip-text{
opacity:1;
}

/* ===== DASHBOARD ===== */

.dashboard{
display:grid;
grid-template-columns:repeat(auto-fit,minmax(180px,1fr));
gap:20px;
margin-top:35px;
}

.metric{
background:#020617;
border:1px solid #1e293b;
border-radius:12px;
padding:20px;
text-align:center;
}

.metric-title{
font-size:12px;
color:#94a3b8;
}

.metric-value{
font-size:24px;
font-weight:700;
color:#fbbf24;
}

/* ===== RESULT GRID ===== */

.result-grid{
margin-top:40px;
display:grid;
grid-template-columns:1fr 1fr;
gap:20px;
}

.result-box{
background:#020617;
border:1px solid #1e293b;
border-radius:12px;
padding:20px;
line-height:1.7;
}

.result-title{
color:#22c55e;
font-weight:700;
margin-bottom:10px;
}

/* ===== CHART ===== */

.chart-box{
margin-top:40px;
background:#020617;
padding:20px;
border-radius:12px;
}

canvas{
width:100%;
height:320px;
}

</style>


<div class="wrapper">
<div class="panel">

<div class="title">Institutional Wealth Simulator</div>

<div class="input-grid">

<div>
<label>Annual Expenses
<span class="tip">?
<span class="tip-text">တစ်နှစ်အတွင်း အသုံးပြုသော စုစုပေါင်းအသုံးစရိတ်</span>
</span>
</label>
<input id="expense" value="40000">
</div>

<div>
<label>Inflation %
<span class="tip">?
<span class="tip-text">ငွေဖောင်းပွမှုနှုန်း</span>
</span>
</label>
<input id="inflation" value="3">
</div>

<div>
<label>Current Assets
<span class="tip">?
<span class="tip-text">လက်ရှိ ရင်းနှီးမြှုပ်နှံထားသော ပိုင်ဆိုင်မှု</span>
</span>
</label>
<input id="assets" value="200000">
</div>

<div>
<label>Annual Savings
<span class="tip">?
<span class="tip-text">နှစ်စဉ် ထပ်မံရင်းနှီးမြှုပ်နှံမည့် ငွေ</span>
</span>
</label>
<input id="savings" value="15000">
</div>

<div>
<label>Expected Return %
<span class="tip">?
<span class="tip-text">နှစ်စဉ် မျှော်လင့်ထားသော ရင်းနှီးမြှုပ်နှံမှုအမြတ်</span>
</span>
</label>
<input id="return" value="7">
</div>

<div>
<label>Retirement Years
<span class="tip">?
<span class="tip-text">Financial freedom ရပြီးနောက် အသုံးစရိတ်ကြာမြင့်ချိန်</span>
</span>
</label>
<input id="life" value="30">
</div>

<div>
<label>Monte Carlo Runs
<span class="tip">?
<span class="tip-text">Risk simulation အတွက် iteration အရေအတွက်</span>
</span>
</label>
<input id="sim" value="1000">
</div>

</div>


<div class="dashboard">

<div class="metric">
<div class="metric-title">Future Expenses</div>
<div id="futureExp" class="metric-value">-</div>
</div>

<div class="metric">
<div class="metric-title">Freedom Capital</div>
<div id="target" class="metric-value">-</div>
</div>

<div class="metric">
<div class="metric-title">Years to Freedom</div>
<div id="yearsFreedom" class="metric-value">-</div>
</div>

<div class="metric">
<div class="metric-title">Success Probability</div>
<div id="prob" class="metric-value">-</div>
</div>

</div>


<div class="result-grid">

<div class="result-box">
<div class="result-title">English Explanation</div>
<div id="eng"></div>
</div>

<div class="result-box">
<div class="result-title">မြန်မာရှင်းလင်းချက်</div>
<div id="bur"></div>
</div>

</div>


<div class="chart-box">
<h3>Wealth Projection</h3>
<canvas id="chart"></canvas>
</div>


</div>
</div>


<script>

/* ===== AUTO CALCULATION ===== */

document.querySelectorAll("input").forEach(i=>{
i.addEventListener("input",runCalc)
})

function runCalc(){

const expense=Number(expenseInput())
const infl=Number(inflationInput())/100
const assets=Number(assetsInput())
const savings=Number(savingsInput())
const r=Number(returnInput())/100
const life=Number(lifeInput())
const sim=Number(simInput())

/* Inflation adjusted expense */

const futureExp=expense*Math.pow(1+infl,20)

/* Financial Freedom Capital */

const target=futureExp*((1-Math.pow(1+r,-life))/r)*(1+r)

/* Years to freedom */

let wealth=assets
let years=0

while(years<100){

wealth=wealth*(1+r)+savings

if(wealth>=target) break

years++

}

/* Monte Carlo */

let success=0

for(let s=0;s<sim;s++){

let w=target

for(let y=0;y<life;y++){

let rand=r+(Math.random()*2-1)*0.15

w=w*(1+rand)-futureExp

if(w<=0) break

}

if(w>0) success++

}

const prob=(success/sim)*100

/* UI updates */

futureExpUI(futureExp)
targetUI(target)
yearsUI(years)
probUI(prob)

explain(prob,target,years)

drawChart(assets,r,savings,years)

}

/* ===== CHART ===== */

function drawChart(PV,r,PMT,years){

const c=document.getElementById("chart")
const ctx=c.getContext("2d")

c.width=c.offsetWidth
c.height=320

ctx.clearRect(0,0,c.width,c.height)

let data=[]
let wealth=PV

for(let i=0;i<=years;i++){

wealth=wealth*(1+r)+PMT
data.push(wealth)

}

const max=Math.max(...data)

ctx.beginPath()
ctx.strokeStyle="#22c55e"
ctx.lineWidth=3

data.forEach((v,i)=>{

const x=i/(data.length-1)*c.width
const y=c.height-(v/max)*c.height

if(i===0) ctx.moveTo(x,y)
else ctx.lineTo(x,y)

})

ctx.stroke()

}

/* ===== UI ===== */

function futureExpUI(v){
document.getElementById("futureExp").innerText=fmt(v)
}

function targetUI(v){
document.getElementById("target").innerText=fmt(v)
}

function yearsUI(v){
document.getElementById("yearsFreedom").innerText=v
}

function probUI(v){
document.getElementById("prob").innerText=v.toFixed(1)+"%"
}

/* ===== EXPLANATION ===== */

function explain(prob,target,years){

document.getElementById("eng").innerHTML=
"To sustain your lifestyle, you need approximately "+fmt(target)+
". Based on your savings rate, you may reach financial freedom in "+
years+" years. The Monte Carlo simulation shows a "+prob.toFixed(1)+
"% probability of sustaining withdrawals."

document.getElementById("bur").innerHTML=
"သင့် lifestyle ကို ဆက်လက်ထောက်ပံ့ရန် "+
fmt(target)+" လောက်လိုအပ်နိုင်သည်။ "+
years+" နှစ်အတွင်း Financial Freedom ရနိုင်ပါသည်။ "+
"Monte Carlo simulation အရ survival probability "+
prob.toFixed(1)+"% ဖြစ်ပါသည်။"

}

/* ===== HELPERS ===== */

function fmt(x){
return "$"+Number(x).toLocaleString()
}

function expenseInput(){return document.getElementById("expense").value}
function inflationInput(){return document.getElementById("inflation").value}
function assetsInput(){return document.getElementById("assets").value}
function savingsInput(){return document.getElementById("savings").value}
function returnInput(){return document.getElementById("return").value}
function lifeInput(){return document.getElementById("life").value}
function simInput(){return document.getElementById("sim").value}

runCalc()

</script>


<?php include 'includes/footer.php'; ?>