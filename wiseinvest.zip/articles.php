<?php 
include 'includes/db.php'; 
include 'includes/header.php'; 

// 1. FETCH ARTICLES (Dynamic & Searchable)
$search_sql = "";
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $s = $conn->real_escape_string($_GET['search']);
    $search_sql = " WHERE title LIKE '%$s%' OR content LIKE '%$s%'";
}

// Fetch from DB
$articles_res = $conn->query("SELECT * FROM articles $search_sql ORDER BY created_at DESC");
?>

<div class="page-hero" style="height: 300px; display:flex; align-items:center; justify-content:center; text-align:center;">
    <div class="hero-content">
        <h1 class="hero-title">Market Insights</h1>
        <p class="hero-subtitle">Expert analysis, news, and educational resources.</p>
    </div>
</div>

<section style="padding: 60px 5%; background: #f8fafc;">
    <div style="max-width: 1200px; margin: 0 auto; display: grid; grid-template-columns: 3fr 1fr; gap: 40px;">
        
        <div class="articles-feed">
            <?php if($articles_res && $articles_res->num_rows > 0): ?>
                <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 30px;">
                    <?php while($art = $articles_res->fetch_assoc()): ?>
                        <?php 
                            // Get Data
                            $id = $art['id']; // THE CRITICAL PART: Get the Unique ID
                            $title = htmlspecialchars($art['title']);
                            $category = htmlspecialchars($art['category']);
                            $date = date('M d, Y', strtotime($art['created_at']));
                            // Create snippet (first 100 chars)
                            $excerpt = substr(strip_tags($art['content']), 0, 100) . "...";
                            // Image
                            $img = !empty($art['image']) ? $art['image'] : 'https://images.unsplash.com/photo-1611974765270-ca12586343bb?q=80&w=500';
                        ?>
                        
                        <article style="background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 5px 15px rgba(0,0,0,0.05); transition: 0.3s; display:flex; flex-direction:column;">
                            <div style="height: 200px; background-image: url('<?php echo $img; ?>'); background-size: cover; background-position: center;"></div>
                            
                            <div style="padding: 20px; flex:1; display:flex; flex-direction:column;">
                                <div style="margin-bottom:10px;">
                                    <span style="background: #f1f5f9; color: #64748b; padding: 4px 10px; border-radius: 20px; font-size: 0.8rem; font-weight: 700;"><?php echo $category; ?></span>
                                </div>
                                
                                <h3 style="margin: 0 0 10px 0; font-size: 1.2rem; color: #0f172a; line-height:1.4;">
                                    <a href="read-article.php?id=<?php echo $id; ?>" style="text-decoration: none; color: inherit;"><?php echo $title; ?></a>
                                </h3>
                                
                                <p style="color: #64748b; font-size: 0.9rem; line-height: 1.6; flex:1;"><?php echo $excerpt; ?></p>
                                
                                <div style="margin-top: 15px; padding-top: 15px; border-top: 1px solid #f1f5f9; display: flex; justify-content: space-between; align-items: center; color: #94a3b8; font-size: 0.85rem;">
                                    <span><i class="far fa-calendar"></i> <?php echo $date; ?></span>
                                    <a href="read-article.php?id=<?php echo $id; ?>" style="color: #d4af37; font-weight: 700; text-decoration: none;">Read More &rarr;</a>
                                </div>
                            </div>
                        </article>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <div style="text-align: center; padding: 50px; color: #94a3b8;">
                    <i class="fas fa-newspaper" style="font-size: 3rem; margin-bottom: 15px;"></i>
                    <h3>No articles found.</h3>
                    <p>Visit the Admin Panel to post your first article.</p>
                </div>
            <?php endif; ?>
        </div>

        <aside>
            <div style="background: white; padding: 25px; border-radius: 12px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); margin-bottom: 30px;">
                <h4 style="margin-top: 0; color: #0f172a;">Search News</h4>
                <form action="articles.php" method="GET" style="display: flex; gap: 5px;">
                    <input type="text" name="search" placeholder="Keywords..." style="width: 100%; padding: 10px; border: 1px solid #cbd5e1; border-radius: 6px;">
                    <button type="submit" style="background: #0f172a; color: white; border: none; padding: 0 15px; border-radius: 6px; cursor: pointer;"><i class="fas fa-search"></i></button>
                </form>
            </div>
        </aside>

    </div>
</section>

<?php include 'includes/footer.php'; ?>