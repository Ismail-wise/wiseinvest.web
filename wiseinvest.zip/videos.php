<?php
include 'includes/header.php';
include 'includes/db.php';

/* ===============================
   CATEGORY FILTER
   =============================== */
$cat = isset($_GET['cat']) ? (int)$_GET['cat'] : 0;

/* ===============================
   PAGINATION
   =============================== */
$per_page = 9;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;

/* ===============================
   BUILD WHERE
   =============================== */
$where = "WHERE 1=1";
$where .= " AND video_type = 'free'";

if ($cat > 0) {
    $where .= " AND folder_id = $cat";
}

/* ===============================
   COUNT
   =============================== */
$count_q = $conn->query("
    SELECT COUNT(*) AS total
    FROM premium_content
    $where
");
$total = (int)$count_q->fetch_assoc()['total'];
$total_pages = max(1, ceil($total / $per_page));
if ($page > $total_pages) $page = $total_pages;

$offset = ($page - 1) * $per_page;

/* ===============================
   FETCH VIDEOS
   =============================== */
$videos_q = $conn->query("
    SELECT *
    FROM premium_content
    $where
    ORDER BY id DESC
    LIMIT $per_page OFFSET $offset
");

/* ===============================
   FETCH CATEGORIES
   =============================== */
$cats_q = $conn->query("SELECT * FROM video_folders ORDER BY name ASC");
?>

<section class="gallery-page clean-gallery">

<header class="gallery-header">
    <h1>Free Video Library</h1>
    <p>Insights, strategies & psychology</p>

    <!-- CATEGORY FILTER -->
    <div class="video-filter-bar">
        <a href="videos.php" class="filter-pill <?= $cat==0?'active':'' ?>">All</a>
        <?php while($c = $cats_q->fetch_assoc()): ?>
            <a href="?cat=<?= $c['id'] ?>"
               class="filter-pill <?= $cat==$c['id']?'active':'' ?>">
               <?= htmlspecialchars($c['name']) ?>
            </a>
        <?php endwhile; ?>
    </div>
</header>

<?php if ($videos_q && $videos_q->num_rows > 0): ?>
<div class="gallery-grid">

<?php while ($v = $videos_q->fetch_assoc()):
    $url = $v['video_url'];
    $locked = $v['is_locked'];

    // YouTube detection
    $yt_id = '';
    if (strpos($url,'youtube') !== false || strpos($url,'youtu.be') !== false) {
        preg_match('~(?:youtu\.be/|v=)([^&?/]+)~', $url, $m);
        $yt_id = $m[1] ?? '';
        $thumb = "https://img.youtube.com/vi/$yt_id/hqdefault.jpg";
    }
?>

<div class="gallery-card video-card <?= $locked?'locked':'' ?>"
     <?php if(!$locked && $yt_id): ?>
     onclick="this.innerHTML='<iframe src=https://www.youtube.com/embed/<?= $yt_id ?>?autoplay=1 allowfullscreen></iframe>'"
     <?php endif; ?>
>

<?php if ($yt_id): ?>
    <img src="<?= $thumb ?>" alt="">
<?php else: ?>
    <blockquote class="tiktok-embed"
        cite="<?= htmlspecialchars($url) ?>"
        data-video-id="<?= basename($url) ?>">
        <section><a href="<?= htmlspecialchars($url) ?>">Loading…</a></section>
    </blockquote>
<?php endif; ?>

<?php if ($locked): ?>
    <div class="premium-overlay">
        <span>🔒 Premium</span>
        <small>Upgrade to unlock</small>
    </div>
<?php else: ?>
    <span class="play-btn">▶</span>
<?php endif; ?>

</div>

<?php endwhile; ?>
</div>
<?php else: ?>
<p class="gallery-empty">No videos found.</p>
<?php endif; ?>

<!-- PAGINATION -->
<?php if ($total_pages > 1): ?>
<div class="dark-pagination">
<?php for($p=1;$p<=$total_pages;$p++): ?>
    <a class="page-link <?= $p==$page?'active':'' ?>"
       href="?page=<?= $p ?><?= $cat? '&cat='.$cat:'' ?>">
        <?= $p ?>
    </a>
<?php endfor; ?>
</div>
<?php endif; ?>

</section>

<script async src="https://www.tiktok.com/embed.js"></script>

<style>
/* FILTER */
.video-filter-bar {
    display:flex;
    gap:10px;
    justify-content:center;
    margin-top:20px;
    flex-wrap:wrap;
}
.filter-pill {
    padding:8px 16px;
    border-radius:999px;
    background:#020617;
    color:#cbd5f5;
    border:1px solid #1e293b;
    text-decoration:none;
}
.filter-pill.active,
.filter-pill:hover {
    background:#facc15;
    color:#000;
}

/* GRID */
.clean-gallery { background:#020617; padding:60px 20px; }
.gallery-grid {
    max-width:1300px;
    margin:0 auto;
    display:grid;
    grid-template-columns:repeat(auto-fill,minmax(320px,1fr));
    gap:26px;
}
.gallery-card {
    position:relative;
    border-radius:20px;
    overflow:hidden;
    box-shadow:0 25px 55px rgba(0,0,0,.55);
    transition:.3s;
}
.gallery-card:hover { transform:translateY(-8px); }

/* MEDIA */
.gallery-card img,
.gallery-card iframe,
.gallery-card blockquote {
    width:100%;
    aspect-ratio:16/9;
    object-fit:cover;
}

/* PLAY */
.play-btn {
    position:absolute;
    inset:0;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:3.5rem;
    color:#facc15;
    background:rgba(0,0,0,.4);
}

/* PREMIUM */
.locked img,
.locked iframe {
    filter:blur(6px);
}
.premium-overlay {
    position:absolute;
    inset:0;
    background:rgba(0,0,0,.6);
    color:#facc15;
    display:flex;
    flex-direction:column;
    align-items:center;
    justify-content:center;
    font-size:1.3rem;
}
</style>

<?php include 'includes/footer.php'; ?>